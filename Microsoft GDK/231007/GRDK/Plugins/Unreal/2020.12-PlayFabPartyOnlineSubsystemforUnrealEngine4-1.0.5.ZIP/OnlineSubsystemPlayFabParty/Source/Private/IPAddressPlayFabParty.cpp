//--------------------------------------------------------------------------------------
// Copyright (C) Microsoft Corporation. All rights reserved.
//--------------------------------------------------------------------------------------

#include "IPAddressPlayFabParty.h"
#include "OnlineSubsystemPlayFabPartyPrivate.h"
#include "OnlineSubsystemPlayFabPartyDefines.h"

FInternetAddrPlayFabParty::FInternetAddrPlayFabParty(uint32 InUniqueId) :
	EndpointId(InUniqueId),
	Port(InUniqueId)
{
}

FInternetAddrPlayFabParty::FInternetAddrPlayFabParty(const FInternetAddrPlayFabParty& Src) : 
	EndpointId(Src.EndpointId), 
	Port(Src.Port)
{
}

void FInternetAddrPlayFabParty::SetIp(uint32 InAddr)
{
	EndpointId = InAddr;
}

void FInternetAddrPlayFabParty::GetIp(uint32& OutAddr) const
{
	OutAddr = EndpointId;
}

void FInternetAddrPlayFabParty::SetPort(int32 InPort)
{
	Port = InPort;
}

void FInternetAddrPlayFabParty::GetPort(int32& OutPort) const
{
	OutPort = Port;
}

int32 FInternetAddrPlayFabParty::GetPort() const
{
	return Port;
}

FName FInternetAddrPlayFabParty::GetProtocolType() const
{
	return PLAYFABPARTY_SUBSYSTEM;
}

TArray<uint8> FInternetAddrPlayFabParty::GetRawIp() const
{
	TArray<uint8> RawAddressArray;
	const uint8* RawData = reinterpret_cast<const uint8*>(&EndpointId);
	for (uint32 DataIndex = 0; DataIndex < sizeof(EndpointId); DataIndex++)
	{
		RawAddressArray.Add(RawData[DataIndex]);
	}

	return RawAddressArray;
}

void FInternetAddrPlayFabParty::SetRawIp(const TArray<uint8>& RawAddr)
{
	check(RawAddr.Num() == sizeof(EndpointId));
	if (RawAddr.Num() != sizeof(EndpointId))
	{
		return;
	}

	FMemory::Memcpy(&EndpointId, RawAddr.GetData(), sizeof(EndpointId));
	Port = EndpointId;
}

void FInternetAddrPlayFabParty::SetIp(const TCHAR* InAddr, bool& bIsValid)
{
	bIsValid = false;

	if (FCString::Strncmp(InAddr, PLAYFABPARTY_URL_PREFIX, FCString::Strlen(PLAYFABPARTY_URL_PREFIX)) == 0)
	{
		const TCHAR* AddrStart = InAddr + UE_ARRAY_COUNT(PLAYFABPARTY_URL_PREFIX) - 1;
		if (AddrStart)
		{
			const TCHAR* PortStart = FCString::Strrchr(AddrStart, L':');
			if (PortStart == nullptr)
			{
				PortStart = AddrStart + FCString::Strlen(AddrStart) + 1;
			}
			else
			{
				PortStart++;
			}

			Port = FCString::Atoi(PortStart);

			FString PartyIdString = FString(AddrStart, static_cast<int>(static_cast<intptr_t>(PortStart - AddrStart)) - 1);
			if (PartyIdString.Len() > 0)
			{
				EndpointId = FCString::Atoi(*PartyIdString);
				bIsValid = EndpointId != 0;
			}
		}
	}
}

FString FInternetAddrPlayFabParty::ToString(bool bAppendPort) const
{
	if (bAppendPort)
	{
		return FString::Printf(TEXT("%s%d:%d"), PLAYFABPARTY_URL_PREFIX, EndpointId, Port);
	}
	else
	{
		return FString::Printf(TEXT("%s%d"), PLAYFABPARTY_URL_PREFIX, EndpointId);
	}
}

uint32 FInternetAddrPlayFabParty::GetTypeHash() const
{
	return GetConstTypeHash();
}

bool FInternetAddrPlayFabParty::IsValid() const
{
	return EndpointId != 0;
}

TSharedRef<FInternetAddr> FInternetAddrPlayFabParty::Clone() const
{
	return MakeShareable(new FInternetAddrPlayFabParty(*this));
}

uint32 FInternetAddrPlayFabParty::GetConstTypeHash() const
{
	return ::GetTypeHash(ToString(true));
}

bool FInternetAddrPlayFabParty::operator!=(const FInternetAddrPlayFabParty& Other) const
{
	return !(FInternetAddrPlayFabParty::operator==(Other));
}

bool FInternetAddrPlayFabParty::operator==(const FInternetAddr& Other) const
{
	FInternetAddrPlayFabParty& PlayFabOther = (FInternetAddrPlayFabParty&)Other;
	return EndpointId == PlayFabOther.EndpointId;
}