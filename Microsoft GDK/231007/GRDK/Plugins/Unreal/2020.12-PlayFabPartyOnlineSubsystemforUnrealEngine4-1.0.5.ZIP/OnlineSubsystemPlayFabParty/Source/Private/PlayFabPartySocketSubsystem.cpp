//--------------------------------------------------------------------------------------
// Copyright (C) Microsoft Corporation. All rights reserved.
//--------------------------------------------------------------------------------------

#include "PlayFabPartySocketSubsystem.h"
#include "OnlineSubsystemPlayFabParty.h"
#include "PlayFabPartySocket.h"
#include "SocketSubsystemModule.h"
#include "PlayFabPartySocketSubsystem.h"
#include "IPAddressPlayFabParty.h"

FPlayFabPartySocketSubsystem* FPlayFabPartySocketSubsystem::SocketSingleton = nullptr;

 // Create the socket subsystem for the given platform service
FName CreatePlayFabPartySocketSubsystem()
{
	FName SubsystemName(PLAYFABPARTY_SOCKET_SUBSYSTEM);

	// Create and register our singleton factory with the main online subsystem for easy access
	FPlayFabPartySocketSubsystem* SocketSubsystem = FPlayFabPartySocketSubsystem::Create();
	FString Error;
	if (SocketSubsystem->Init(Error))
	{
		FSocketSubsystemModule& SSS = FModuleManager::LoadModuleChecked<FSocketSubsystemModule>("Sockets");
		SSS.RegisterSocketSubsystem(SubsystemName, SocketSubsystem, true);
		return SubsystemName;
	}
	else
	{
		FPlayFabPartySocketSubsystem::Destroy();
		return NAME_None;
	}
}

 // Tear down the socket subsystem for the given platform service
void DestroyPlayFabPartySocketSubsystem()
{
	FModuleManager& ModuleManager = FModuleManager::Get();

	if (ModuleManager.IsModuleLoaded("Sockets"))
	{
		FSocketSubsystemModule& SSS = FModuleManager::GetModuleChecked<FSocketSubsystemModule>("Sockets");
		SSS.UnregisterSocketSubsystem(PLAYFABPARTY_SOCKET_SUBSYSTEM);
	}

	FPlayFabPartySocketSubsystem::Destroy();
}

FPlayFabPartySocketSubsystem::FPlayFabPartySocketSubsystem()
{
}

FPlayFabPartySocketSubsystem* FPlayFabPartySocketSubsystem::Create()
{
	if (SocketSingleton == nullptr)
	{
		SocketSingleton = new FPlayFabPartySocketSubsystem();
	}

	return SocketSingleton;
}

void FPlayFabPartySocketSubsystem::Destroy()
{
	if (SocketSingleton)
	{
		SocketSingleton->Shutdown();
		delete SocketSingleton;
		SocketSingleton = nullptr;
	}
}

void FPlayFabPartySocketSubsystem::OnEndpointMessageReceived(const PartyEndpointMessageReceivedStateChange* MessagedReceivedChange)
{
	if (MessagedReceivedChange)
	{
		const uint8* Buffer = static_cast<const uint8*>(MessagedReceivedChange->messageBuffer);
		TArray<uint8> Payload(Buffer, MessagedReceivedChange->messageSize);

		uint16 SenderEndpointId = 0;
		PartyError Err = MessagedReceivedChange->senderEndpoint->GetUniqueIdentifier(&SenderEndpointId);
		if (PARTY_SUCCEEDED(Err))
		{
			if (FPlayFabPartySocket* Socket = GetSocket())
			{
				Socket->AddNewPendingData(SenderEndpointId, Payload);
			}
		}
		else
		{
			UE_LOG(LogSockets, Warning, TEXT("FPlayFabPartySocketSubsystem::OnEndpointMessageReceived: GetEntityId failed:  %s"), *GetPartyErrorMessage(Err));
		}
	}
}

bool FPlayFabPartySocketSubsystem::Init(FString& Error)
{
	return true;
}

void FPlayFabPartySocketSubsystem::RegisterDelegates(FOnlineSubsystemPlayFabParty* InOSSPlayFabParty)
{
	if (InOSSPlayFabParty)
	{
		OSSPlayFabParty = InOSSPlayFabParty;

		OnEndpointMessageReceivedDelegateHandle = OSSPlayFabParty->AddOnEndpointMessageReceivedDelegate_Handle(FOnEndpointMessageReceivedDelegate::CreateRaw(this, &FPlayFabPartySocketSubsystem::OnEndpointMessageReceived));
	}
}

void FPlayFabPartySocketSubsystem::Shutdown()
{
	UE_LOG(LogSockets, Log, TEXT("FPlayFabPartySocketSubsystem: Shutting down"));

	CleanUpActiveSockets();

	// Clean up our delegates here
	if (OSSPlayFabParty)
	{
		OSSPlayFabParty->ClearOnEndpointMessageReceivedDelegate_Handle(OnEndpointMessageReceivedDelegateHandle);
	}

	OSSPlayFabParty = nullptr;
}

class FSocket* FPlayFabPartySocketSubsystem::CreateSocket(const FName& SocketType, const FString& SocketDescription, const FName& ProtocolType)
{
	UE_LOG(LogSockets, Verbose, TEXT("FPlayFabPartySocketSubsystem::CreateSocket"));

	FPlayFabPartySocket* NewSocket = nullptr;

	if (OSSPlayFabParty)
	{
		NewSocket = new FPlayFabPartySocket(OSSPlayFabParty, SocketDescription, FNetworkProtocolTypes::PlayFabParty);
		AddSocket(NewSocket);
	}

	return NewSocket;
}

void FPlayFabPartySocketSubsystem::DestroySocket(class FSocket* Socket)
{
	UE_LOG(LogSockets, Verbose, TEXT("FPlayFabPartySocketSubsystem::DestroySocket"));

	FPlayFabPartySocket* PlayFabPartySocket = static_cast<FPlayFabPartySocket*>(Socket);
	if (PlayFabPartySocket)
	{
		RemoveSocket(PlayFabPartySocket);
		delete Socket;
	}
}

FAddressInfoResult FPlayFabPartySocketSubsystem::GetAddressInfo(const TCHAR* HostName, const TCHAR* ServiceName /*= nullptr*/, EAddressInfoFlags QueryFlags /*= EAddressInfoFlags::Default*/, const FName ProtocolTypeName /*= NAME_None*/, ESocketType SocketType /*= ESocketType::SOCKTYPE_Unknown*/)
{
	UE_LOG_ONLINE(Warning, TEXT("FPlayFabPartySocketSubsystem::GetAddressInfo is not supported on PlayFabParty Sockets"));
	return FAddressInfoResult(HostName, ServiceName);
}

TSharedPtr<FInternetAddr> FPlayFabPartySocketSubsystem::GetAddressFromString(const FString& IPAddress)
{
	UE_LOG(LogSockets, Verbose, TEXT("FPlayFabPartySocketSubsystem::GetAddressFromString"));

	FInternetAddrPlayFabParty* PlayFabPartyAddr = new FInternetAddrPlayFabParty();
	bool IsValid;
	PlayFabPartyAddr->SetIp(*IPAddress, IsValid);
	return MakeShareable(PlayFabPartyAddr);
}

TSharedRef<FInternetAddr> FPlayFabPartySocketSubsystem::CreateInternetAddr()
{
	return MakeShareable(new FInternetAddrPlayFabParty());
}

bool FPlayFabPartySocketSubsystem::GetLocalAdapterAddresses(TArray<TSharedPtr<FInternetAddr>>& OutAddresses)
{
	bool bCanBindAll;

	OutAddresses.Add(GetLocalHostAddr(*GLog, bCanBindAll));

	return true;
}

TSharedRef<FInternetAddr> FPlayFabPartySocketSubsystem::GetLocalBindAddr(FOutputDevice& Out)
{
	if (OSSPlayFabParty && OSSPlayFabParty->LocalEndpoint)
	{
		uint16 EndpointId = 0;
		PartyError Err = OSSPlayFabParty->LocalEndpoint->GetUniqueIdentifier(&EndpointId);

		if (PARTY_FAILED(Err))
		{
			UE_LOG_ONLINE(Warning, TEXT("FPlayFabPartySocketSubsystem::GetLocalBindAddr: failed: %s"), *GetPartyErrorMessage(Err));
		}
		else
		{
			return MakeShareable(new FInternetAddrPlayFabParty(EndpointId));
		}
	}

	return MakeShareable(new FInternetAddrPlayFabParty());
}

TSharedRef<FInternetAddr> FPlayFabPartySocketSubsystem::GetLocalHostAddr(FOutputDevice& Out, bool& bCanBindAll)
{
	TSharedRef<FInternetAddr> HostAddr = GetLocalBindAddr(Out);
	bCanBindAll = true;

	return HostAddr;
}

const TCHAR* FPlayFabPartySocketSubsystem::GetSocketAPIName() const
{
	return TEXT("PlayFabParty");
}

FPlayFabPartySocket* FPlayFabPartySocketSubsystem::GetSocket()
{
	UE_LOG(LogSockets, Verbose, TEXT("FPlayFabPartySocketSubsystem::GetSocket"));

	FPlayFabPartySocket* FoundSocket = nullptr;
	for (FPlayFabPartySocket* Socket : ActiveSockets)
	{
		if (Socket)
		{
			FoundSocket = Socket;
			break;
		}
	}

	if (FoundSocket == nullptr)
	{
		UE_LOG(LogSockets, Warning, TEXT("FPlayFabPartySocketSubsystem::GetSocketByEntityId: Cannot get Socket, returning null"));
	}

	return FoundSocket;
}

void FPlayFabPartySocketSubsystem::AddSocket(FPlayFabPartySocket* NewSocket)
{
	UE_LOG(LogSockets, Verbose, TEXT("FPlayFabPartySocketSubsystem::AddSocket"));

	if (NewSocket)
	{
		ActiveSockets.Add(NewSocket);
	}
	else
	{
		UE_LOG(LogSockets, Warning, TEXT("FPlayFabPartySocketSubsystem::AddSocket: NewSocket was null, cannot add socket"));
	}
}

void FPlayFabPartySocketSubsystem::RemoveSocket(FPlayFabPartySocket* Socket)
{
	UE_LOG(LogSockets, Verbose, TEXT("FPlayFabPartySocketSubsystem::RemoveSocket"));

	ActiveSockets.RemoveSingleSwap(Socket);
}

void FPlayFabPartySocketSubsystem::CleanUpActiveSockets()
{
	UE_LOG(LogSockets, Verbose, TEXT("FPlayFabPartySocketSubsystem::CleanUpActiveSockets"));

	// Clean up sockets
	TArray<FPlayFabPartySocket*> TempArray = ActiveSockets;
	for (int SocketIdx = 0; SocketIdx < TempArray.Num(); SocketIdx++)
	{
		DestroySocket(TempArray[SocketIdx]);
	}

	ActiveSockets.Empty();
}

void FPlayFabPartySocketSubsystem::LinkNetDriver(UPlayFabPartyNetDriver* InNetDriver)
{
	NetDriver = InNetDriver;
}