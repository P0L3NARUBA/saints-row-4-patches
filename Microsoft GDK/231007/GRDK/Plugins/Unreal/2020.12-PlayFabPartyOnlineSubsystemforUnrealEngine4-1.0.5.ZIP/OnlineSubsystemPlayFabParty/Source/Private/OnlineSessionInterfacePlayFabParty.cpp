//--------------------------------------------------------------------------------------
// Copyright (C) Microsoft Corporation. All rights reserved.
//--------------------------------------------------------------------------------------

#include "OnlineSessionInterfacePlayFabParty.h"
#include "OnlineSubsystemSessionSettings.h"
#include "OnlineSessionSettings.h"
#include "PlayFabPartySocketSubsystem.h"
#include "../PlatformSpecific/PlatformDefines.h"

#include "OnlineSubsystemPlayFabParty.h"
#include "OnlineSubsystemPlayFabPartyPrivate.h"

#define OSS_PFP_GET_NATIVE_SESSION_INTERFACE IOnlineSubsystem* NativeSubsystem = IOnlineSubsystem::GetByPlatform();  IOnlineSessionPtr NativeSessionInterface = NativeSubsystem ? NativeSubsystem->GetSessionInterface() : nullptr; if (NativeSessionInterface)

FOnlineSessionPlayFabParty::FOnlineSessionPlayFabParty(class FOnlineSubsystemPlayFabParty* InSubsystem) :
	OSSPlayFabParty(InSubsystem)
{

}

FOnlineSessionPlayFabParty::~FOnlineSessionPlayFabParty()
{
	// Clean up delegates
	if (OSSPlayFabParty)
	{
		OSSPlayFabParty->ClearOnConnectToPlayFabPartyNetworkCompletedDelegates(this);
	}
}

TSharedPtr<const FUniqueNetId> FOnlineSessionPlayFabParty::CreateSessionIdFromString(const FString& SessionIdStr)
{
	OSS_PFP_GET_NATIVE_SESSION_INTERFACE
	{
		return NativeSessionInterface->CreateSessionIdFromString(SessionIdStr);
	}

	return nullptr;
}

FNamedOnlineSession* FOnlineSessionPlayFabParty::GetNamedSession(FName SessionName)
{
	OSS_PFP_GET_NATIVE_SESSION_INTERFACE
	{
		return NativeSessionInterface->GetNamedSession(SessionName);
	}

	return nullptr;
}

void FOnlineSessionPlayFabParty::RemoveNamedSession(FName SessionName)
{
	OSS_PFP_GET_NATIVE_SESSION_INTERFACE
	{
		return NativeSessionInterface->RemoveNamedSession(SessionName);
	}
}

bool FOnlineSessionPlayFabParty::HasPresenceSession()
{
	OSS_PFP_GET_NATIVE_SESSION_INTERFACE
	{
		return NativeSessionInterface->HasPresenceSession();
	}

	return false;
}

EOnlineSessionState::Type FOnlineSessionPlayFabParty::GetSessionState(FName SessionName) const
{
	OSS_PFP_GET_NATIVE_SESSION_INTERFACE
	{
		return NativeSessionInterface->GetSessionState(SessionName);
	}

	return EOnlineSessionState::NoSession;
}

bool FOnlineSessionPlayFabParty::CreateSession(int32 HostingPlayerControllerIndex, FName SessionName, const FOnlineSessionSettings& NewSessionSettings)
{
	bool bSuccess = false;

	PendingCreateSessionInfo.PlayerControllerIndex = HostingPlayerControllerIndex;
	PendingCreateSessionInfo.PlayerId = nullptr;
	PendingCreateSessionInfo.SessionName = SessionName;
	PendingCreateSessionInfo.SessionSettings = NewSessionSettings;

	if (OSSPlayFabParty)
	{
		OSSPlayFabParty->AddOnPartyEndpointCreatedDelegate_Handle(FOnPartyEndpointCreatedDelegate::CreateRaw(this, &FOnlineSessionPlayFabParty::OnCreatePartyEndpoint));

		bSuccess = OSSPlayFabParty->CreateAndConnectToPlayFabPartyNetwork();
	}

	if (bSuccess == false)
	{
		TriggerOnCreateSessionCompleteDelegates(SessionName, false);
	}

	return bSuccess;
}

bool FOnlineSessionPlayFabParty::CreateSession(const FUniqueNetId& HostingPlayerId, FName SessionName, const FOnlineSessionSettings& NewSessionSettings)
{
	bool bSuccess = false;

	PendingCreateSessionInfo.PlayerControllerIndex = INDEX_NONE;
	PendingCreateSessionInfo.PlayerId = HostingPlayerId.AsShared();
	PendingCreateSessionInfo.SessionName = SessionName;
	PendingCreateSessionInfo.SessionSettings = NewSessionSettings;

	if (OSSPlayFabParty)
	{
		OSSPlayFabParty->AddOnPartyEndpointCreatedDelegate_Handle(FOnPartyEndpointCreatedDelegate::CreateRaw(this, &FOnlineSessionPlayFabParty::OnCreatePartyEndpoint));

		bSuccess = OSSPlayFabParty->CreateAndConnectToPlayFabPartyNetwork();
	}

	if (bSuccess == false)
	{
		TriggerOnCreateSessionCompleteDelegates(SessionName, false);
	}

	return bSuccess;
}

void FOnlineSessionPlayFabParty::OnCreatePartyEndpoint(bool bSuccess, uint16 EndpointID, bool bIsHosting)
{
	if (OSSPlayFabParty)
	{
		OSSPlayFabParty->ClearOnPartyEndpointCreatedDelegates(this);
	}

	if (bIsHosting)
	{
		ISocketSubsystem* PlayFabPartySocketSubsystem = ISocketSubsystem::Get(PLAYFABPARTY_SOCKET_SUBSYSTEM);
		if (bSuccess && OSSPlayFabParty && PlayFabPartySocketSubsystem)
		{
			bool BindAll = false;
			TSharedRef<FInternetAddr> LocalIp = PlayFabPartySocketSubsystem->GetLocalHostAddr(*GLog, BindAll);
			if (LocalIp->IsValid())
			{
				FString NetworkIdStr = OSSPlayFabParty->NetworkId;
				FString NetworkDescriptorStr = OSSPlayFabParty->SerializeNetworkDescriptor(OSSPlayFabParty->NetworkDescriptor);
				FString HostConnectInfo = LocalIp->ToString(false);

				PendingCreateSessionInfo.SessionSettings.Set(SETTING_NETWORK_ID, NetworkIdStr, EOnlineDataAdvertisementType::ViaOnlineService);
				PendingCreateSessionInfo.SessionSettings.Set(SETTING_NETWORK_DESCRIPTOR, NetworkDescriptorStr, EOnlineDataAdvertisementType::ViaOnlineService);
				PendingCreateSessionInfo.SessionSettings.Set(SETTING_HOST_CONNECT_INFO, HostConnectInfo, EOnlineDataAdvertisementType::ViaOnlineService);

				PendingCreateSessionInfo.SessionSettings.bIsDedicated = true;
			}
			else
			{
				UE_LOG_ONLINE_SESSION(Verbose, TEXT("FOnlineSessionPlayFabParty::OnCreatePartyEndpoin: LocalHostAddr was invalid"));
			}

			OSS_PFP_GET_NATIVE_SESSION_INTERFACE
			{
				if (bSuccess)
				{
					if (PendingCreateSessionInfo.PlayerControllerIndex != INDEX_NONE)
					{
						NativeSessionInterface->CreateSession(PendingCreateSessionInfo.PlayerControllerIndex, PendingCreateSessionInfo.SessionName, PendingCreateSessionInfo.SessionSettings);
					}
					else if (PendingCreateSessionInfo.PlayerId.IsValid())
					{
						NativeSessionInterface->CreateSession(*PendingCreateSessionInfo.PlayerId, PendingCreateSessionInfo.SessionName, PendingCreateSessionInfo.SessionSettings);
					}
					else
					{
						TriggerOnCreateSessionCompleteDelegates(PendingCreateSessionInfo.SessionName, false);
					}
				}
				else
				{
					TriggerOnCreateSessionCompleteDelegates(PendingCreateSessionInfo.SessionName, false);
				}
			}
			else
			{
				TriggerOnCreateSessionCompleteDelegates(PendingCreateSessionInfo.SessionName, false);
			}
		}
		else
		{
			TriggerOnCreateSessionCompleteDelegates(PendingCreateSessionInfo.SessionName, false);
		}
	}
}

bool FOnlineSessionPlayFabParty::StartSession(FName SessionName)
{
	OSS_PFP_GET_NATIVE_SESSION_INTERFACE
	{
		return NativeSessionInterface->StartSession(SessionName);
	}

	return false;
}

bool FOnlineSessionPlayFabParty::UpdateSession(FName SessionName, FOnlineSessionSettings& UpdatedSessionSettings, bool bShouldRefreshOnlineData /*= false*/)
{
	OSS_PFP_GET_NATIVE_SESSION_INTERFACE
	{
		return NativeSessionInterface->UpdateSession(SessionName, UpdatedSessionSettings, bShouldRefreshOnlineData);
	}

	return false;
}

bool FOnlineSessionPlayFabParty::EndSession(FName SessionName)
{
	OSS_PFP_GET_NATIVE_SESSION_INTERFACE
	{
		return NativeSessionInterface->EndSession(SessionName);
	}

	return false;
}

bool FOnlineSessionPlayFabParty::DestroySession(FName SessionName, const FOnDestroySessionCompleteDelegate& CompletionDelegate /*= FOnDestroySessionCompleteDelegate()*/)
{
	// Leave the PlayFab Party network
	if (OSSPlayFabParty)
	{
		OSSPlayFabParty->LeavePlayFabPartyNetwork();
	}

	OSS_PFP_GET_NATIVE_SESSION_INTERFACE
	{
		return NativeSessionInterface->DestroySession(SessionName, CompletionDelegate);
	}

	return false;
}

bool FOnlineSessionPlayFabParty::IsPlayerInSession(FName SessionName, const FUniqueNetId& UniqueId)
{
	OSS_PFP_GET_NATIVE_SESSION_INTERFACE
	{
		return NativeSessionInterface->IsPlayerInSession(SessionName, UniqueId);
	}

	return false;
}

bool FOnlineSessionPlayFabParty::StartMatchmaking(const TArray< TSharedRef<const FUniqueNetId> >& LocalPlayers, FName SessionName, const FOnlineSessionSettings& NewSessionSettings, TSharedRef<FOnlineSessionSearch>& SearchSettings)
{
	OSS_PFP_GET_NATIVE_SESSION_INTERFACE
	{
		return NativeSessionInterface->StartMatchmaking(LocalPlayers, SessionName, NewSessionSettings, SearchSettings);
	}

	return false;
}

bool FOnlineSessionPlayFabParty::CancelMatchmaking(int32 SearchingPlayerNum, FName SessionName)
{
	OSS_PFP_GET_NATIVE_SESSION_INTERFACE
	{
		return NativeSessionInterface->CancelMatchmaking(SearchingPlayerNum, SessionName);
	}

	return false;
}

bool FOnlineSessionPlayFabParty::CancelMatchmaking(const FUniqueNetId& SearchingPlayerId, FName SessionName)
{
	OSS_PFP_GET_NATIVE_SESSION_INTERFACE
	{
		return NativeSessionInterface->CancelMatchmaking(SearchingPlayerId, SessionName);
	}

	return false;
}

bool FOnlineSessionPlayFabParty::FindSessions(int32 SearchingPlayerNum, const TSharedRef<FOnlineSessionSearch>& SearchSettings)
{
	OSS_PFP_GET_NATIVE_SESSION_INTERFACE
	{
		return NativeSessionInterface->FindSessions(SearchingPlayerNum, SearchSettings);
	}

	return false;
}

bool FOnlineSessionPlayFabParty::FindSessions(const FUniqueNetId& SearchingPlayerId, const TSharedRef<FOnlineSessionSearch>& SearchSettings)
{
	OSS_PFP_GET_NATIVE_SESSION_INTERFACE
	{
		return NativeSessionInterface->FindSessions(SearchingPlayerId, SearchSettings);
	}

	return false;
}

bool FOnlineSessionPlayFabParty::FindSessionById(const FUniqueNetId& SearchingUserId, const FUniqueNetId& SessionId, const FUniqueNetId& FriendId, const FOnSingleSessionResultCompleteDelegate& CompletionDelegate)
{
	OSS_PFP_GET_NATIVE_SESSION_INTERFACE
	{
		return NativeSessionInterface->FindSessionById(SearchingUserId, SessionId, FriendId, CompletionDelegate);
	}

	return false;
}

bool FOnlineSessionPlayFabParty::CancelFindSessions()
{
	OSS_PFP_GET_NATIVE_SESSION_INTERFACE
	{
		return NativeSessionInterface->CancelFindSessions();
	}

	return false;
}

bool FOnlineSessionPlayFabParty::PingSearchResults(const FOnlineSessionSearchResult& SearchResult)
{
	OSS_PFP_GET_NATIVE_SESSION_INTERFACE
	{
		return NativeSessionInterface->PingSearchResults(SearchResult);
	}

	return false;
}

bool FOnlineSessionPlayFabParty::JoinSession_PlayFabInternal(const FOnlineSessionSearchResult& DesiredSession)
{
	bool bSuccess = false;

	if (OSSPlayFabParty)
	{
		FString NetworkIdStr;
		FString NetworkDescriptorStr;
		FString HostConnectInfo;
		if (DesiredSession.Session.SessionSettings.Get(SETTING_NETWORK_ID, NetworkIdStr) &&
			DesiredSession.Session.SessionSettings.Get(SETTING_NETWORK_DESCRIPTOR, NetworkDescriptorStr) &&
			DesiredSession.Session.SessionSettings.Get(SETTING_HOST_CONNECT_INFO, HostConnectInfo))
		{
			OSSPlayFabParty->AddOnConnectToPlayFabPartyNetworkCompletedDelegate_Handle(FOnConnectToPlayFabPartyNetworkCompletedDelegate::CreateRaw(this, &FOnlineSessionPlayFabParty::OnConnectToNetworkCompleted));
			OSSPlayFabParty->AddOnPartyEndpointCreatedDelegate_Handle(FOnPartyEndpointCreatedDelegate::CreateRaw(this, &FOnlineSessionPlayFabParty::OnCreatePartyEndpoint));

			OnJoinSessionCompleteDelegateHandle = AddOnJoinSessionCompleteDelegate_Handle(FOnJoinSessionCompleteDelegate::CreateRaw(this, &FOnlineSessionPlayFabParty::OnJoinSessionComplete));

			bSuccess = OSSPlayFabParty->ConnectToPlayFabPartyNetwork(NetworkIdStr, NetworkDescriptorStr);
		}
		else
		{
			UE_LOG_ONLINE_SESSION(Warning, TEXT("FOnlineSessionPlayFabParty::JoinSession_PlayFabInternal: Failed to get required connection strings from SessionSettings"));
		}
	}

	return bSuccess;
}

bool FOnlineSessionPlayFabParty::JoinSession(int32 ControllerIndex, FName SessionName, const FOnlineSessionSearchResult& DesiredSession)
{
	bool bSuccess = false;

	if (OSSPlayFabParty)
	{
		PendingJoinSessionInfo.PlayerControllerIndex = ControllerIndex;
		PendingJoinSessionInfo.PlayerId = nullptr;
		PendingJoinSessionInfo.SessionName = SessionName;
		PendingJoinSessionInfo.SessionSearchResult = DesiredSession;

		bSuccess = JoinSession_PlayFabInternal(DesiredSession);
	}

	if (bSuccess == false)
	{
		TriggerOnJoinSessionCompleteDelegates(SessionName, EOnJoinSessionCompleteResult::UnknownError);
	}

	return bSuccess;
}

bool FOnlineSessionPlayFabParty::JoinSession(const FUniqueNetId& UserId, FName SessionName, const FOnlineSessionSearchResult& DesiredSession)
{
	bool bSuccess = false;

	if (OSSPlayFabParty)
	{
		PendingJoinSessionInfo.PlayerControllerIndex = INDEX_NONE;
		PendingJoinSessionInfo.PlayerId = UserId.AsShared();
		PendingJoinSessionInfo.SessionName = SessionName;
		PendingJoinSessionInfo.SessionSearchResult = DesiredSession;
		
		bSuccess = JoinSession_PlayFabInternal(DesiredSession);
	}

	if (bSuccess == false)
	{
		TriggerOnJoinSessionCompleteDelegates(SessionName, EOnJoinSessionCompleteResult::UnknownError);
	}

	return bSuccess;
}

void FOnlineSessionPlayFabParty::OnJoinSessionComplete(FName InSessionName, EOnJoinSessionCompleteResult::Type Result)
{
	ClearOnJoinSessionCompleteDelegate_Handle(OnJoinSessionCompleteDelegateHandle);
	
	if (Result != EOnJoinSessionCompleteResult::Success && Result != EOnJoinSessionCompleteResult::AlreadyInSession)
	{
		// Leave the PlayFab Party network
		if (OSSPlayFabParty)
		{
			OSSPlayFabParty->LeavePlayFabPartyNetwork();
		}
	}	
}

void FOnlineSessionPlayFabParty::OnConnectToNetworkCompleted(bool bSuccess)
{
	// Clean up the delegate
	if (OSSPlayFabParty)
	{
		OSSPlayFabParty->ClearOnConnectToPlayFabPartyNetworkCompletedDelegates(this);
	}

	OSS_PFP_GET_NATIVE_SESSION_INTERFACE
	{
		if (bSuccess)
		{
			if (PendingJoinSessionInfo.PlayerControllerIndex != INDEX_NONE)
			{
				NativeSessionInterface->JoinSession(PendingJoinSessionInfo.PlayerControllerIndex, PendingJoinSessionInfo.SessionName, PendingJoinSessionInfo.SessionSearchResult);
			}
			else if (PendingJoinSessionInfo.PlayerId.IsValid())
			{
				NativeSessionInterface->JoinSession(*PendingJoinSessionInfo.PlayerId, PendingJoinSessionInfo.SessionName, PendingJoinSessionInfo.SessionSearchResult);
			}
			else
			{
				UE_LOG_ONLINE_SESSION(Warning, TEXT("FOnlineSessionPlayFabParty::OnConnectToNetworkCompleted: PendingJoinSessionInfo had invalid data to join the session"));
				TriggerOnJoinSessionCompleteDelegates(PendingJoinSessionInfo.SessionName, EOnJoinSessionCompleteResult::UnknownError);
			}
		}
		else
		{
			TriggerOnJoinSessionCompleteDelegates(PendingJoinSessionInfo.SessionName, EOnJoinSessionCompleteResult::UnknownError);
		}
	}
}

bool FOnlineSessionPlayFabParty::FindFriendSession(int32 LocalUserNum, const FUniqueNetId& Friend)
{
	OSS_PFP_GET_NATIVE_SESSION_INTERFACE
	{
		return NativeSessionInterface->FindFriendSession(LocalUserNum, Friend);
	}

	return false;
}

bool FOnlineSessionPlayFabParty::FindFriendSession(const FUniqueNetId& LocalUserId, const FUniqueNetId& Friend)
{
	OSS_PFP_GET_NATIVE_SESSION_INTERFACE
	{
		return NativeSessionInterface->FindFriendSession(LocalUserId, Friend);
	}

	return false;
}

bool FOnlineSessionPlayFabParty::FindFriendSession(const FUniqueNetId& LocalUserId, const TArray<TSharedRef<const FUniqueNetId>>& FriendList)
{
	OSS_PFP_GET_NATIVE_SESSION_INTERFACE
	{
		return NativeSessionInterface->FindFriendSession(LocalUserId, FriendList);
	}

	return false;
}

bool FOnlineSessionPlayFabParty::SendSessionInviteToFriend(int32 LocalUserNum, FName SessionName, const FUniqueNetId& Friend)
{
	OSS_PFP_GET_NATIVE_SESSION_INTERFACE
	{
		return NativeSessionInterface->SendSessionInviteToFriend(LocalUserNum, SessionName, Friend);
	}

	return false;
}

bool FOnlineSessionPlayFabParty::SendSessionInviteToFriend(const FUniqueNetId& LocalUserId, FName SessionName, const FUniqueNetId& Friend)
{
	OSS_PFP_GET_NATIVE_SESSION_INTERFACE
	{
		return NativeSessionInterface->SendSessionInviteToFriend(LocalUserId, SessionName, Friend);
	}

	return false;
}

bool FOnlineSessionPlayFabParty::SendSessionInviteToFriends(int32 LocalUserNum, FName SessionName, const TArray< TSharedRef<const FUniqueNetId> >& Friends)
{
	OSS_PFP_GET_NATIVE_SESSION_INTERFACE
	{
		return NativeSessionInterface->SendSessionInviteToFriends(LocalUserNum, SessionName, Friends);
	}

	return false;
}

bool FOnlineSessionPlayFabParty::SendSessionInviteToFriends(const FUniqueNetId& LocalUserId, FName SessionName, const TArray< TSharedRef<const FUniqueNetId> >& Friends)
{
	OSS_PFP_GET_NATIVE_SESSION_INTERFACE
	{
		return NativeSessionInterface->SendSessionInviteToFriends(LocalUserId, SessionName, Friends);
	}

	return false;
}

bool FOnlineSessionPlayFabParty::GetResolvedConnectString(FName SessionName, FString& ConnectInfo, FName PortType)
{
	// NOTE: We don't care about the IP addr since PlayFab Party does not use them. Return empty IP instead of an actual IP or SDA. Don't call the base OSS.
	ConnectInfo = "0.0.0.0:5000";
	return true;
}

bool FOnlineSessionPlayFabParty::GetResolvedConnectString(const class FOnlineSessionSearchResult& SearchResult, FName PortType, FString& ConnectInfo)
{
	// NOTE: We don't care about the IP addr since PlayFab Party does not use them. Return empty IP instead of an actual IP or SDA. Don't call the base OSS.
	ConnectInfo = "0.0.0.0:5000";
	return true;
}

FOnlineSessionSettings* FOnlineSessionPlayFabParty::GetSessionSettings(FName SessionName)
{
	OSS_PFP_GET_NATIVE_SESSION_INTERFACE
	{
		return NativeSessionInterface->GetSessionSettings(SessionName);
	}

	return nullptr;
}

bool FOnlineSessionPlayFabParty::RegisterPlayer(FName SessionName, const FUniqueNetId& PlayerId, bool bWasInvited)
{
	// Register the player as a local talker with our own voice interface
	IOnlineVoicePtr VoiceIntPtr = OSSPlayFabParty->GetVoiceInterface();
	if (VoiceIntPtr.IsValid())
	{
		FOnlineVoicePlayFabParty* PlayFabVoiceInt = static_cast<FOnlineVoicePlayFabParty*>(VoiceIntPtr.Get());

		IOnlineIdentityPtr IdentityIntPtr = OSSPlayFabParty->GetIdentityInterface();
		if (IdentityIntPtr.IsValid())
		{
			FOnlineIdentityPlayFabParty* PlayFabIdentityInt = static_cast<FOnlineIdentityPlayFabParty*>(IdentityIntPtr.Get());

			FPlayFabPartyUser* pLocalPartyUser = PlayFabIdentityInt->GetPartyLocalUserFromPlatformId(PlayerId);
			if (pLocalPartyUser != nullptr)
			{
				PlayFabVoiceInt->RegisterLocalTalker(PlayerId);
			}
			else
			{
				PlayFabVoiceInt->RegisterRemoteTalker(PlayerId);
			}
		}
	}

	OSS_PFP_GET_NATIVE_SESSION_INTERFACE
	{
		// Convert from string to a platform specific ID
		PLATFORM_UNIQUE_NET_ID_REF PlatformNetID = PLATFORM_UNIQUE_NET_ID::Create(PlayerId.ToString());
		return NativeSessionInterface->RegisterPlayer(SessionName, PlatformNetID.Get(), bWasInvited);
	}

	return false;
}

bool FOnlineSessionPlayFabParty::RegisterPlayers(FName SessionName, const TArray< TSharedRef<const FUniqueNetId> >& Players, bool bWasInvited /*= false*/)
{
	// NOTE: Not implemented for PFP
	return false;
}

bool FOnlineSessionPlayFabParty::UnregisterPlayer(FName SessionName, const FUniqueNetId& PlayerId)
{
	IOnlineVoicePtr VoiceIntPtr = OSSPlayFabParty->GetVoiceInterface();
	if (VoiceIntPtr.IsValid())
	{
		FOnlineVoicePlayFabParty* PlayFabVoiceInt = static_cast<FOnlineVoicePlayFabParty*>(VoiceIntPtr.Get());

		IOnlineIdentityPtr IdentityIntPtr = OSSPlayFabParty->GetIdentityInterface();
		if (IdentityIntPtr.IsValid())
		{
			FOnlineIdentityPlayFabParty* PlayFabIdentityInt = static_cast<FOnlineIdentityPlayFabParty*>(IdentityIntPtr.Get());

			FPlayFabPartyUser* pLocalPartyUser = PlayFabIdentityInt->GetPartyLocalUserFromPlatformId(PlayerId);
			if (pLocalPartyUser != nullptr)
			{
				PlayFabVoiceInt->UnregisterLocalTalker(PlayerId);
			}
			else
			{
				PlayFabVoiceInt->UnregisterRemoteTalker(PlayerId);
			}
		}
	}

	OSS_PFP_GET_NATIVE_SESSION_INTERFACE
	{
		// convert from string to a platform specific ID
		PLATFORM_UNIQUE_NET_ID_REF PlatformNetID = PLATFORM_UNIQUE_NET_ID::Create(PlayerId.ToString());
		return NativeSessionInterface->UnregisterPlayer(SessionName, *PlatformNetID);
	}

	return false;
}

bool FOnlineSessionPlayFabParty::UnregisterPlayers(FName SessionName, const TArray< TSharedRef<const FUniqueNetId> >& Players)
{
	// NOTE: Not implemented for PFP
	return false;
}

void FOnlineSessionPlayFabParty::RegisterLocalPlayer(const FUniqueNetId& PlayerId, FName SessionName, const FOnRegisterLocalPlayerCompleteDelegate& Delegate)
{
	OSS_PFP_GET_NATIVE_SESSION_INTERFACE
	{
		return NativeSessionInterface->RegisterLocalPlayer(PlayerId, SessionName, Delegate);
	}
}

void FOnlineSessionPlayFabParty::UnregisterLocalPlayer(const FUniqueNetId& PlayerId, FName SessionName, const FOnUnregisterLocalPlayerCompleteDelegate& Delegate)
{
	OSS_PFP_GET_NATIVE_SESSION_INTERFACE
	{
		return NativeSessionInterface->UnregisterLocalPlayer(PlayerId, SessionName, Delegate);
	}
}

int32 FOnlineSessionPlayFabParty::GetNumSessions()
{
	OSS_PFP_GET_NATIVE_SESSION_INTERFACE
	{
		return NativeSessionInterface->GetNumSessions();
	}

	return 0;
}

void FOnlineSessionPlayFabParty::DumpSessionState()
{
	OSS_PFP_GET_NATIVE_SESSION_INTERFACE
	{
		NativeSessionInterface->DumpSessionState();
	}
}

FNamedOnlineSession* FOnlineSessionPlayFabParty::AddNamedSession(FName SessionName, const FOnlineSessionSettings& SessionSettings)
{
	UE_LOG_ONLINE(Error, TEXT("[FOnlineSessionPlayFabParty::AddNamedSession] This function is not implemented."));

	return nullptr;
}

FNamedOnlineSession* FOnlineSessionPlayFabParty::AddNamedSession(FName SessionName, const FOnlineSession& Session)
{
	UE_LOG_ONLINE(Error, TEXT("[FOnlineSessionPlayFabParty::AddNamedSession] This function is not implemented."));

	return nullptr;
}

FDelegateHandle FOnlineSessionPlayFabParty::AddOnCreateSessionCompleteDelegate_Handle(const FOnCreateSessionCompleteDelegate& Delegate)
{
	OSS_PFP_GET_NATIVE_SESSION_INTERFACE
	{
		return NativeSessionInterface->AddOnCreateSessionCompleteDelegate_Handle(Delegate);
	}

	return FDelegateHandle();
}

void FOnlineSessionPlayFabParty::ClearOnCreateSessionCompleteDelegate_Handle(FDelegateHandle& Handle)
{
	OSS_PFP_GET_NATIVE_SESSION_INTERFACE
	{
		NativeSessionInterface->ClearOnCreateSessionCompleteDelegate_Handle(Handle);
	}
}

void FOnlineSessionPlayFabParty::TriggerOnCreateSessionCompleteDelegates(FName SessionName, bool bWasSuccessful)
{
	if (bWasSuccessful == false)
	{
		// Leave the PlayFab Party network
		if (OSSPlayFabParty)
		{
			OSSPlayFabParty->LeavePlayFabPartyNetwork();
		}
	}

	OSS_PFP_GET_NATIVE_SESSION_INTERFACE
	{
		NativeSessionInterface->TriggerOnCreateSessionCompleteDelegates(SessionName, bWasSuccessful);
	}
}

FDelegateHandle FOnlineSessionPlayFabParty::AddOnStartSessionCompleteDelegate_Handle(const FOnStartSessionCompleteDelegate& Delegate)
{
	OSS_PFP_GET_NATIVE_SESSION_INTERFACE
	{
		return NativeSessionInterface->AddOnStartSessionCompleteDelegate_Handle(Delegate);
	}

	return FDelegateHandle();
}

void FOnlineSessionPlayFabParty::ClearOnStartSessionCompleteDelegate_Handle(FDelegateHandle& Handle)
{
	OSS_PFP_GET_NATIVE_SESSION_INTERFACE
	{
		NativeSessionInterface->ClearOnStartSessionCompleteDelegate_Handle(Handle);
	}
}

void FOnlineSessionPlayFabParty::TriggerOnStartSessionCompleteDelegates(FName Param1, bool Param2)
{
	OSS_PFP_GET_NATIVE_SESSION_INTERFACE
	{
		NativeSessionInterface->TriggerOnStartSessionCompleteDelegates(Param1, Param2);
	}
}

FDelegateHandle FOnlineSessionPlayFabParty::AddOnUpdateSessionCompleteDelegate_Handle(const FOnUpdateSessionCompleteDelegate& Delegate)
{
	OSS_PFP_GET_NATIVE_SESSION_INTERFACE
	{
		return NativeSessionInterface->AddOnUpdateSessionCompleteDelegate_Handle(Delegate);
	}

	return FDelegateHandle();
}

void FOnlineSessionPlayFabParty::ClearOnUpdateSessionCompleteDelegate_Handle(FDelegateHandle& Handle)
{
	OSS_PFP_GET_NATIVE_SESSION_INTERFACE
	{
		NativeSessionInterface->ClearOnUpdateSessionCompleteDelegate_Handle(Handle);
	}
}

void FOnlineSessionPlayFabParty::TriggerOnUpdateSessionCompleteDelegates(FName Param1, bool Param2)
{
	OSS_PFP_GET_NATIVE_SESSION_INTERFACE
	{
		NativeSessionInterface->TriggerOnUpdateSessionCompleteDelegates(Param1, Param2);
	}
}

FDelegateHandle FOnlineSessionPlayFabParty::AddOnEndSessionCompleteDelegate_Handle(const FOnEndSessionCompleteDelegate& Delegate)
{
	OSS_PFP_GET_NATIVE_SESSION_INTERFACE
	{
		return NativeSessionInterface->AddOnEndSessionCompleteDelegate_Handle(Delegate);
	}

	return FDelegateHandle();
}

void FOnlineSessionPlayFabParty::ClearOnEndSessionCompleteDelegate_Handle(FDelegateHandle& Handle)
{
	OSS_PFP_GET_NATIVE_SESSION_INTERFACE
	{
		NativeSessionInterface->ClearOnEndSessionCompleteDelegate_Handle(Handle);
	}
}

void FOnlineSessionPlayFabParty::TriggerOnEndSessionCompleteDelegates(FName Param1, bool Param2)
{
	OSS_PFP_GET_NATIVE_SESSION_INTERFACE
	{
		NativeSessionInterface->TriggerOnEndSessionCompleteDelegates(Param1, Param2);
	}
}

FDelegateHandle FOnlineSessionPlayFabParty::AddOnDestroySessionCompleteDelegate_Handle(const FOnDestroySessionCompleteDelegate& Delegate)
{
	OSS_PFP_GET_NATIVE_SESSION_INTERFACE
	{
		return NativeSessionInterface->AddOnDestroySessionCompleteDelegate_Handle(Delegate);
	}

	return FDelegateHandle();
}

void FOnlineSessionPlayFabParty::ClearOnDestroySessionCompleteDelegate_Handle(FDelegateHandle& Handle)
{
	OSS_PFP_GET_NATIVE_SESSION_INTERFACE
	{
		NativeSessionInterface->ClearOnDestroySessionCompleteDelegate_Handle(Handle);
	}
}

void FOnlineSessionPlayFabParty::TriggerOnDestroySessionCompleteDelegates(FName Param1, bool Param2)
{
	OSS_PFP_GET_NATIVE_SESSION_INTERFACE
	{
		NativeSessionInterface->TriggerOnDestroySessionCompleteDelegates(Param1, Param2);
	}
}

FDelegateHandle FOnlineSessionPlayFabParty::AddOnMatchmakingCompleteDelegate_Handle(const FOnMatchmakingCompleteDelegate& Delegate)
{
	OSS_PFP_GET_NATIVE_SESSION_INTERFACE
	{
		NativeSessionInterface->AddOnMatchmakingCompleteDelegate_Handle(Delegate);
	}

	return FDelegateHandle();
}

void FOnlineSessionPlayFabParty::ClearOnMatchmakingCompleteDelegate_Handle(FDelegateHandle& Handle)
{
	OSS_PFP_GET_NATIVE_SESSION_INTERFACE
	{
		NativeSessionInterface->ClearOnMatchmakingCompleteDelegate_Handle(Handle);
	}
}

void FOnlineSessionPlayFabParty::TriggerOnMatchmakingCompleteDelegates(FName Param1, bool Param2)
{
	OSS_PFP_GET_NATIVE_SESSION_INTERFACE
	{
		NativeSessionInterface->TriggerOnMatchmakingCompleteDelegates(Param1, Param2);
	}
}

FDelegateHandle FOnlineSessionPlayFabParty::AddOnCancelMatchmakingCompleteDelegate_Handle(const FOnCancelMatchmakingCompleteDelegate& Delegate)
{
	OSS_PFP_GET_NATIVE_SESSION_INTERFACE
	{
		return NativeSessionInterface->AddOnCancelMatchmakingCompleteDelegate_Handle(Delegate);
	}

	return FDelegateHandle();
}

void FOnlineSessionPlayFabParty::ClearOnCancelMatchmakingCompleteDelegate_Handle(FDelegateHandle& Handle)
{
	OSS_PFP_GET_NATIVE_SESSION_INTERFACE
	{
		NativeSessionInterface->ClearOnCancelMatchmakingCompleteDelegate_Handle(Handle);
	}
}

void FOnlineSessionPlayFabParty::TriggerOnCancelMatchmakingCompleteDelegates(FName Param1, bool Param2)
{
	OSS_PFP_GET_NATIVE_SESSION_INTERFACE
	{
		NativeSessionInterface->TriggerOnCancelMatchmakingCompleteDelegates(Param1, Param2);
	}
}

FDelegateHandle FOnlineSessionPlayFabParty::AddOnFindSessionsCompleteDelegate_Handle(const FOnFindSessionsCompleteDelegate& Delegate)
{
	OSS_PFP_GET_NATIVE_SESSION_INTERFACE
	{
		return NativeSessionInterface->AddOnFindSessionsCompleteDelegate_Handle(Delegate);
	}

	return FDelegateHandle();
}

void FOnlineSessionPlayFabParty::ClearOnFindSessionsCompleteDelegate_Handle(FDelegateHandle& Handle)
{
	OSS_PFP_GET_NATIVE_SESSION_INTERFACE
	{
		NativeSessionInterface->ClearOnFindSessionsCompleteDelegate_Handle(Handle);
	}
}

void FOnlineSessionPlayFabParty::TriggerOnFindSessionsCompleteDelegates(bool Param1)
{
	OSS_PFP_GET_NATIVE_SESSION_INTERFACE
	{
		NativeSessionInterface->TriggerOnFindSessionsCompleteDelegates(Param1);
	}
}

FDelegateHandle FOnlineSessionPlayFabParty::AddOnCancelFindSessionsCompleteDelegate_Handle(const FOnCancelFindSessionsCompleteDelegate& Delegate)
{
	OSS_PFP_GET_NATIVE_SESSION_INTERFACE
	{
		return NativeSessionInterface->AddOnCancelFindSessionsCompleteDelegate_Handle(Delegate);
	}

	return FDelegateHandle();
}

void FOnlineSessionPlayFabParty::ClearOnCancelFindSessionsCompleteDelegate_Handle(FDelegateHandle& Handle)
{
	OSS_PFP_GET_NATIVE_SESSION_INTERFACE
	{
		NativeSessionInterface->ClearOnCancelFindSessionsCompleteDelegate_Handle(Handle);
	}
}

void FOnlineSessionPlayFabParty::TriggerOnCancelFindSessionsCompleteDelegates(bool Param1)
{
	OSS_PFP_GET_NATIVE_SESSION_INTERFACE
	{
		NativeSessionInterface->TriggerOnCancelFindSessionsCompleteDelegates(Param1);
	}
}

FDelegateHandle FOnlineSessionPlayFabParty::AddOnPingSearchResultsCompleteDelegate_Handle(const FOnPingSearchResultsCompleteDelegate& Delegate)
{
	OSS_PFP_GET_NATIVE_SESSION_INTERFACE
	{
		return NativeSessionInterface->AddOnPingSearchResultsCompleteDelegate_Handle(Delegate);
	}

	return FDelegateHandle();
}

void FOnlineSessionPlayFabParty::ClearOnPingSearchResultsCompleteDelegate_Handle(FDelegateHandle& Handle)
{
	OSS_PFP_GET_NATIVE_SESSION_INTERFACE
	{
		NativeSessionInterface->ClearOnPingSearchResultsCompleteDelegate_Handle(Handle);
	}
}

void FOnlineSessionPlayFabParty::TriggerOnPingSearchResultsCompleteDelegates(bool Param1)
{
	OSS_PFP_GET_NATIVE_SESSION_INTERFACE
	{
		NativeSessionInterface->TriggerOnPingSearchResultsCompleteDelegates(Param1);
	}
}

FDelegateHandle FOnlineSessionPlayFabParty::AddOnJoinSessionCompleteDelegate_Handle(const FOnJoinSessionCompleteDelegate& Delegate)
{
	OSS_PFP_GET_NATIVE_SESSION_INTERFACE
	{
		return NativeSessionInterface->AddOnJoinSessionCompleteDelegate_Handle(Delegate);
	}

	return FDelegateHandle();
}

void FOnlineSessionPlayFabParty::ClearOnJoinSessionCompleteDelegate_Handle(FDelegateHandle& Handle)
{
	OSS_PFP_GET_NATIVE_SESSION_INTERFACE
	{
		NativeSessionInterface->ClearOnJoinSessionCompleteDelegate_Handle(Handle);
	}
}

void FOnlineSessionPlayFabParty::TriggerOnJoinSessionCompleteDelegates(FName Param1, EOnJoinSessionCompleteResult::Type Param2)
{
	OSS_PFP_GET_NATIVE_SESSION_INTERFACE
	{
		NativeSessionInterface->TriggerOnJoinSessionCompleteDelegates(Param1, Param2);
	}
}

FDelegateHandle FOnlineSessionPlayFabParty::AddOnFindFriendSessionCompleteDelegate_Handle(int32 LocalUserNum, const FOnFindFriendSessionCompleteDelegate& Delegate)
{
	OSS_PFP_GET_NATIVE_SESSION_INTERFACE
	{
		return NativeSessionInterface->AddOnFindFriendSessionCompleteDelegate_Handle(LocalUserNum, Delegate);
	}

	return FDelegateHandle();
}

void FOnlineSessionPlayFabParty::ClearOnFindFriendSessionCompleteDelegate_Handle(int32 LocalUserNum, FDelegateHandle& Handle)
{
	OSS_PFP_GET_NATIVE_SESSION_INTERFACE
	{
		NativeSessionInterface->ClearOnFindFriendSessionCompleteDelegate_Handle(LocalUserNum, Handle);
	}
}

void FOnlineSessionPlayFabParty::TriggerOnFindFriendSessionCompleteDelegates(int32 LocalUserNum, bool bWasSuccessful, const TArray<FOnlineSessionSearchResult>& SearchResult)
{
	OSS_PFP_GET_NATIVE_SESSION_INTERFACE
	{
		NativeSessionInterface->TriggerOnFindFriendSessionCompleteDelegates(LocalUserNum, bWasSuccessful, SearchResult);
	}
}

FDelegateHandle FOnlineSessionPlayFabParty::AddOnSessionUserInviteAcceptedDelegate_Handle(const FOnSessionUserInviteAcceptedDelegate& Delegate)
{
	OSS_PFP_GET_NATIVE_SESSION_INTERFACE
	{
		return NativeSessionInterface->AddOnSessionUserInviteAcceptedDelegate_Handle(Delegate);
	}

	return FDelegateHandle();
}

void FOnlineSessionPlayFabParty::ClearOnSessionUserInviteAcceptedDelegate_Handle(FDelegateHandle& Handle)
{
	OSS_PFP_GET_NATIVE_SESSION_INTERFACE
	{
		NativeSessionInterface->ClearOnSessionUserInviteAcceptedDelegate_Handle(Handle);
	}
}

void FOnlineSessionPlayFabParty::TriggerOnSessionUserInviteAcceptedDelegates(const bool bWasSuccessful, const int32 ControllerId, TSharedPtr<const FUniqueNetId> UserId, const FOnlineSessionSearchResult& InviteResult)
{
	OSS_PFP_GET_NATIVE_SESSION_INTERFACE
	{
		NativeSessionInterface->TriggerOnSessionUserInviteAcceptedDelegates(bWasSuccessful, ControllerId, UserId, InviteResult);
	}
}

FDelegateHandle FOnlineSessionPlayFabParty::AddOnSessionInviteReceivedDelegate_Handle(const FOnSessionInviteReceivedDelegate& Delegate)
{
	OSS_PFP_GET_NATIVE_SESSION_INTERFACE
	{
		return NativeSessionInterface->AddOnSessionInviteReceivedDelegate_Handle(Delegate);
	}

	return FDelegateHandle();
}

void FOnlineSessionPlayFabParty::ClearOnSessionInviteReceivedDelegate_Handle(FDelegateHandle& Handle)
{
	OSS_PFP_GET_NATIVE_SESSION_INTERFACE
	{
		NativeSessionInterface->ClearOnSessionInviteReceivedDelegate_Handle(Handle);
	}
}

void FOnlineSessionPlayFabParty::TriggerOnSessionInviteReceivedDelegates(const FUniqueNetId& UserId, const FUniqueNetId& FromId, const FString& AppId, const FOnlineSessionSearchResult& InviteResult)
{
	OSS_PFP_GET_NATIVE_SESSION_INTERFACE
	{
		NativeSessionInterface->TriggerOnSessionInviteReceivedDelegates(UserId, FromId, AppId, InviteResult);
	}
}

FDelegateHandle FOnlineSessionPlayFabParty::AddOnRegisterPlayersCompleteDelegate_Handle(const FOnRegisterPlayersCompleteDelegate& Delegate)
{
	OSS_PFP_GET_NATIVE_SESSION_INTERFACE
	{
		return NativeSessionInterface->AddOnRegisterPlayersCompleteDelegate_Handle(Delegate);
	}

	return FDelegateHandle();
}

void FOnlineSessionPlayFabParty::ClearOnRegisterPlayersCompleteDelegate_Handle(FDelegateHandle& Handle)
{
	OSS_PFP_GET_NATIVE_SESSION_INTERFACE
	{
		NativeSessionInterface->ClearOnRegisterPlayersCompleteDelegate_Handle(Handle);
	}
}

void FOnlineSessionPlayFabParty::TriggerOnRegisterPlayersCompleteDelegates(FName Param1, const TArray< TSharedRef<const FUniqueNetId> >& Param2, bool Param3)
{
	OSS_PFP_GET_NATIVE_SESSION_INTERFACE
	{
		NativeSessionInterface->TriggerOnRegisterPlayersCompleteDelegates(Param1, Param2, Param3);
	}
}

FDelegateHandle FOnlineSessionPlayFabParty::AddOnUnregisterPlayersCompleteDelegate_Handle(const FOnUnregisterPlayersCompleteDelegate& Delegate)
{
	OSS_PFP_GET_NATIVE_SESSION_INTERFACE
	{
		return NativeSessionInterface->AddOnUnregisterPlayersCompleteDelegate_Handle(Delegate);
	}

	return FDelegateHandle();
}

void FOnlineSessionPlayFabParty::ClearOnUnregisterPlayersCompleteDelegate_Handle(FDelegateHandle& Handle)
{
	OSS_PFP_GET_NATIVE_SESSION_INTERFACE
	{
		NativeSessionInterface->ClearOnUnregisterPlayersCompleteDelegate_Handle(Handle);
	}
}

void FOnlineSessionPlayFabParty::TriggerOnUnregisterPlayersCompleteDelegates(FName Param1, const TArray< TSharedRef<const FUniqueNetId> >& Param2, bool Param3)
{
	OSS_PFP_GET_NATIVE_SESSION_INTERFACE
	{
		NativeSessionInterface->TriggerOnUnregisterPlayersCompleteDelegates(Param1, Param2, Param3);
	}
}

FDelegateHandle FOnlineSessionPlayFabParty::AddOnSessionFailureDelegate_Handle(const FOnSessionFailureDelegate& Delegate)
{
	OSS_PFP_GET_NATIVE_SESSION_INTERFACE
	{
		return NativeSessionInterface->AddOnSessionFailureDelegate_Handle(Delegate);
	}

	return FDelegateHandle();
}

void FOnlineSessionPlayFabParty::ClearOnSessionFailureDelegate_Handle(FDelegateHandle& Handle)
{
	OSS_PFP_GET_NATIVE_SESSION_INTERFACE
	{
		NativeSessionInterface->ClearOnSessionFailureDelegate_Handle(Handle);
	}
}

void FOnlineSessionPlayFabParty::TriggerOnSessionFailureDelegates(const FUniqueNetId& Param1, ESessionFailure::Type Param2)
{
	OSS_PFP_GET_NATIVE_SESSION_INTERFACE
	{
		NativeSessionInterface->TriggerOnSessionFailureDelegates(Param1, Param2);
	}
}