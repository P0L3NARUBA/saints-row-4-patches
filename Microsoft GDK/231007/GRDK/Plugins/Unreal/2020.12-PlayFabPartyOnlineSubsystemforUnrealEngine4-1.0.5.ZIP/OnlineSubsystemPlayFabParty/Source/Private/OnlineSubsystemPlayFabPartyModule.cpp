//--------------------------------------------------------------------------------------
// Copyright (C) Microsoft Corporation. All rights reserved.
//--------------------------------------------------------------------------------------

#include "OnlineSubsystemPlayFabPartyModule.h"
#include "CoreMinimal.h"
#include "Misc/Paths.h"
#include "Misc/CommandLine.h"
#include "Modules/ModuleManager.h"
#include "OnlineSubsystemModule.h"
#include "OnlineSubsystemNames.h"
#include "OnlineSubsystem.h"
#include "OnlineSubsystemPlayFabParty.h"
#include "HAL/PlatformProcess.h"

IMPLEMENT_MODULE(FOnlineSubsystemPlayFabPartyModule, OnlineSubsystemPlayFabParty);

 // Class responsible for creating instance(s) of the subsystem
class FOnlineFactoryPlayFabParty : public IOnlineFactory
{

private:

	// Single instantiation of the PlayFabParty interface
	FOnlineSubsystemPlayFabPartyPtr& GetSingleton() const
	{
		static FOnlineSubsystemPlayFabPartyPtr PlayFabPartySingleton;
		return PlayFabPartySingleton;
	}

	virtual void DestroySubsystem()
	{
		FOnlineSubsystemPlayFabPartyPtr& PlayFabPartySingleton = GetSingleton();
		if (PlayFabPartySingleton.IsValid())
		{
			PlayFabPartySingleton->Shutdown();
			PlayFabPartySingleton.Reset();
		}
	}

public:

	FOnlineFactoryPlayFabParty() {}
	virtual ~FOnlineFactoryPlayFabParty() 
	{
		DestroySubsystem();
	}

	virtual IOnlineSubsystemPtr CreateSubsystem(FName InstanceName) override
	{
		FOnlineSubsystemPlayFabPartyPtr& PlayFabPartySingleton = GetSingleton();
		if (PlayFabPartySingleton.IsValid())
		{
			UE_LOG_ONLINE(Warning, TEXT("Can't create more than one instance of PlayFabParty online subsystem!"));
			return nullptr;
		}

		PlayFabPartySingleton = MakeShared<FOnlineSubsystemPlayFabParty, ESPMode::ThreadSafe>(InstanceName);
		if (PlayFabPartySingleton->IsEnabled())
		{
			if (!PlayFabPartySingleton->Init())
			{
				UE_LOG_ONLINE(Warning, TEXT("PlayFabParty API failed to initialize!"));
				DestroySubsystem();
				return nullptr;
			}
		}
		else
		{
			UE_LOG_ONLINE(Warning, TEXT("PlayFabParty API disabled!"));
			DestroySubsystem();
			return nullptr;
		}

		return PlayFabPartySingleton;
	}
};

void FOnlineSubsystemPlayFabPartyModule::StartupModule()
{
	// Create and register our singleton factory with the main online subsystem for easy access
	PlayFabPartyFactory = new FOnlineFactoryPlayFabParty();

	FOnlineSubsystemModule& OSS = FModuleManager::GetModuleChecked<FOnlineSubsystemModule>("OnlineSubsystem");
	OSS.RegisterPlatformService(PLAYFABPARTY_SUBSYSTEM, PlayFabPartyFactory);
}

void FOnlineSubsystemPlayFabPartyModule::ShutdownModule()
{
	FOnlineSubsystemModule& OSS = FModuleManager::GetModuleChecked<FOnlineSubsystemModule>("OnlineSubsystem");
	OSS.UnregisterPlatformService(PLAYFABPARTY_SUBSYSTEM);

	delete PlayFabPartyFactory;
	PlayFabPartyFactory = nullptr;
}