//--------------------------------------------------------------------------------------
// Copyright (C) Microsoft Corporation. All rights reserved.
//--------------------------------------------------------------------------------------

#include "PlayFabPartyNetDriver.h"
#include "SocketSubsystem.h"
#include "PlayFabPartySocketSubsystem.h"
#include "OnlineSubsystemPlayFabParty.h"
#include "OnlineSubsystemPlayFabPartyPrivate.h"
#include "OnlineSubsystemSessionSettings.h"
#include "PlayFabPartySocket.h"

UPlayFabPartyNetDriver::UPlayFabPartyNetDriver(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
}

class ISocketSubsystem* UPlayFabPartyNetDriver::GetSocketSubsystem()
{
	return ISocketSubsystem::Get(PLAYFABPARTY_SOCKET_SUBSYSTEM);
}

bool UPlayFabPartyNetDriver::IsAvailable() const
{
	IOnlineSubsystem* OSSPlayFabParty = IOnlineSubsystem::Get(PLAYFABPARTY_SUBSYSTEM);
	if (OSSPlayFabParty)
	{
		ISocketSubsystem* PlayFabPartySocketSubsystem = ISocketSubsystem::Get(PLAYFABPARTY_SOCKET_SUBSYSTEM);
		if (PlayFabPartySocketSubsystem)
		{
			return true;
		}
	}

	return false;
}

bool UPlayFabPartyNetDriver::InitBase(bool bInitAsClient, FNetworkNotify* InNotify, const FURL& URL, bool bReuseAddressAndPort, FString& Error)
{
	if (FOnlineSubsystemPlayFabParty* OSSPlayFabParty = GetOnlineSubsystemPlayFabParty())
	{
		if (FPlayFabPartySocketSubsystem* SocketSubsystem = GetPlayFabPartySocketSubsystem())
		{
			FUniqueSocket NewSocket = CreateSocketForProtocol(FNetworkProtocolTypes::PlayFabParty);
			SetSocketAndLocalAddress(NewSocket.Release());

			SocketSubsystem->LinkNetDriver(this);

			if (UNetDriver::InitBase(bInitAsClient, InNotify, URL, bReuseAddressAndPort, Error))
			{
				return true;
			}
		}
	}

	return false;
}

bool UPlayFabPartyNetDriver::InitListen(FNetworkNotify* InNotify, FURL& LocalURL, bool bReuseAddressAndPort, FString& Error)
{
	return Super::InitListen(InNotify, LocalURL, bReuseAddressAndPort, Error);
}

bool UPlayFabPartyNetDriver::InitConnect(FNetworkNotify* InNotify, const FURL& InConnectURL, FString& Error)
{
	return Super::InitConnect(InNotify, InConnectURL, Error);
}

void UPlayFabPartyNetDriver::Shutdown()
{
	UE_LOG(LogSockets, Verbose, TEXT("PlayFabPartyNetDriver: Shutdown called on netdriver"));

	Super::Shutdown();
}

void UPlayFabPartyNetDriver::TickDispatch(float DeltaTime)
{
	Super::TickDispatch(DeltaTime);
}

FOnlineSubsystemPlayFabParty* UPlayFabPartyNetDriver::GetOnlineSubsystemPlayFabParty()
{
	return static_cast<FOnlineSubsystemPlayFabParty*>(IOnlineSubsystem::Get(PLAYFABPARTY_SUBSYSTEM));
}

FPlayFabPartySocketSubsystem* UPlayFabPartyNetDriver::GetPlayFabPartySocketSubsystem()
{
	return static_cast<FPlayFabPartySocketSubsystem*>(GetSocketSubsystem());
}