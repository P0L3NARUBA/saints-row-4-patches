//--------------------------------------------------------------------------------------
// Copyright (C) Microsoft Corporation. All rights reserved.
//--------------------------------------------------------------------------------------
#pragma once

#include "HAL/Platform.h"
PRAGMA_DISABLE_UNDEFINED_IDENTIFIER_WARNINGS

#if PFPOSS_WINGDK || PFPOSS_XSX || PFPOSS_XBOXONEGDK
#include "PlatformDefines.h"

#include "OnlineSubsystemPlayFabParty.h"

#include "XNetworking.h"
#include <XGameRuntimeFeature.h>

namespace
{
	XTaskQueueRegistrationToken NetworkInitRegistration;
}

void FOnlineSubsystemPlayFabParty::RegisterNetworkInitCallbacks()
{
	UE_LOG_ONLINE(Verbose, TEXT("FOnlineSubsystemPlayFabParty::RegisterNetworkInitCallbacks"));

	XNetworkingRegisterConnectivityHintChanged(nullptr, this, [](void* Context, const XNetworkingConnectivityHint* ConnectivityHint)
	{
		FOnlineSubsystemPlayFabParty* OSS = reinterpret_cast<FOnlineSubsystemPlayFabParty*>(Context);
		if (OSS)
		{
			// if the new value is different than the old value
			if (ConnectivityHint->networkInitialized != OSS->bNetworkInitialized)
			{
				UE_LOG_ONLINE(Verbose, TEXT("FOnlineSubsystemPlayFabParty: ConnectivityHint.networkInitialized changed: %s"), ConnectivityHint->networkInitialized ? TEXT("true") : TEXT("false"));

				OSS->bNetworkInitialized = ConnectivityHint->networkInitialized;

				if (OSS->bNetworkInitialized)
				{
					OSS->InitializePlayFabParty();
				}
			}
		}
	}, 
	& NetworkInitRegistration);
}

void FOnlineSubsystemPlayFabParty::UnregisterNetworkInitCallbacks()
{
	UE_LOG_ONLINE(Verbose, TEXT("FOnlineSubsystemPlayFabParty::UnregisterNetworkInitCallbacks"));

	XNetworkingUnregisterConnectivityHintChanged(NetworkInitRegistration, true);
}

void FOnlineSubsystemPlayFabParty::TryInitializePlayFabParty()
{
	UE_LOG_ONLINE(Verbose, TEXT("FOnlineSubsystemPlayFabParty::TryInitializePlayFabParty"));

	if (XGameRuntimeIsFeatureAvailable(XGameRuntimeFeature::XNetworking))
	{
		XNetworkingConnectivityHint ConnectivityHint;

		auto Hr = XNetworkingGetConnectivityHint(&ConnectivityHint);

		if (SUCCEEDED(Hr))
		{
			if (ConnectivityHint.networkInitialized)
			{
				bNetworkInitialized = true;

				InitializePlayFabParty();
			}
			else
			{
				UE_LOG_ONLINE(Verbose, TEXT("FOnlineSubsystemPlayFabParty::TryInitializePlayFabParty: ConnectivityHint.networkInitialized was false, waiting to initialize PlayFab Party"));
			}
		}
	}
}
#endif