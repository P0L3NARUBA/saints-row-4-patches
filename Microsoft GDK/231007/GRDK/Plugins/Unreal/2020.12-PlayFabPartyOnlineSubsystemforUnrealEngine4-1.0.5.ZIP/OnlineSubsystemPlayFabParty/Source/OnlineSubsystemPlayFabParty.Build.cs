//--------------------------------------------------------------------------------------
// Advanced Technology Group (ATG)
// Copyright (C) Microsoft Corporation. All rights reserved.
//--------------------------------------------------------------------------------------

using UnrealBuildTool;
using System;
using System.IO;
using Tools.DotNETCommon;

public class OnlineSubsystemPlayFabParty : ModuleRules
{
	private void SetupPlatformDefine(UnrealTargetPlatform TargetPlatform)
	{
		PublicDefinitions.Add(String.Format("PFPOSS_{0}=1", TargetPlatform.ToString().ToUpper()));
		Log.TraceInformation("OnlineSubsystemPlayfabParty: building for platform {0}", TargetPlatform.ToString().ToUpper());
	}

	public OnlineSubsystemPlayFabParty(ReadOnlyTargetRules Target) : base(Target)
	{
		// We don't want to try and load when doing project gen, editor, server, etc
		if (Target.bGenerateProjectFiles || (Target.Type != TargetType.Game && Target.Type != TargetType.Client))
		{
			return;
		}

		string PFPartyExtensionPath = string.Empty;
		string PFPartyRedistPath = string.Empty;
		string PFPartyXblExtensionPath = string.Empty;
		string PFPartyXblRedistPath = string.Empty;
		bool bPlatformHasPartyBundled = false;

		SetupPlatformDefine(Target.Platform);

		// Use the Platforms folder libs if available, these are not included by default so should be considered an override if present.
		string PlatformDirName = "UNKNOWN";
		if (Target.Platform.IsInGroup(UnrealPlatformGroup.GDK))
		{
			PlatformDirName = "GDK";
			bPlatformHasPartyBundled = true;
		}
		else if (Target.Platform == UnrealTargetPlatform.XboxOne)
		{
			PlatformDirName = "XDK";
		}

		string PlatformDir = Path.Combine(Directory.GetCurrentDirectory(), "..", "Plugins", "Online", "OnlineSubsystemPlayFabParty", "Platforms", PlatformDirName);

		if (Target.Platform == UnrealBuildTool.UnrealTargetPlatform.WinGDK)
		{
			PublicDefinitions.Add("PFP_OSS_IS_PC=1");
		}
		else
		{
			PublicDefinitions.Add("PFP_OSS_IS_PC=0");
		}

		// For debugging purposes
		PublicDefinitions.Add("PFP_OSS_VERBOSE_VOIP_LOGGING=0");
		PublicDefinitions.Add("PFP_OSS_VERBOSE_PACKET_LEVEL_LOGGING=0");

		if (Directory.Exists(PlatformDir) && Directory.Exists(Path.Combine(PlatformDir, "Lib")) && Directory.Exists(Path.Combine(PlatformDir, "Redist")) && Directory.Exists(Path.Combine(PlatformDir, "Include")))
		{
			PFPartyXblExtensionPath = PFPartyExtensionPath = PlatformDir;
			PFPartyXblRedistPath = PFPartyRedistPath = Path.Combine(PlatformDir, "Redist");

			Log.TraceInformation("OnlineSubsystemPlayfabParty: Using Party library provided as an override.");

		}
		else if (bPlatformHasPartyBundled) // Use GDK version
		{
			PFPartyExtensionPath = GDKExports.GetExtensionDirectory("PlayFab.Party.Cpp", false);
			PFPartyRedistPath = GDKExports.GetExtensionDirectory("PlayFab.Party.Cpp", true);

			if (!Directory.Exists(PFPartyExtensionPath) || !Directory.Exists(PFPartyRedistPath))
			{
				throw new BuildException("PlayFab Party was not found. Please validate your GDK installation or provide an override library.");
			}

			Log.TraceInformation("OnlineSubsystemPlayfabParty: Using Party library from GDK installation at {0}", PFPartyExtensionPath);

			PFPartyXblExtensionPath = GDKExports.GetExtensionDirectory("PlayFab.PartyXboxLive.Cpp", false);
			PFPartyXblRedistPath = GDKExports.GetExtensionDirectory("PlayFab.PartyXboxLive.Cpp", true);

			if (!Directory.Exists(PFPartyXblExtensionPath) || !Directory.Exists(PFPartyXblRedistPath))
			{
				throw new BuildException("PlayFab Party XboxLive Extension was not found. Please validate your GDK installation or provide an override library.");
			}

			Log.TraceInformation("OnlineSubsystemPlayfabParty: Using Party XboxLive library from GDK installation at {0}", PFPartyXblExtensionPath);
		}
		else
		{
			throw new BuildException("PlayFab Party was not found. This platforms SDK does not have PlayFab Party bundled with it, and you have not provided an override library.");
		}


		string PFPartyIncludePath = Path.Combine(PFPartyExtensionPath, "Include");
		string PFPartyLibraryPath = Path.Combine(PFPartyExtensionPath, "Lib");
		string PFPartyXblIncludePath = Path.Combine(PFPartyXblExtensionPath, "Include");
		string PFPartyXblLibraryPath = Path.Combine(PFPartyXblExtensionPath, "Lib");

		PrivateDefinitions.Add("ONLINESUBSYSTEMPLAYFABPARTY_PACKAGE=1");
		PCHUsage = ModuleRules.PCHUsageMode.UseExplicitOrSharedPCHs;

		PublicSystemIncludePaths.Add(PFPartyIncludePath);
		PublicSystemIncludePaths.Add(PFPartyXblIncludePath);

		// We need party.lib, this is either in the GDK, or via Platforms override
		PublicSystemLibraries.Add(Path.Combine(PFPartyLibraryPath, "Party.lib"));
		PublicSystemLibraries.Add(Path.Combine(PFPartyXblLibraryPath, "PartyXboxLive.lib"));

		PublicDependencyModuleNames.AddRange(
			new string[] {
				"OnlineSubsystemUtils"
			}
		);

		PrivateDependencyModuleNames.AddRange(
			new string[] {
				"Core",
				"CoreUObject",
				"NetCore",
				"Engine",
				"Sockets",
				"Voice",
				"AudioMixer",
				"OnlineSubsystem",
				"Json",
				"PacketHandler",
				"Projects",
				"HTTP"
			}
		);

		// GDK is everything gamecore.
		if (Target.Platform.IsInGroup(UnrealPlatformGroup.GDK))
		{
			PublicDependencyModuleNames.Add("GDKCore");
			PublicDependencyModuleNames.Add("OnlineSubsystemGDK");
		}
		else if (Target.Platform == UnrealTargetPlatform.XboxOne)
		{
			PublicDependencyModuleNames.Add("OnlineSubsystemLive");
		}

		RuntimeDependencies.Add("$(TargetOutputDir)/Party.dll", Path.Combine(PFPartyRedistPath, "Party.dll"), StagedFileType.SystemNonUFS);
		RuntimeDependencies.Add("$(TargetOutputDir)/Party.pdb", Path.Combine(PFPartyRedistPath, "Party.pdb"), StagedFileType.DebugNonUFS);

		RuntimeDependencies.Add("$(TargetOutputDir)/PartyXboxLive.dll", Path.Combine(PFPartyXblRedistPath, "PartyXboxLive.dll"), StagedFileType.SystemNonUFS);
		RuntimeDependencies.Add("$(TargetOutputDir)/PartyXboxLive.pdb", Path.Combine(PFPartyXblRedistPath, "PartyXboxLive.pdb"), StagedFileType.DebugNonUFS);
	}
}
