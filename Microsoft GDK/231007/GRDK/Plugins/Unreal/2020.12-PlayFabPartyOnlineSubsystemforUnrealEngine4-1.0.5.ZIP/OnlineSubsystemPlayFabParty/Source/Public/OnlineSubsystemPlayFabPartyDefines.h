//--------------------------------------------------------------------------------------
// Copyright (C) Microsoft Corporation. All rights reserved.
//--------------------------------------------------------------------------------------

#pragma once

#include "OnlineSubsystemTypes.h"

#ifndef PLAYFABPARTY_SUBSYSTEM
#define PLAYFABPARTY_SUBSYSTEM FName(TEXT("PLAYFABPARTY"))
#endif