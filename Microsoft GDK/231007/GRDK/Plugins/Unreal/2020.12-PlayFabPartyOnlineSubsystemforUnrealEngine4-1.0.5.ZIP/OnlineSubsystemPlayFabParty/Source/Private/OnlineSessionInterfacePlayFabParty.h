//--------------------------------------------------------------------------------------
// Copyright (C) Microsoft Corporation. All rights reserved.
//--------------------------------------------------------------------------------------

#pragma once

#include "Interfaces/OnlineSessionInterface.h"
#include "OnlineSubsystemPlayFabPartyDefines.h"
#include "OnlineSubsystemPlayFabPartyPackage.h"
#include "OnlineSessionSettings.h"

using FNamedOnlineSessionRef = TSharedRef<FNamedOnlineSession, ESPMode::ThreadSafe>;
using FNamedOnlineSessionPtr = TSharedPtr<FNamedOnlineSession, ESPMode::ThreadSafe>;

class FInternetAddr;
class FUniqueNetIdPlayFab;

struct FPendingCreateSessionInfo
{
	int32 PlayerControllerIndex = INDEX_NONE;
	TSharedPtr<const FUniqueNetId> PlayerId;
	FName SessionName;
	FOnlineSessionSettings SessionSettings;
};

struct FPendingJoinSessionInfo
{
	int32 PlayerControllerIndex = INDEX_NONE;
	TSharedPtr<const FUniqueNetId> PlayerId;
	FName SessionName;
	FOnlineSessionSearchResult SessionSearchResult;
};

class FOnlineSessionPlayFabParty : public IOnlineSession
{
public:
	FOnlineSessionPlayFabParty(class FOnlineSubsystemPlayFabParty* InSubsystem);
	virtual ~FOnlineSessionPlayFabParty();

	// IOnlineSession interface
	virtual TSharedPtr<const FUniqueNetId> CreateSessionIdFromString(const FString& SessionIdStr) override;
	virtual FNamedOnlineSession* GetNamedSession(FName SessionName) override;

	virtual void RemoveNamedSession(FName SessionName) override;
	virtual bool HasPresenceSession() override;
	virtual EOnlineSessionState::Type GetSessionState(FName SessionName) const override;
	virtual bool CreateSession(int32 HostingPlayerControllerIndex, FName SessionName, const FOnlineSessionSettings& NewSessionSettings) override;
	virtual bool CreateSession(const FUniqueNetId& HostingPlayerId, FName SessionName, const FOnlineSessionSettings& NewSessionSettings) override;
	virtual bool StartSession(FName SessionName) override;
	virtual bool UpdateSession(FName SessionName, FOnlineSessionSettings& UpdatedSessionSettings, bool bShouldRefreshOnlineData = false)  override;
	virtual bool EndSession(FName SessionName) override;
	virtual bool DestroySession(FName SessionName, const FOnDestroySessionCompleteDelegate& CompletionDelegate = FOnDestroySessionCompleteDelegate()) override;
	virtual bool IsPlayerInSession(FName SessionName, const FUniqueNetId& UniqueId) override;
	virtual bool StartMatchmaking(const TArray< TSharedRef<const FUniqueNetId> >& LocalPlayers, FName SessionName, const FOnlineSessionSettings& NewSessionSettings, TSharedRef<FOnlineSessionSearch>& SearchSettings) override;
	virtual bool CancelMatchmaking(int32 SearchingPlayerNum, FName SessionName) override;
	virtual bool CancelMatchmaking(const FUniqueNetId& SearchingPlayerId, FName SessionName) override;
	virtual bool FindSessions(int32 SearchingPlayerNum, const TSharedRef<FOnlineSessionSearch>& SearchSettings) override;
	virtual bool FindSessions(const FUniqueNetId& SearchingPlayerId, const TSharedRef<FOnlineSessionSearch>& SearchSettings) override;
	virtual bool FindSessionById(const FUniqueNetId& SearchingUserId, const FUniqueNetId& SessionId, const FUniqueNetId& FriendId, const FOnSingleSessionResultCompleteDelegate& CompletionDelegate) override;
	virtual bool CancelFindSessions() override;
	virtual bool PingSearchResults(const FOnlineSessionSearchResult& SearchResult) override;
	virtual bool JoinSession(int32 ControllerIndex, FName SessionName, const FOnlineSessionSearchResult& DesiredSession) override;
	virtual bool JoinSession(const FUniqueNetId& UserId, FName SessionName, const FOnlineSessionSearchResult& DesiredSession) override;
	virtual bool FindFriendSession(int32 LocalUserNum, const FUniqueNetId& Friend) override;
	virtual bool FindFriendSession(const FUniqueNetId& LocalUserId, const FUniqueNetId& Friend) override;
	virtual bool FindFriendSession(const FUniqueNetId& LocalUserId, const TArray<TSharedRef<const FUniqueNetId>>& FriendList) override;
	virtual bool SendSessionInviteToFriend(int32 LocalUserNum, FName SessionName, const FUniqueNetId& Friend) override;
	virtual bool SendSessionInviteToFriend(const FUniqueNetId& LocalUserId, FName SessionName, const FUniqueNetId& Friend) override;
	virtual bool SendSessionInviteToFriends(int32 LocalUserNum, FName SessionName, const TArray< TSharedRef<const FUniqueNetId> >& Friends) override;
	virtual bool SendSessionInviteToFriends(const FUniqueNetId& LocalUserId, FName SessionName, const TArray< TSharedRef<const FUniqueNetId> >& Friends) override;
	virtual bool GetResolvedConnectString(FName SessionName, FString& ConnectInfo, FName PortType)  override;
	virtual bool GetResolvedConnectString(const class FOnlineSessionSearchResult& SearchResult, FName PortType, FString& ConnectInfo)  override;
	virtual FOnlineSessionSettings* GetSessionSettings(FName SessionName) override;
	virtual bool RegisterPlayer(FName SessionName, const FUniqueNetId& PlayerId, bool bWasInvited)  override;
	virtual bool RegisterPlayers(FName SessionName, const TArray< TSharedRef<const FUniqueNetId> >& Players, bool bWasInvited = false)  override;
	virtual bool UnregisterPlayer(FName SessionName, const FUniqueNetId& PlayerId)  override;
	virtual bool UnregisterPlayers(FName SessionName, const TArray< TSharedRef<const FUniqueNetId> >& Players)  override;
	virtual void RegisterLocalPlayer(const FUniqueNetId& PlayerId, FName SessionName, const FOnRegisterLocalPlayerCompleteDelegate& Delegate) override;
	virtual void UnregisterLocalPlayer(const FUniqueNetId& PlayerId, FName SessionName, const FOnUnregisterLocalPlayerCompleteDelegate& Delegate) override;
	virtual int32 GetNumSessions() override;
	virtual void DumpSessionState() override;

protected:
	// IOnlineSession interface
	FNamedOnlineSession* AddNamedSession(FName SessionName, const FOnlineSessionSettings& SessionSettings) override;
	FNamedOnlineSession* AddNamedSession(FName SessionName, const FOnlineSession& Session) override;

	bool JoinSession_PlayFabInternal(const FOnlineSessionSearchResult& DesiredSession);

	void OnConnectToNetworkCompleted(bool bSuccess);
	void OnCreatePartyEndpoint(bool bSuccess, uint16 EndpointID, bool bIsHosting);

	class FOnlineSubsystemPlayFabParty* OSSPlayFabParty = nullptr;

	FPendingCreateSessionInfo PendingCreateSessionInfo;
	FPendingJoinSessionInfo PendingJoinSessionInfo;

	FDelegateHandle OnJoinSessionCompleteDelegateHandle;
	void OnJoinSessionComplete(FName InSessionName, EOnJoinSessionCompleteResult::Type Result);

public:
	// OnCreateSessionComplete
	virtual FDelegateHandle AddOnCreateSessionCompleteDelegate_Handle(const FOnCreateSessionCompleteDelegate& Delegate) override;
	virtual void ClearOnCreateSessionCompleteDelegate_Handle(FDelegateHandle& Handle) override;
	virtual void TriggerOnCreateSessionCompleteDelegates(FName SessionName, bool bWasSuccessful) override;

	// OnStartSessionComplete
	virtual FDelegateHandle AddOnStartSessionCompleteDelegate_Handle(const FOnStartSessionCompleteDelegate& Delegate) override;
	virtual void ClearOnStartSessionCompleteDelegate_Handle(FDelegateHandle& Handle) override;
	virtual void TriggerOnStartSessionCompleteDelegates(FName Param1, bool Param2) override;

	// OnUpdateSessionComplete
	virtual FDelegateHandle AddOnUpdateSessionCompleteDelegate_Handle(const FOnUpdateSessionCompleteDelegate& Delegate) override;
	virtual void ClearOnUpdateSessionCompleteDelegate_Handle(FDelegateHandle& Handle) override;
	virtual void TriggerOnUpdateSessionCompleteDelegates(FName Param1, bool Param2) override;

	// OnEndSessionComplete
	virtual FDelegateHandle AddOnEndSessionCompleteDelegate_Handle(const FOnEndSessionCompleteDelegate& Delegate) override;
	virtual void ClearOnEndSessionCompleteDelegate_Handle(FDelegateHandle& Handle) override;
	virtual void TriggerOnEndSessionCompleteDelegates(FName Param1, bool Param2) override;

	// OnDestroySessionComplete
	virtual FDelegateHandle AddOnDestroySessionCompleteDelegate_Handle(const FOnDestroySessionCompleteDelegate& Delegate) override;
	virtual void ClearOnDestroySessionCompleteDelegate_Handle(FDelegateHandle& Handle) override;
	virtual void TriggerOnDestroySessionCompleteDelegates(FName Param1, bool Param2) override;

	// OnMatchmakingComplete
	virtual FDelegateHandle AddOnMatchmakingCompleteDelegate_Handle(const FOnMatchmakingCompleteDelegate& Delegate) override;
	virtual void ClearOnMatchmakingCompleteDelegate_Handle(FDelegateHandle& Handle) override;
	virtual void TriggerOnMatchmakingCompleteDelegates(FName Param1, bool Param2) override;

	// OnCancelMatchmakingComplete
	virtual FDelegateHandle AddOnCancelMatchmakingCompleteDelegate_Handle(const FOnCancelMatchmakingCompleteDelegate& Delegate) override;
	virtual void ClearOnCancelMatchmakingCompleteDelegate_Handle(FDelegateHandle& Handle) override;
	virtual void TriggerOnCancelMatchmakingCompleteDelegates(FName Param1, bool Param2) override;

	// OnFindSessionsComplete
	virtual FDelegateHandle AddOnFindSessionsCompleteDelegate_Handle(const FOnFindSessionsCompleteDelegate& Delegate) override;
	virtual void ClearOnFindSessionsCompleteDelegate_Handle(FDelegateHandle& Handle) override;
	virtual void TriggerOnFindSessionsCompleteDelegates(bool Param1) override;

	// OnCancelFindSessionsComplete
	virtual FDelegateHandle AddOnCancelFindSessionsCompleteDelegate_Handle(const FOnCancelFindSessionsCompleteDelegate& Delegate) override;
	virtual void ClearOnCancelFindSessionsCompleteDelegate_Handle(FDelegateHandle& Handle) override;
	virtual void TriggerOnCancelFindSessionsCompleteDelegates(bool Param1) override;

	// OnPingSearchResultsComplete
	virtual FDelegateHandle AddOnPingSearchResultsCompleteDelegate_Handle(const FOnPingSearchResultsCompleteDelegate& Delegate) override;
	virtual void ClearOnPingSearchResultsCompleteDelegate_Handle(FDelegateHandle& Handle) override;
	virtual void TriggerOnPingSearchResultsCompleteDelegates(bool Param1) override;

	// OnJoinSessionComplete
	virtual FDelegateHandle AddOnJoinSessionCompleteDelegate_Handle(const FOnJoinSessionCompleteDelegate& Delegate) override;
	virtual void ClearOnJoinSessionCompleteDelegate_Handle(FDelegateHandle& Handle) override;
	virtual void TriggerOnJoinSessionCompleteDelegates(FName Param1, EOnJoinSessionCompleteResult::Type Param2) override;

	// OnFindFriendSessionComplete
	virtual FDelegateHandle AddOnFindFriendSessionCompleteDelegate_Handle(int32 LocalUserNum, const FOnFindFriendSessionCompleteDelegate& Delegate) override;
	virtual void ClearOnFindFriendSessionCompleteDelegate_Handle(int32 LocalUserNum, FDelegateHandle& Handle) override;
	virtual void TriggerOnFindFriendSessionCompleteDelegates(int32 LocalUserNum, bool bWasSuccessful, const TArray<FOnlineSessionSearchResult>& SearchResult) override;

	// OnSessionUserInviteAccepted
	virtual FDelegateHandle AddOnSessionUserInviteAcceptedDelegate_Handle(const FOnSessionUserInviteAcceptedDelegate& Delegate) override;
	virtual void ClearOnSessionUserInviteAcceptedDelegate_Handle(FDelegateHandle& Handle) override;
	virtual void TriggerOnSessionUserInviteAcceptedDelegates(const bool bWasSuccessful, const int32 ControllerId, TSharedPtr<const FUniqueNetId> UserId, const FOnlineSessionSearchResult& InviteResult) override;

	// OnSessionInviteReceived
	virtual FDelegateHandle AddOnSessionInviteReceivedDelegate_Handle(const FOnSessionInviteReceivedDelegate& Delegate) override;
	virtual void ClearOnSessionInviteReceivedDelegate_Handle(FDelegateHandle& Handle) override;
	virtual void TriggerOnSessionInviteReceivedDelegates(const FUniqueNetId& UserId, const FUniqueNetId& FromId, const FString& AppId, const FOnlineSessionSearchResult& InviteResult) override;

	// OnRegisterPlayersComplete
	virtual FDelegateHandle AddOnRegisterPlayersCompleteDelegate_Handle(const FOnRegisterPlayersCompleteDelegate& Delegate) override;
	virtual void ClearOnRegisterPlayersCompleteDelegate_Handle(FDelegateHandle& Handle) override;
	virtual void TriggerOnRegisterPlayersCompleteDelegates(FName Param1, const TArray< TSharedRef<const FUniqueNetId> >& Param2, bool Param3) override;

	// OnUnregisterPlayersComplete
	virtual FDelegateHandle AddOnUnregisterPlayersCompleteDelegate_Handle(const FOnUnregisterPlayersCompleteDelegate& Delegate) override;
	virtual void ClearOnUnregisterPlayersCompleteDelegate_Handle(FDelegateHandle& Handle) override;
	virtual void TriggerOnUnregisterPlayersCompleteDelegates(FName Param1, const TArray< TSharedRef<const FUniqueNetId> >& Param2, bool Param3) override;

	// OnSessionFailure
	virtual FDelegateHandle AddOnSessionFailureDelegate_Handle(const FOnSessionFailureDelegate& Delegate) override;
	virtual void ClearOnSessionFailureDelegate_Handle(FDelegateHandle& Handle) override;
	virtual void TriggerOnSessionFailureDelegates(const FUniqueNetId& Param1, ESessionFailure::Type Param2) override;
};

typedef TSharedPtr<FOnlineSessionPlayFabParty, ESPMode::ThreadSafe> FOnlineSessionPlayFabPartyPtr;