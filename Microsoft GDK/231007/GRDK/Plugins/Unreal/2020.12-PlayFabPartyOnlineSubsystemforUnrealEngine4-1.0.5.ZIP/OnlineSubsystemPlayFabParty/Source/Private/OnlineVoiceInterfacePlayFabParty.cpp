//--------------------------------------------------------------------------------------
// Copyright (C) Microsoft Corporation. All rights reserved.
//--------------------------------------------------------------------------------------

#include "OnlineVoiceInterfacePlayFabParty.h"
#include "OnlineSessionInterfacePlayFabParty.h"
#include "OnlineSubsystemPlayFabParty.h"

FOnlineVoicePlayFabParty::FOnlineVoicePlayFabParty(class FOnlineSubsystemPlayFabParty* InSubsystem) :
	OSSPlayFabParty(InSubsystem)
{

}

FOnlineVoicePlayFabParty::~FOnlineVoicePlayFabParty()
{
}

PartyLocalChatControl* FOnlineVoicePlayFabParty::GetPartyLocalChatControl(const FUniqueNetId& UserId) const
{
	if (UserId.IsValid())
	{
		const FString& PlatformId = UserId.ToString();
		if (LocalTalkers.Contains(PlatformId))
		{
			const FLocalTalkerPlayFabParty& PartyLocalTalker = LocalTalkers[PlatformId];
			return PartyLocalTalker.GetChatControl();
		}
	}

	return nullptr;
}

void FOnlineVoicePlayFabParty::OnAppSuspend()
{
	UE_LOG_ONLINE_VOICE(Verbose, TEXT("FOnlineVoicePlayFabParty::OnAppSuspend"));

	LocalTalkers.Empty();
	RemoteTalkers.Empty();
	
	CleanUpPartyXblManager();
}

void FOnlineVoicePlayFabParty::OnAppResume()
{
	UE_LOG_ONLINE_VOICE(Verbose, TEXT("FOnlineVoicePlayFabParty::OnAppResume"));

	InitPartyXblManager();
}

const FLocalTalkerPlayFabParty* FOnlineVoicePlayFabParty::GetLocalTalker(const int32 LocalUserNum) const
{
	IOnlineIdentityPtr IdentityIntPtr = OSSPlayFabParty->GetIdentityInterface();
	if (IdentityIntPtr.IsValid())
	{
		TSharedPtr<const FUniqueNetId> LocalUserId = IdentityIntPtr->GetUniquePlayerId(LocalUserNum);
		if (LocalUserId.IsValid())
		{
			const FString& PlatformId = LocalUserId->ToString();
			if (LocalTalkers.Contains(PlatformId))
			{
				const FLocalTalkerPlayFabParty& PartyLocalTalker = LocalTalkers[PlatformId];
				return &PartyLocalTalker;
			}
		}
	}

	return nullptr;
}

const FRemoteTalkerPlayFabParty* FOnlineVoicePlayFabParty::GetRemoteTalker(const FUniqueNetId& UniqueId) const
{
	const FString& PlatformId = UniqueId.ToString();
	if (LocalTalkers.Contains(PlatformId))
	{
		const FRemoteTalkerPlayFabParty& PartyLocalTalker = RemoteTalkers[PlatformId];
		return &PartyLocalTalker;
	}

	return nullptr;
}

void FOnlineVoicePlayFabParty::StartNetworkedVoice(uint8 LocalUserNum)
{
	const FLocalTalkerPlayFabParty* LocalTalker = GetLocalTalker(LocalUserNum);
	if (LocalTalker)
	{
		PartyLocalChatControl* ChatControl = LocalTalker->GetChatControl();
		if (ChatControl)
		{
			ChatControl->SetAudioInputMuted(false);
		}
	}
}

void FOnlineVoicePlayFabParty::StopNetworkedVoice(uint8 LocalUserNum)
{
	const FLocalTalkerPlayFabParty* LocalTalker = GetLocalTalker(LocalUserNum);
	if (LocalTalker)
	{
		PartyLocalChatControl* ChatControl = LocalTalker->GetChatControl();
		if (ChatControl)
		{
			ChatControl->SetAudioInputMuted(true);
		}
	}
}

bool FOnlineVoicePlayFabParty::RegisterLocalTalker(uint32 LocalUserNum)
{
	IOnlineIdentityPtr IdentityIntPtr = OSSPlayFabParty->GetIdentityInterface();
	if (IdentityIntPtr.IsValid())
	{
		FOnlineIdentityPlayFabParty* PlayFabIdentityInt = static_cast<FOnlineIdentityPlayFabParty*>(IdentityIntPtr.Get());

		TSharedPtr<const FUniqueNetId> LocalUserId = IdentityIntPtr->GetUniquePlayerId(LocalUserNum);
		if (!LocalUserId.IsValid())
		{
			UE_LOG_ONLINE_VOICE(Warning, TEXT("RegisterLocalTalker: Unable to register local talker %u, unable to get unique player id"), LocalUserNum);
			return false;
		}
		else
		{
			FPlayFabPartyUser* pLocalPartyUser = PlayFabIdentityInt->GetPartyLocalUserFromPlatformId(*LocalUserId);
			return RegisterLocalTalker(pLocalPartyUser);
		}
	}

	return false;
}

bool FOnlineVoicePlayFabParty::RegisterLocalTalker(const FUniqueNetId& LocalPlayer)
{
	IOnlineIdentityPtr IdentityIntPtr = OSSPlayFabParty->GetIdentityInterface();
	if (IdentityIntPtr.IsValid())
	{
		FOnlineIdentityPlayFabParty* PlayFabIdentityInt = static_cast<FOnlineIdentityPlayFabParty*>(IdentityIntPtr.Get());

		FPlayFabPartyUser* pLocalPartyUser = PlayFabIdentityInt->GetPartyLocalUserFromPlatformId(LocalPlayer);
		return RegisterLocalTalker(pLocalPartyUser);
	}

	return false;
}

bool FOnlineVoicePlayFabParty::RegisterLocalTalker(FPlayFabPartyUser* LocalPlayer)
{
	if (LocalPlayer == nullptr)
	{
		return false;
	}

	PartyManager& Manager = PartyManager::GetSingleton();

	// Get the local chat user
	Party::PartyLocalUser* ExistingLocalUser = LocalPlayer->GetPartyLocalUser();

	PartyLocalDevice* LocalDevice = nullptr;

	// Get local device
	PartyError Err = Manager.GetLocalDevice(&LocalDevice);

	if (PARTY_FAILED(Err))
	{
		UE_LOG_ONLINE(Warning, TEXT("PartyManager::GetLocalDevice failed: %s"), *GetPartyErrorMessage(Err));
		return false;
	}

	Party::PartyLocalChatControl* NewChatControl = nullptr;

	// Create a chat control for the local user on this device
	Err = LocalDevice->CreateChatControl(
		ExistingLocalUser,
		LocalChatControlLanguage.IsEmpty() ? nullptr : TCHAR_TO_UTF8(*LocalChatControlLanguage),
		nullptr,
		&NewChatControl
	);

	if (PARTY_FAILED(Err))
	{
		UE_LOG_ONLINE(Warning, TEXT("PartyManager::CreateChatControl failed: %s"), *GetPartyErrorMessage(Err));
		return false;
	}

	// Use platform default settings for user for audio in and out devices
	Err = NewChatControl->SetAudioInput(
		PartyAudioDeviceSelectionType::PlatformUserDefault,
		TCHAR_TO_UTF8(*LocalPlayer->GetPlatformUserId()),
		nullptr
	);

	if (PARTY_FAILED(Err))
	{
		UE_LOG_ONLINE(Warning, TEXT("PartyManager::SetAudioInput failed: %s"), *GetPartyErrorMessage(Err));
	}

	Err = NewChatControl->SetAudioOutput(
		PartyAudioDeviceSelectionType::PlatformUserDefault,
		TCHAR_TO_UTF8(*LocalPlayer->GetPlatformUserId()),
		nullptr
	);

	if (PARTY_FAILED(Err))
	{
		UE_LOG_ONLINE(Warning, TEXT("PartyManager::SetAudioOutput failed: %s"), *GetPartyErrorMessage(Err));
	}

	// Get the available list of text to speech profiles
	Err = NewChatControl->PopulateAvailableTextToSpeechProfiles(nullptr);
	if (PARTY_FAILED(Err))
	{
		UE_LOG_ONLINE(Warning, TEXT("Populating available TextToSpeechProfiles failed: %s"), *GetPartyErrorMessage(Err));
	}

#if PFP_OSS_IS_PC
	// Set the device to muted by default, this is standard for push to talk behavior on PC
	NewChatControl->SetAudioInputMuted(true);
#else
	// On console, unmute by default since the device manages this via voice activity detection
	NewChatControl->SetAudioInputMuted(false);
#endif
	
	// Add the chat control into the network mesh
	if (!OSSPlayFabParty->AddChatControlToNetwork(NewChatControl))
	{
		return false;
	}

	// NOTE: We store using the platform user id (e.g. xuid on xbox) instead, since its easier to retrieve when the person speaks due to UE giving us the base platform user id
	FLocalTalkerPlayFabParty NewTalkerInst(LocalPlayer->GetPlatformUserId(), LocalDevice, NewChatControl);
	LocalTalkers.Emplace(LocalPlayer->GetPlatformUserId(), NewTalkerInst);

	StartTrackingPermissionForTalker(LocalPlayer->GetPlatformUserId(), false /*IsRemote*/);

	// Always update permissions for controls when were done here, order of local + remote may not be guaranteed
	UpdatePermissionsForAllControls();

	return true;
}

void FOnlineVoicePlayFabParty::RegisterLocalTalkers()
{
	if (OSSPlayFabParty)
	{
		IOnlineIdentityPtr IdentityIntPtr = OSSPlayFabParty->GetIdentityInterface();
		if (IdentityIntPtr.IsValid())
		{
			FOnlineIdentityPlayFabParty* PlayFabIdentityInt = static_cast<FOnlineIdentityPlayFabParty*>(IdentityIntPtr.Get());
			if (PlayFabIdentityInt)
			{
				const TArray<FPlayFabPartyUser*>& ArrUsers = PlayFabIdentityInt->GetAllPartyLocalUsers();
				for (FPlayFabPartyUser* User : ArrUsers)
				{
					RegisterLocalTalker(User);
				}
			}
		}
	}
}

bool FOnlineVoicePlayFabParty::UnregisterLocalTalker(const FUniqueNetId& PlayerId)
{
	const FString& PlatformId = PlayerId.ToString();
	if (LocalTalkers.Contains(PlatformId))
	{
		const FLocalTalkerPlayFabParty& LocalTalker = LocalTalkers[PlatformId];
		return UnregisterLocalTalker(&LocalTalker);
	}

	return false;
}

bool FOnlineVoicePlayFabParty::UnregisterLocalTalker(uint32 LocalUserNum)
{
	const FLocalTalkerPlayFabParty* LocalTalker = GetLocalTalker(LocalUserNum);
	if (LocalTalker)
	{
		return UnregisterLocalTalker(LocalTalker);
	}

	return false;
}

bool FOnlineVoicePlayFabParty::UnregisterLocalTalker(const FLocalTalkerPlayFabParty* LocalTalker)
{
	PartyLocalDevice* LocalDevice = nullptr;

	// Get local device
	PartyError Err = PartyManager::GetSingleton().GetLocalDevice(&LocalDevice);

	if (PARTY_FAILED(Err))
	{
		UE_LOG_ONLINE(Warning, TEXT("PartyManager::GetLocalDevice failed: %s"), *GetPartyErrorMessage(Err));
	}

	Err = LocalDevice->DestroyChatControl(LocalTalker->GetChatControl(), nullptr);
	if (PARTY_FAILED(Err))
	{
		UE_LOG_ONLINE(Warning, TEXT("PartyManager::DestroyChatControl failed: %s"), *GetPartyErrorMessage(Err));
	}

	if (OnPlayerTalkingStateChangedDelegates.IsBound())
	{
		PLATFORM_UNIQUE_NET_ID_REF PlatformNetID = PLATFORM_UNIQUE_NET_ID::Create(LocalTalker->GetPlatformUserId());
		OnPlayerTalkingStateChangedDelegates.Broadcast(PlatformNetID, false);
	}

	LocalTalkers.Remove(LocalTalker->GetPlatformUserId());

	return true;
}

void FOnlineVoicePlayFabParty::UnregisterLocalTalkers()
{
	PartyLocalDevice* LocalDevice = nullptr;

	// Get local device
	PartyError Err = PartyManager::GetSingleton().GetLocalDevice(&LocalDevice);

	if (PARTY_FAILED(Err))
	{
		UE_LOG_ONLINE(Warning, TEXT("PartyManager::GetLocalDevice failed: %s"), *GetPartyErrorMessage(Err));
	}

	for (auto& LocalTalkerKvPair : LocalTalkers)
	{
		const FLocalTalkerPlayFabParty& LocalTalker = LocalTalkerKvPair.Value;
		Err = LocalDevice->DestroyChatControl(LocalTalker.GetChatControl(), nullptr);
		if (PARTY_FAILED(Err))
		{
			UE_LOG_ONLINE(Warning, TEXT("PartyManager::DestroyChatControl failed: %s"), *GetPartyErrorMessage(Err));
		}

		if (OnPlayerTalkingStateChangedDelegates.IsBound())
		{
			PLATFORM_UNIQUE_NET_ID_REF PlatformNetID = PLATFORM_UNIQUE_NET_ID::Create(LocalTalker.GetPlatformUserId());
			OnPlayerTalkingStateChangedDelegates.Broadcast(PlatformNetID, false);
		}

		StopTrackingPermissionForTalker(LocalTalkerKvPair.Key);
	}

	LocalTalkers.Empty();
}

bool FOnlineVoicePlayFabParty::RegisterRemoteTalker(const FUniqueNetId& UniqueId)
{
	StartTrackingPermissionForTalker(UniqueId.ToString(), true);
	return true;
}

bool FOnlineVoicePlayFabParty::UnregisterRemoteTalker(const FUniqueNetId& UniqueId)
{
	const FRemoteTalkerPlayFabParty* RemoteTalker = GetRemoteTalker(UniqueId);
	if (RemoteTalker)
	{
		if (OnPlayerTalkingStateChangedDelegates.IsBound() && (RemoteTalker->bIsTalking || RemoteTalker->bWasTalking))
		{
			PLATFORM_UNIQUE_NET_ID_REF PlatformNetID = PLATFORM_UNIQUE_NET_ID::Create(RemoteTalker->GetPlatformUserId());
			OnPlayerTalkingStateChangedDelegates.Broadcast(RemoteTalker->TalkerId.ToSharedRef(), false);
		}

		// Remotes get destroyed automatically, so we just remove it from our cache here
		RemoteTalkers.Remove(UniqueId.ToString());
		StopTrackingPermissionForTalker(UniqueId.ToString());

		return true;
	}

	return false;
}

void FOnlineVoicePlayFabParty::RemoveAllRemoteTalkers()
{
	for (auto& RemoteTalkerKvPair : RemoteTalkers)
	{
		const FRemoteTalkerPlayFabParty& RemoteTalker = RemoteTalkerKvPair.Value;
		
		if (OnPlayerTalkingStateChangedDelegates.IsBound() && (RemoteTalker.bIsTalking || RemoteTalker.bWasTalking))
		{
			PLATFORM_UNIQUE_NET_ID_REF PlatformNetID = PLATFORM_UNIQUE_NET_ID::Create(RemoteTalker.GetPlatformUserId());
			OnPlayerTalkingStateChangedDelegates.Broadcast(PlatformNetID, false);
		}
	}

	// Remotes get destroyed automatically, so we just wipe our cache here
	RemoteTalkers.Empty();
}

bool FOnlineVoicePlayFabParty::IsHeadsetPresent(uint32 LocalUserNum)
{
	const FLocalTalkerPlayFabParty* LocalTalker = GetLocalTalker(LocalUserNum);
	if (LocalTalker)
	{
		PartyAudioDeviceSelectionType DeviceType;
		PartyString DeviceContext, DeviceId;
		PartyError Err = LocalTalker->GetChatControl()->GetAudioInput(&DeviceType, &DeviceContext, &DeviceId);
		if (PARTY_SUCCEEDED(Err))
		{
			FString DeviceIdString = DeviceId;
			if (DeviceIdString.IsEmpty())
			{
				return false;
			}
			else
			{
				return true;
			}
		}
	}

	return false;
}

bool FOnlineVoicePlayFabParty::IsLocalPlayerTalking(uint32 LocalUserNum)
{
	const FLocalTalkerPlayFabParty* LocalTalker = GetLocalTalker(LocalUserNum);
	if (LocalTalker)
	{
		return LocalTalker->bIsTalking;
	}

	return false;
}

bool FOnlineVoicePlayFabParty::IsRemotePlayerTalking(const FUniqueNetId& UniqueId)
{
	const FRemoteTalkerPlayFabParty* RemoteTalker = GetRemoteTalker(UniqueId);
	if (RemoteTalker)
	{
		return RemoteTalker->bIsTalking;
	}

	return false;
}

bool FOnlineVoicePlayFabParty::IsMuted(uint32 LocalUserNum, const FUniqueNetId& UniqueId) const
{
	const FLocalTalkerPlayFabParty* LocalTalker = GetLocalTalker(LocalUserNum);
	if (LocalTalker)
	{
		PartyBool InputMuted;
		PartyError Err = LocalTalker->GetChatControl()->GetAudioInputMuted(&InputMuted);
		if (PARTY_SUCCEEDED(Err))
		{
			return static_cast<bool>(InputMuted);
		}
		else
		{
			UE_LOG_ONLINE(Error, TEXT("GetAudioInputMuted failed: %s"), *GetPartyErrorMessage(Err));
		}
	}

	return false;
}

bool FOnlineVoicePlayFabParty::MuteRemoteTalker(uint8 LocalUserNum, const FUniqueNetId& PlayerId, bool bIsSystemWide)
{
	const FLocalTalkerPlayFabParty* LocalTalker = GetLocalTalker(LocalUserNum);
	const FRemoteTalkerPlayFabParty* RemoteTalker = GetRemoteTalker(PlayerId);
	if (LocalTalker && RemoteTalker)
	{
		PartyError Err = LocalTalker->GetChatControl()->SetIncomingAudioMuted(RemoteTalker->GetChatControl(), static_cast<PartyBool>(true));
		if (PARTY_SUCCEEDED(Err))
		{
			return true;
		}
		else
		{
			UE_LOG_ONLINE(Error, TEXT("SetIncomingAudioMuted failed: %s"), *GetPartyErrorMessage(Err));
		}
	}

	return false;
}

bool FOnlineVoicePlayFabParty::UnmuteRemoteTalker(uint8 LocalUserNum, const FUniqueNetId& PlayerId, bool bIsSystemWide)
{
	const FLocalTalkerPlayFabParty* LocalTalker = GetLocalTalker(LocalUserNum);
	const FRemoteTalkerPlayFabParty* RemoteTalker = GetRemoteTalker(PlayerId);
	if (LocalTalker && RemoteTalker)
	{
		PartyError Err = LocalTalker->GetChatControl()->SetIncomingAudioMuted(RemoteTalker->GetChatControl(), static_cast<PartyBool>(false));
		if (PARTY_SUCCEEDED(Err))
		{
			return true;
		}
		else
		{
			UE_LOG_ONLINE(Error, TEXT("SetIncomingAudioMuted failed: %s"), *GetPartyErrorMessage(Err));
		}
	}

	return false;
}

TSharedPtr<class FVoicePacket> FOnlineVoicePlayFabParty::SerializeRemotePacket(FArchive& Ar)
{
	// NOTE: NOOP for PlayFab Party
	return nullptr;
}

TSharedPtr<class FVoicePacket> FOnlineVoicePlayFabParty::GetLocalPacket(uint32 LocalUserNum)
{
	// NOTE: NOOP for PlayFab Party
	return nullptr;
}

int32 FOnlineVoicePlayFabParty::GetNumLocalTalkers()
{
	return LocalTalkers.Num();
}

void FOnlineVoicePlayFabParty::ClearVoicePackets()
{
	// NOTE: NOOP for PlayFab Party
}

#if PFP_OSS_VERBOSE_VOIP_LOGGING
void FOnlineVoicePlayFabParty::DumpState()
{
	UE_LOG_ONLINE(Warning, TEXT("START LOCAL"));
	for (auto& LocalTalkerKvPair : LocalTalkers)
	{
		const FLocalTalkerPlayFabParty& LocalTalker = LocalTalkerKvPair.Value;
		PartyLocalChatControlChatIndicator ChatControlIndicator;
		LocalTalker.GetChatControl()->GetLocalChatIndicator(&ChatControlIndicator);

		switch (ChatControlIndicator)
		{
		case PartyLocalChatControlChatIndicator::Silent:		  UE_LOG_ONLINE(Warning, TEXT("LOCAL STATE IS Silent")); break;
		case PartyLocalChatControlChatIndicator::Talking:		  UE_LOG_ONLINE(Warning, TEXT("LOCAL STATE IS Talking")); break;
		case PartyLocalChatControlChatIndicator::AudioInputMuted: UE_LOG_ONLINE(Warning, TEXT("LOCAL STATE IS AudioInputMuted")); break;
		case PartyLocalChatControlChatIndicator::NoAudioInput:	  UE_LOG_ONLINE(Warning, TEXT("LOCAL STATE IS NoAudioInput")); break;
		}
	}
	UE_LOG_ONLINE(Warning, TEXT("END LOCAL"));

	// And now remote endpoints
	UE_LOG_ONLINE(Warning, TEXT("START REMOTE"));
	for (auto& LocalTalkerKvPair : LocalTalkers)
	{
		for (auto& RemoteTalkerKvPair : RemoteTalkers)
		{
			const FLocalTalkerPlayFabParty& LocalTalker = LocalTalkerKvPair.Value;
			const FRemoteTalkerPlayFabParty& RemoteTalker = RemoteTalkerKvPair.Value;
			PartyChatControlChatIndicator ChatControlIndicator;
			LocalTalker.GetChatControl()->GetChatIndicator(RemoteTalker.GetChatControl(), &ChatControlIndicator);

			switch (ChatControlIndicator)
			{
			case PartyChatControlChatIndicator::Silent:						 UE_LOG_ONLINE(Warning, TEXT("REMOTE STATE IS Silent")); break;
			case PartyChatControlChatIndicator::Talking:					 UE_LOG_ONLINE(Warning, TEXT("REMOTE STATE IS Talking")); break;
			case PartyChatControlChatIndicator::IncomingVoiceDisabled:		 UE_LOG_ONLINE(Warning, TEXT("REMOTE STATE IS IncomingVoiceDisabled")); break;
			case PartyChatControlChatIndicator::IncomingCommunicationsMuted: UE_LOG_ONLINE(Warning, TEXT("REMOTE STATE IS IncomingCommunicationsMuted")); break;
			}
		}
	}
	UE_LOG_ONLINE(Warning, TEXT("END REMOTE"));
}
#endif

void FOnlineVoicePlayFabParty::ProcessTalkingDelegates(float DeltaTime)
{
	for (auto& LocalTalkerKvPair : LocalTalkers)
	{
		FLocalTalkerPlayFabParty& LocalTalker = LocalTalkerKvPair.Value;
		PartyLocalChatControlChatIndicator ChatControlIndicator;
		LocalTalker.GetChatControl()->GetLocalChatIndicator(&ChatControlIndicator);

		LocalTalker.bIsTalking = ChatControlIndicator == PartyLocalChatControlChatIndicator::Talking;

		// If the talker was not previously talking, but now is trigger the event
		bool bShouldNotify = !LocalTalker.bWasTalking && LocalTalker.bIsTalking;
		// If the talker was previously talking, but now isn't time delay the event
		if (!bShouldNotify && LocalTalker.bWasTalking)
		{
			LocalTalker.LastNotificationTime -= DeltaTime;
			if (LocalTalker.LastNotificationTime <= 0.f)
			{
				// Clear the flag so it only activates when needed
				LocalTalker.bIsTalking = false;
				LocalTalker.LastNotificationTime = VoiceNotificationDelta;
				bShouldNotify = true;
			}
		}

		if (bShouldNotify)
		{
			if (OnPlayerTalkingStateChangedDelegates.IsBound())
			{
				PLATFORM_UNIQUE_NET_ID_REF PlatformNetID = PLATFORM_UNIQUE_NET_ID::Create(LocalTalker.GetPlatformUserId());
				OnPlayerTalkingStateChangedDelegates.Broadcast(PlatformNetID, LocalTalker.bIsTalking);
			}

			LocalTalker.bWasTalking = LocalTalker.bIsTalking;
			UE_LOG_ONLINE_VOICE(VeryVerbose, TEXT("Trigger is %sTALKING"), LocalTalker.bIsTalking ? TEXT("") : TEXT("NOT"));
		}
	}

	for (auto& LocalTalkerKvPair : LocalTalkers)
	{
		for (auto& RemoteTalkerKvPair : RemoteTalkers)
		{
			FLocalTalkerPlayFabParty& LocalTalker = LocalTalkerKvPair.Value;
			FRemoteTalkerPlayFabParty& RemoteTalker = RemoteTalkerKvPair.Value;
			PartyChatControlChatIndicator ChatControlIndicator;
			LocalTalker.GetChatControl()->GetChatIndicator(RemoteTalker.GetChatControl(), &ChatControlIndicator);

			RemoteTalker.bIsTalking = ChatControlIndicator == PartyChatControlChatIndicator::Talking;

			// If the talker was not previously talking, but now is trigger the event
			bool bShouldNotify = !RemoteTalker.bWasTalking && RemoteTalker.bIsTalking;
			// If the talker was previously talking, but now isn't time delay the event
			if (!bShouldNotify && RemoteTalker.bWasTalking)
			{
				RemoteTalker.LastNotificationTime -= DeltaTime;
				if (RemoteTalker.LastNotificationTime <= 0.f)
				{
					// Clear the flag so it only activates when needed
					RemoteTalker.bIsTalking = false;
					RemoteTalker.LastNotificationTime = VoiceNotificationDelta;
					bShouldNotify = true;
				}
			}

			if (bShouldNotify)
			{
				if (OnPlayerTalkingStateChangedDelegates.IsBound())
				{
					PLATFORM_UNIQUE_NET_ID_REF PlatformNetID = PLATFORM_UNIQUE_NET_ID::Create(RemoteTalker.GetPlatformUserId());
					OnPlayerTalkingStateChangedDelegates.Broadcast(PlatformNetID, RemoteTalker.bIsTalking);
				}

				RemoteTalker.bWasTalking = RemoteTalker.bIsTalking;
				UE_LOG_ONLINE_VOICE(VeryVerbose, TEXT("Trigger is %sTALKING"), RemoteTalker.bIsTalking ? TEXT("") : TEXT("NOT"));
			}
		}
	}
}

void FOnlineVoicePlayFabParty::Tick(float DeltaTime)
{
	TickTalkerPermissionTracking();
	ProcessTalkingDelegates(DeltaTime);
}

FString FOnlineVoicePlayFabParty::GetVoiceDebugState() const
{
	// NOTE: NOOP for PlayFab Party
	return TEXT("");
}

void FOnlineVoicePlayFabParty::OnLeavePFPNetwork()
{
	UnregisterLocalTalkers();
	RemoveAllRemoteTalkers();
}

IVoiceEnginePtr FOnlineVoicePlayFabParty::CreateVoiceEngine()
{
	// NOTE: NOOP for PlayFab Party
	return nullptr;
}

void FOnlineVoicePlayFabParty::ProcessMuteChangeNotification()
{
	// NOTE: NOOP for PlayFab Party
}

bool FOnlineVoicePlayFabParty::Init()
{
	bool bHasVoiceEnabled = true;
	if (GConfig->GetBool(TEXT("OnlineSubsystemPlayFabParty"), TEXT("bHasPlayFabPartyVoiceEnabled"), bHasVoiceEnabled, GEngineIni) && !bHasVoiceEnabled)
	{
		UE_LOG_ONLINE_VOICE(Log, TEXT("Voice Chat is Disabled"));
		return false;
	}

	if (!GConfig->GetFloat(TEXT("OnlineSubsystem"), TEXT("VoiceNotificationDelta"), VoiceNotificationDelta, GEngineIni))
	{
		VoiceNotificationDelta = 0.2f;
		UE_LOG_ONLINE_VOICE(Warning, TEXT("Missing VoiceNotificationDelta key in OnlineSubsystem of DefaultEngine.ini"));
	}

	return true;
}

void FOnlineVoicePlayFabParty::OnChatControlJoinedNetwork(const PartyStateChange* Change)
{
	UE_LOG_ONLINE(Warning, TEXT("FOnlineVoicePlayFabParty::OnChatControlJoinedNetwork"));
}

void FOnlineVoicePlayFabParty::OnChatControlLeftNetwork(const PartyStateChange* Change)
{
	UE_LOG_ONLINE(Warning, TEXT("FOnlineVoicePlayFabParty::OnChatControlLeftNetwork"));
}

void FOnlineVoicePlayFabParty::OnChatControlDestroyed(const PartyStateChange* Change)
{
	UE_LOG_ONLINE(Warning, TEXT("FOnlineVoicePlayFabParty::OnChatControlDestroyed"));
}

void FOnlineVoicePlayFabParty::OnChatControlCreated(const PartyStateChange* Change)
{
	UE_LOG_ONLINE(Warning, TEXT("FOnlineVoicePlayFabParty::OnChatControlCreated"));

	const PartyChatControlCreatedStateChange* Result = static_cast<const PartyChatControlCreatedStateChange*>(Change);
	if (Result)
	{
		PartyString SenderEntityId = nullptr;
		PartyError Err = Result->chatControl->GetEntityId(&SenderEntityId);

		if (PARTY_FAILED(Err))
		{
			UE_LOG_ONLINE(Warning, TEXT("FOnlineVoicePlayFabParty::OnChatControlCreated chatControl::GetEntityId failed: %s"), *GetPartyErrorMessage(Err));
		}
		else
		{
			// Is it remote? We already stored the local ones, so we only care about storing remote ones
			PartyLocalChatControl* LocalChatControl = nullptr;
			Err = Result->chatControl->GetLocal(&LocalChatControl);

			if (PARTY_FAILED(Err))
			{
				UE_LOG_ONLINE(Warning, TEXT("FOnlineVoicePlayFabParty::OnChatControlCreated chatControl::GetLocal failed: %s"), *GetPartyErrorMessage(Err));
			}
			else
			{
				if (LocalChatControl == nullptr) // Its remote
				{
					// Store it
					FRemoteTalkerPlayFabParty NewTalkerInst(Result->chatControl);
					RemoteTalkers.Emplace(SenderEntityId, NewTalkerInst);
				}
			}
		}

		// Always update permissions for controls when were done here, order of local + remote may not be guaranteed
		UpdatePermissionsForAllControls();
	}
}

void FOnlineVoicePlayFabParty::OnChatPermissionsChanged(const FString& LocalUserId, const FString& RemoteUserId, PartyChatPermissionOptions perms)
{
	UE_LOG_ONLINE(Verbose, TEXT("OnChatPermissionChanged %s %s %d"), *LocalUserId, *RemoteUserId, perms);

	// Rebuild the relationship map
	UpdatePermissionsForAllControls();
}

void FOnlineVoicePlayFabParty::UpdatePermissionsForAllControls()
{
	UE_LOG_ONLINE(Warning, TEXT("FOnlineVoicePlayFabParty::UpdatePermissionsForAllControls"));

	// first check if we have resolved a platform ID for any PF entity which did not have one associated
	for (auto& RemoteTalkerKvPair : RemoteTalkers)
	{
		FRemoteTalkerPlayFabParty& RemoteTalker = RemoteTalkerKvPair.Value;
		if (RemoteTalker.GetPlatformUserId().IsEmpty())
		{
			// do we have a platform ID for this user now?
			FString PlatformUserId = GetPlatformIdFromEntityId(RemoteTalkerKvPair.Key);

			if (!PlatformUserId.IsEmpty())
			{
				RemoteTalker.UpdatePlatformUserId(PlatformUserId);
			}
		}
	}

	// set permissions on all of our local chat controls
	bool bErr = false;
	for (auto& LocalTalkerKvPair : LocalTalkers)
	{
		for (auto& RemoteTalkerKvPair : RemoteTalkers)
		{
			const FLocalTalkerPlayFabParty& LocalTalker = LocalTalkerKvPair.Value;
			const FRemoteTalkerPlayFabParty& RemoteTalker = RemoteTalkerKvPair.Value;

			const FString& RemotePlatformID = RemoteTalker.GetPlatformUserId();

			if (RemotePlatformID.IsEmpty())
			{
				UE_LOG_ONLINE(Verbose, TEXT("Skipping ChatPermissions for PlayFab Entity %s at this time - the platform ID is still pending resolve"), *RemoteTalkerKvPair.Key);
				continue;
			}

			PartyChatPermissionOptions Options = GetChatPermissionsForTalker(LocalTalkerKvPair.Key, RemotePlatformID);

			UE_LOG_ONLINE(Verbose, TEXT("ChatPermissions for %s vs. %s (PlayFab EntityID: %s): %d"), *LocalTalkerKvPair.Key, *RemotePlatformID, *RemoteTalkerKvPair.Key, Options);

			PartyError Err = LocalTalker.GetChatControl()->SetPermissions(RemoteTalker.GetChatControl(), Options);

			if (PARTY_FAILED(Err))
			{
				UE_LOG_ONLINE(Warning, TEXT("FOnlineVoicePlayFabParty::OnChatControlCreated chatControl::SetPermissions failed: %s"), *GetPartyErrorMessage(Err));
			}
		}
	}
}

void FOnlineVoicePlayFabParty::OnConnectChatControlCompleted(const PartyStateChange* Change)
{
	UE_LOG_ONLINE(Warning, TEXT("FOnlineVoicePlayFabParty::OnConnectChatControlCompleted"));
}

void FOnlineVoicePlayFabParty::OnCreateChatControlCompleted(const PartyStateChange* Change)
{
	UE_LOG_ONLINE(Warning, TEXT("FOnlineVoicePlayFabParty::OnCreateChatControlCompleted"));
}

void FOnlineVoicePlayFabParty::OnDestroyChatControlCompleted(const PartyStateChange* Change)
{
	UE_LOG_ONLINE(Warning, TEXT("FOnlineVoicePlayFabParty::OnDestroyChatControlCompleted"));
}

void FOnlineVoicePlayFabParty::OnLocalChatAudioInputChanged(const PartyStateChange* Change)
{
	UE_LOG_ONLINE(Warning, TEXT("FOnlineVoicePlayFabParty::OnLocalChatAudioInputChanged"));

	const auto Result = static_cast<const PartyLocalChatAudioInputChangedStateChange*>(Change);

	UE_LOG_ONLINE(Verbose, TEXT("PartyAudioInputState: %d, %s"), Result->state, *GetPartyErrorMessage(Result->errorDetail));
}

void FOnlineVoicePlayFabParty::OnSetChatAudioInputCompleted(const PartyStateChange* Change)
{
	UE_LOG_ONLINE(Warning, TEXT("FOnlineVoicePlayFabParty::OnSetChatAudioInputCompleted"));

	const auto Result = static_cast<const PartySetChatAudioInputCompletedStateChange*>(Change);

	UE_LOG_ONLINE(Verbose, TEXT("PartyStateChangeResult: %d, %hs, %s"), Result->result, Result->audioDeviceSelectionContext, *GetPartyErrorMessage(Result->errorDetail));
}

void FOnlineVoicePlayFabParty::OnSetChatAudioOutputCompleted(const PartyStateChange* Change)
{
	UE_LOG_ONLINE(Warning, TEXT("FOnlineVoicePlayFabParty::OnSetChatAudioOutputCompleted"));
	
	const auto Result = static_cast<const PartySetChatAudioOutputCompletedStateChange*>(Change);

	UE_LOG_ONLINE(Verbose, TEXT("PartyStateChangeResult: %d, %hs, %s"), Result->result, Result->audioDeviceSelectionContext, *GetPartyErrorMessage(Result->errorDetail));
}