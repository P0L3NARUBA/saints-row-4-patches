//--------------------------------------------------------------------------------------
// Copyright (C) Microsoft Corporation. All rights reserved.
//--------------------------------------------------------------------------------------

#include "PlayFabPartyNetConnection.h"
#include "PlayFabPartySocketSubsystem.h"
#include "Net/DataChannel.h"

#include "OnlineSubsystem.h"
#include "OnlineSubsystemPlayFabPartyDefines.h"
#include "OnlineSubsystemSessionSettings.h"
#include "OnlineSessionSettings.h"
#include "Interfaces/OnlineSessionInterface.h"
#include "OnlineSubsystemPlayfabPartyPrivate.h"


UPlayFabPartyNetConnection::UPlayFabPartyNetConnection(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
}

void UPlayFabPartyNetConnection::InitLocalConnection(UNetDriver* InDriver, class FSocket* InSocket, const FURL& InURL, EConnectionState InState, int32 InMaxPacket, int32 InPacketOverhead)
{
	DisableAddressResolution();
	PlayerId.SetUniqueNetId(nullptr);

	FString HostConnectInfo;
	IOnlineSubsystem* OSSPlayFabParty = IOnlineSubsystem::Get(PLAYFABPARTY_SUBSYSTEM);
	if (OSSPlayFabParty)
	{
		FNamedOnlineSession* Session = OSSPlayFabParty->GetSessionInterface()->GetNamedSession(NAME_GameSession);
		if (Session)
		{
			Session->SessionSettings.Get(SETTING_HOST_CONNECT_INFO, HostConnectInfo);
		}
		else
		{
			UE_LOG_ONLINE(Error, TEXT("UPlayFabPartyNetConnection::InitLocalConnection failed: Named Session GameSession is null"));
		}
	}
	else
	{
		UE_LOG_ONLINE(Error, TEXT("UPlayFabPartyNetConnection::InitLocalConnection failed: Online Subsystem is null"));
	}

	InitBase(InDriver, InSocket, InURL, InState, InMaxPacket, InPacketOverhead);

	FPlayFabPartySocketSubsystem* SocketSubsystem = static_cast<FPlayFabPartySocketSubsystem*>(InDriver->GetSocketSubsystem());
	check(SocketSubsystem);

	RemoteAddr = InDriver->GetSocketSubsystem()->CreateInternetAddr();
	bool isValid = false;
	RemoteAddr->SetIp(*HostConnectInfo, isValid);

	FString PortStr;
	if (HostConnectInfo.StartsWith(PLAYFABPARTY_URL_PREFIX))
	{
		PortStr = HostConnectInfo.Mid(UE_ARRAY_COUNT(PLAYFABPARTY_URL_PREFIX) - 1);
	}

	const int32 Port = FCString::Atoi(*PortStr);
	RemoteAddr->SetPort(Port);

	InitSendBuffer();
}

void UPlayFabPartyNetConnection::InitRemoteConnection(UNetDriver* InDriver, class FSocket* InSocket, const FURL& InURL, const class FInternetAddr& InRemoteAddr, EConnectionState InState, int32 InMaxPacket, int32 InPacketOverhead)
{
	DisableAddressResolution();
	PlayerId.SetUniqueNetId(nullptr);

	InitBase(InDriver, InSocket, InURL, InState, InMaxPacket, InPacketOverhead);

	RemoteAddr = InRemoteAddr.Clone();

	URL.Host = RemoteAddr->ToString(false);

	InitSendBuffer();

	SetClientLoginState(EClientLoginState::LoggingIn);
	SetExpectedClientLoginMsgType(NMT_Hello);
}

void UPlayFabPartyNetConnection::FlushNet(bool bIgnoreSimulation)
{
	if (State == USOCK_Closed || State == USOCK_Invalid)
	{
		SendBuffer.Reset();
		InitSendBuffer();
		return;
	}
	else
	{
		Super::FlushNet(bIgnoreSimulation);
	}
}