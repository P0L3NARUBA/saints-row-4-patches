//--------------------------------------------------------------------------------------
// Copyright (C) Microsoft Corporation. All rights reserved.
//--------------------------------------------------------------------------------------

#pragma once

#include "CoreMinimal.h"
#include "Interfaces/VoiceInterface.h"
#include "OnlineSubsystemPlayFabPartyDefines.h"
#include "OnlineSubsystemPlayFabPartyPackage.h"
#include "OnlineIdentityInterfacePlayFabParty.h"
#include "Misc/CoreDelegates.h"

THIRD_PARTY_INCLUDES_START
#include <Party.h>
using namespace Party;
THIRD_PARTY_INCLUDES_END

class FOnlineSubsystemPlayFabParty;

class FLocalTalkerPlayFabParty : public FLocalTalker
{
public:
	FLocalTalkerPlayFabParty(const FString& InPlatformUserId, PartyLocalDevice* InLocalDevice, PartyLocalChatControl* InLocalChatControl)
		: PlatformUserId(InPlatformUserId),
		LocalDevice(InLocalDevice),
		LocalChatControl(InLocalChatControl)
	{
		// All talkers, if they exist, are registered
		bIsRegistered = true;
	}

	FString GetPlatformUserId() const 
	{
		return PlatformUserId;
	}

	PartyLocalDevice* GetDevice() const
	{
		return LocalDevice;
	}

	PartyLocalChatControl* GetChatControl() const
	{
		return LocalChatControl;
	}

private:
	FString PlatformUserId;
	PartyLocalDevice* LocalDevice = nullptr;
	PartyLocalChatControl* LocalChatControl = nullptr;
};

class FRemoteTalkerPlayFabParty : public FRemoteTalker
{
public:
	FRemoteTalkerPlayFabParty(const FString& InPlatformUserId, PartyChatControl* InChatControl)
		: PlatformUserId(InPlatformUserId),
		ChatControl(InChatControl)
	{
		
	}

	FRemoteTalkerPlayFabParty(PartyChatControl* InChatControl)
		: PlatformUserId(FString()),
		ChatControl(InChatControl)
	{

	}

	void UpdatePlatformUserId(const FString& InPlatformUserId)
	{
		PlatformUserId = InPlatformUserId;
	}

	FString GetPlatformUserId() const
	{
		return PlatformUserId;
	}

	PartyChatControl* GetChatControl() const
	{
		return ChatControl;
	}

private:
	FString PlatformUserId;
	PartyChatControl* ChatControl = nullptr;
};

class FOnlineVoicePlayFabParty
	: public IOnlineVoice
	, public TSharedFromThis<FOnlineVoicePlayFabParty, ESPMode::ThreadSafe>
{
	class FOnlineSubsystemPlayFabParty* OSSPlayFabParty;

PACKAGE_SCOPE:
	// Re-evaluates the muting list for all local talkers
	void ProcessMuteChangeNotification() override;

	//Initialize the voice interface
	virtual bool Init() override;

public:
	// Constructors
	FOnlineVoicePlayFabParty() = delete;
	FOnlineVoicePlayFabParty(class FOnlineSubsystemPlayFabParty* InSubsystem);

	// Virtual destructor to force proper child cleanup
	virtual ~FOnlineVoicePlayFabParty();

	virtual void StartNetworkedVoice(uint8 LocalUserNum) override;
	virtual void StopNetworkedVoice(uint8 LocalUserNum) override;
	virtual bool RegisterLocalTalker(uint32 LocalUserNum) override;
	bool RegisterLocalTalker(FPlayFabPartyUser* LocalPlayer);
	bool RegisterLocalTalker(const FUniqueNetId& LocalPlayer);
	virtual void RegisterLocalTalkers() override;
	virtual bool UnregisterLocalTalker(uint32 LocalUserNum) override;
	bool UnregisterLocalTalker(const FUniqueNetId& PlayerId);
	bool UnregisterLocalTalker(const FLocalTalkerPlayFabParty* LocalTalker);
	virtual void UnregisterLocalTalkers() override;
	virtual bool RegisterRemoteTalker(const FUniqueNetId& UniqueId) override;
	virtual bool UnregisterRemoteTalker(const FUniqueNetId& UniqueId) override;
	virtual void RemoveAllRemoteTalkers() override;
	virtual bool IsHeadsetPresent(uint32 LocalUserNum) override;
	virtual bool IsLocalPlayerTalking(uint32 LocalUserNum) override;
	virtual bool IsRemotePlayerTalking(const FUniqueNetId& UniqueId) override;
	bool IsMuted(uint32 LocalUserNum, const FUniqueNetId& UniqueId) const override;
	bool MuteRemoteTalker(uint8 LocalUserNum, const FUniqueNetId& PlayerId, bool bIsSystemWide) override;
	bool UnmuteRemoteTalker(uint8 LocalUserNum, const FUniqueNetId& PlayerId, bool bIsSystemWide) override;
	virtual TSharedPtr<class FVoicePacket> SerializeRemotePacket(FArchive& Ar) override;
	virtual TSharedPtr<class FVoicePacket> GetLocalPacket(uint32 LocalUserNum) override;
	virtual int32 GetNumLocalTalkers() override;
	virtual void ClearVoicePackets() override;
	virtual void Tick(float DeltaTime) override;
	virtual FString GetVoiceDebugState() const override;

	void OnLeavePFPNetwork();

	// PlayFab Party Network Events
	void OnChatControlJoinedNetwork(const PartyStateChange* Change);
	void OnChatControlLeftNetwork(const PartyStateChange* Change);
	void OnChatControlDestroyed(const PartyStateChange* Change);
	void OnChatControlCreated(const PartyStateChange* Change);
	void OnConnectChatControlCompleted(const PartyStateChange* Change);
	void OnCreateChatControlCompleted(const PartyStateChange* Change);
	void OnDestroyChatControlCompleted(const PartyStateChange* Change);
	void OnLocalChatAudioInputChanged(const PartyStateChange* Change);
	void OnSetChatAudioInputCompleted(const PartyStateChange* Change);
	void OnSetChatAudioOutputCompleted(const PartyStateChange* Change);

	PartyLocalChatControl* GetPartyLocalChatControl(const FUniqueNetId& UserId) const;

	FString GetPlatformIdFromEntityId(const FString& EntityId);

	void OnAppSuspend();
	void OnAppResume();
	
	void CleanUpPartyXblManager();
	void InitPartyXblManager();

protected:
	virtual IVoiceEnginePtr CreateVoiceEngine() override;

	const FLocalTalkerPlayFabParty* GetLocalTalker(const int32 LocalUserNum) const;
	const FRemoteTalkerPlayFabParty* GetRemoteTalker(const FUniqueNetId& UniqueId) const;

	// Platform-specific functions for chat permissions
	PartyChatPermissionOptions GetChatPermissionsForTalker(const FString& LocalId, const FString& RemoteId);
	void StartTrackingPermissionForTalker(const FString& UserId, bool IsRemote);
	void StopTrackingPermissionForTalker(const FString& UserId);
	void TickTalkerPermissionTracking();
	void OnChatPermissionsChanged(const FString& LocalUserId, const FString& RemoteUserId, PartyChatPermissionOptions perms);

private:
	void UpdatePermissionsForAllControls();

#if PFP_OSS_VERBOSE_VOIP_LOGGING
	void DumpState();
#endif

	void ProcessTalkingDelegates(float DeltaTime);

	float VoiceNotificationDelta = 0.2f;

	FString LocalChatControlLanguage;
	TMap<FString, FLocalTalkerPlayFabParty> LocalTalkers;
	TMap<FString, FRemoteTalkerPlayFabParty> RemoteTalkers; // NOTE: Key here is a PlayFab Entity ID, if you want the platform ID, access the FRemoteTalkerPlayFabParty member var
};

typedef TSharedPtr<FOnlineVoicePlayFabParty, ESPMode::ThreadSafe> FOnlineVoicePlayFabPartyPtr;