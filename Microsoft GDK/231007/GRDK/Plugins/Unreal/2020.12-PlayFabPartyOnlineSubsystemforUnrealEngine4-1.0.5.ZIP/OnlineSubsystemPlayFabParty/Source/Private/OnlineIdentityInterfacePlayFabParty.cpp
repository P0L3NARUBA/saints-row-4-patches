//--------------------------------------------------------------------------------------
// Copyright (C) Microsoft Corporation. All rights reserved.
//--------------------------------------------------------------------------------------

#include "OnlineIdentityInterfacePlayFabParty.h"
#include "OnlineSubsystemPlayFabParty.h"

#include "Serialization/JsonWriter.h"
#include "Serialization/JsonReader.h"
#include "Serialization/JsonTypes.h"
#include "Serialization/JsonSerializer.h"

#include "HttpModule.h"
#include "OnlineSubsystem.h"

#define OSS_PFP_GET_NATIVE_IDENTITY_INTERFACE IOnlineSubsystem* NativeSubsystem = IOnlineSubsystem::GetByPlatform();  IOnlineIdentityPtr NativeIdentityInterface = NativeSubsystem ? NativeSubsystem->GetIdentityInterface() : nullptr; if (NativeIdentityInterface)

FOnlineIdentityPlayFabParty::FOnlineIdentityPlayFabParty(class FOnlineSubsystemPlayFabParty* InSubsystem) : 
	OSSPlayFabParty(InSubsystem)
{
	check(OSSPlayFabParty);

	// Don't wait on the cool down to auth on the very first go
	TimeSinceLastAuth = AuthCoolDownTime;
}

FOnlineIdentityPlayFabParty::~FOnlineIdentityPlayFabParty()
{
	OSSPlayFabParty = nullptr;

	CleanUpAuthDelegates();
	CleanUpLocalUsers();
}

bool FOnlineIdentityPlayFabParty::Login(int32 LocalUserNum, const FOnlineAccountCredentials& AccountCredentials)
{
	UE_LOG_ONLINE_IDENTITY(Verbose, TEXT("FOnlineIdentityPlayFabParty::Login"));

	OSS_PFP_GET_NATIVE_IDENTITY_INTERFACE
	{
		return NativeIdentityInterface->Login(LocalUserNum, AccountCredentials);
	}
	
	return false;
}

bool FOnlineIdentityPlayFabParty::Logout(int32 LocalUserNum)
{
	UE_LOG_ONLINE_IDENTITY(Verbose, TEXT("FOnlineIdentityPlayFabParty::Logout"));

	OSS_PFP_GET_NATIVE_IDENTITY_INTERFACE
	{
		return NativeIdentityInterface->Logout(LocalUserNum);
	}

	return false;
}

bool FOnlineIdentityPlayFabParty::AutoLogin(int32 LocalUserNum)
{
	return Login(LocalUserNum, FOnlineAccountCredentials());
}

TSharedPtr<FUserOnlineAccount> FOnlineIdentityPlayFabParty::GetUserAccount(const FUniqueNetId& UserId) const
{
	UE_LOG_ONLINE_IDENTITY(Verbose, TEXT("FOnlineIdentityPlayFabParty::GetUserAccount"));

	OSS_PFP_GET_NATIVE_IDENTITY_INTERFACE
	{
		return NativeIdentityInterface->GetUserAccount(UserId);
	}

	return nullptr;
}

TArray<TSharedPtr<FUserOnlineAccount> > FOnlineIdentityPlayFabParty::GetAllUserAccounts() const
{
	UE_LOG_ONLINE_IDENTITY(Verbose, TEXT("FOnlineIdentityPlayFabParty::GetAllUserAccounts"));

	OSS_PFP_GET_NATIVE_IDENTITY_INTERFACE
	{
		return NativeIdentityInterface->GetAllUserAccounts();
	}

	return TArray<TSharedPtr<FUserOnlineAccount>>();
}

TSharedPtr<const FUniqueNetId> FOnlineIdentityPlayFabParty::GetUniquePlayerId(int32 LocalUserNum) const
{
	UE_LOG_ONLINE_IDENTITY(Verbose, TEXT("FOnlineIdentityPlayFabParty::GetUniquePlayerId"));

	OSS_PFP_GET_NATIVE_IDENTITY_INTERFACE
	{
		return NativeIdentityInterface->GetUniquePlayerId(LocalUserNum);
	}

	return nullptr;
}

TSharedPtr<const FUniqueNetId> FOnlineIdentityPlayFabParty::GetSponsorUniquePlayerId(int32 LocalUserNum) const
{
	UE_LOG_ONLINE_IDENTITY(Verbose, TEXT("FOnlineIdentityPlayFabParty::GetSponsorUniquePlayerId"));

	OSS_PFP_GET_NATIVE_IDENTITY_INTERFACE
	{
		return NativeIdentityInterface->GetSponsorUniquePlayerId(LocalUserNum);
	}

	return nullptr;
}

TSharedPtr<const FUniqueNetId> FOnlineIdentityPlayFabParty::CreateUniquePlayerId(uint8* Bytes, int32 Size)
{
	UE_LOG_ONLINE_IDENTITY(Verbose, TEXT("FOnlineIdentityPlayFabParty::CreateUniquePlayerId"));

	OSS_PFP_GET_NATIVE_IDENTITY_INTERFACE
	{
		return NativeIdentityInterface->CreateUniquePlayerId(Bytes, Size);
	}

	return nullptr;
}

TSharedPtr<const FUniqueNetId> FOnlineIdentityPlayFabParty::CreateUniquePlayerId(const FString& Str)
{
	UE_LOG_ONLINE_IDENTITY(Verbose, TEXT("FOnlineIdentityPlayFabParty::CreateUniquePlayerId"));

	OSS_PFP_GET_NATIVE_IDENTITY_INTERFACE
	{
		return NativeIdentityInterface->CreateUniquePlayerId(Str);
	}

	return nullptr;
}

ELoginStatus::Type FOnlineIdentityPlayFabParty::GetLoginStatus(int32 LocalUserNum) const
{
	UE_LOG_ONLINE_IDENTITY(Verbose, TEXT("FOnlineIdentityPlayFabParty::GetLoginStatus"));

	OSS_PFP_GET_NATIVE_IDENTITY_INTERFACE
	{
		return NativeIdentityInterface->GetLoginStatus(LocalUserNum);
	}

	return ELoginStatus::NotLoggedIn;
}

ELoginStatus::Type FOnlineIdentityPlayFabParty::GetLoginStatus(const FUniqueNetId& UserId) const
{
	UE_LOG_ONLINE_IDENTITY(Verbose, TEXT("FOnlineIdentityPlayFabParty::GetLoginStatus"));

	OSS_PFP_GET_NATIVE_IDENTITY_INTERFACE
	{
		return NativeIdentityInterface->GetLoginStatus(UserId);
	}

	return ELoginStatus::NotLoggedIn;
}

FString FOnlineIdentityPlayFabParty::GetPlayerNickname(int32 LocalUserNum) const
{
	UE_LOG_ONLINE_IDENTITY(Verbose, TEXT("FOnlineIdentityPlayFabParty::GetPlayerNickname"));

	OSS_PFP_GET_NATIVE_IDENTITY_INTERFACE
	{
		return NativeIdentityInterface->GetPlayerNickname(LocalUserNum);
	}

	return TEXT("");
}

FString FOnlineIdentityPlayFabParty::GetPlayerNickname(const FUniqueNetId& UserId) const
{
	UE_LOG_ONLINE_IDENTITY(Verbose, TEXT("FOnlineIdentityPlayFabParty::GetPlayerNickname"));

	OSS_PFP_GET_NATIVE_IDENTITY_INTERFACE
	{
		return NativeIdentityInterface->GetPlayerNickname(UserId);
	}

	return TEXT("");
}

FString FOnlineIdentityPlayFabParty::GetAuthToken(int32 LocalUserNum) const
{
	UE_LOG_ONLINE_IDENTITY(Verbose, TEXT("FOnlineIdentityPlayFabParty::GetAuthToken"));

	OSS_PFP_GET_NATIVE_IDENTITY_INTERFACE
	{
		return NativeIdentityInterface->GetAuthToken(LocalUserNum);
	}

	return TEXT("");
}

void FOnlineIdentityPlayFabParty::RevokeAuthToken(const FUniqueNetId& UserId, const FOnRevokeAuthTokenCompleteDelegate& Delegate)
{
	UE_LOG_ONLINE_IDENTITY(Verbose, TEXT("FOnlineIdentityPlayFabParty::RevokeAuthToken"));

	OSS_PFP_GET_NATIVE_IDENTITY_INTERFACE
	{
		NativeIdentityInterface->RevokeAuthToken(UserId, Delegate);
	}
}

void FOnlineIdentityPlayFabParty::GetUserPrivilege(const FUniqueNetId& UserId, EUserPrivileges::Type Privilege, const FOnGetUserPrivilegeCompleteDelegate& Delegate)
{
	UE_LOG_ONLINE_IDENTITY(Verbose, TEXT("FOnlineIdentityPlayFabParty::GetUserPrivilege"));

	OSS_PFP_GET_NATIVE_IDENTITY_INTERFACE
	{
		NativeIdentityInterface->GetUserPrivilege(UserId, Privilege, Delegate);
	}
}

FPlatformUserId FOnlineIdentityPlayFabParty::GetPlatformUserIdFromUniqueNetId(const FUniqueNetId& UniqueNetId) const
{
	UE_LOG_ONLINE_IDENTITY(Verbose, TEXT("FOnlineIdentityPlayFabParty::GetPlatformUserIdFromUniqueNetId"));

	OSS_PFP_GET_NATIVE_IDENTITY_INTERFACE
	{
		return NativeIdentityInterface->GetPlatformUserIdFromUniqueNetId(UniqueNetId);
	}

	return PLATFORMUSERID_NONE;
}

FString FOnlineIdentityPlayFabParty::GetAuthType() const
{
	UE_LOG_ONLINE_IDENTITY(Verbose, TEXT("FOnlineIdentityPlayFabParty::GetAuthType"));

	OSS_PFP_GET_NATIVE_IDENTITY_INTERFACE
	{
		return NativeIdentityInterface->GetAuthType();
	}

	return TEXT("PlayFabParty");
}

void FOnlineIdentityPlayFabParty::Tick(float DeltaTime)
{
	TimeSinceLastAuth += DeltaTime;
	
	// Auth all players once at start or after resume
	if (bAuthAllUsers == true)
	{
		// The native identity interface may not be constructed yet
		OSS_PFP_GET_NATIVE_IDENTITY_INTERFACE
		{
			UE_LOG_ONLINE(Verbose, TEXT("FOnlineIdentityPlayFabParty::Tick: Native identity interface initialized, registering auth delegates and doing initial user auth"));

			if (bRegisterAuthDelegates)
			{
				RegisterAuthDelegates();
			}
			
			for (const auto& User : NativeIdentityInterface->GetAllUserAccounts())
			{
				FString PlatformUserIdStr;
				User->GetUserAttribute(USER_ATTR_ID, PlatformUserIdStr);
				UsersToAuth.Add(PlatformUserIdStr);
			}

			bAuthAllUsers = false;
		}
	}

	// Don't bother trying to auth users while PlayFab is not initialized and ready
	if (OSSPlayFabParty && OSSPlayFabParty->bPartyInitialized)
	{
		TryAuthenticateUsers();
	}
}

void FOnlineIdentityPlayFabParty::OnAppSuspend()
{
	UE_LOG_ONLINE_IDENTITY(Verbose, TEXT("FOnlineIdentityPlayFabParty::OnAppSuspend"));
	
	CleanUpLocalUsers();
}

void FOnlineIdentityPlayFabParty::OnAppResume()
{
	UE_LOG_ONLINE_IDENTITY(Verbose, TEXT("FOnlineIdentityPlayFabParty::OnAppResume"));

	bAuthAllUsers = true;
}

void FOnlineIdentityPlayFabParty::RegisterAuthDelegates()
{
	UE_LOG_ONLINE_IDENTITY(Verbose, TEXT("FOnlineIdentityPlayFabParty::RegisterAuthDelegates"));

	OSS_PFP_GET_NATIVE_IDENTITY_INTERFACE
	{
		for (int32 i = 0; i < MAX_LOCAL_PLAYERS; ++i)
		{
			FDelegateHandle NewHandle = NativeIdentityInterface->AddOnLoginStatusChangedDelegate_Handle(i, FOnLoginStatusChangedDelegate::CreateRaw(this, &FOnlineIdentityPlayFabParty::OnLoginStatusChanged));
			LoginStatusChangedDelegateHandles.Add(NewHandle);
		}

		for (int32 i = 0; i < MAX_LOCAL_PLAYERS; ++i)
		{
			FDelegateHandle NewHandle = NativeIdentityInterface->AddOnLoginCompleteDelegate_Handle(i, FOnLoginCompleteDelegate::CreateRaw(this, &FOnlineIdentityPlayFabParty::OnLoginComplete));
			LoginCompleteDelegateHandles.Add(NewHandle);
		}

		for (int32 i = 0; i < MAX_LOCAL_PLAYERS; ++i)
		{
			FDelegateHandle NewHandle = NativeIdentityInterface->AddOnLogoutCompleteDelegate_Handle(i, FOnLogoutCompleteDelegate::CreateRaw(this, &FOnlineIdentityPlayFabParty::OnLogoutComplete));
			LogoutCompleteDelegateHandles.Add(NewHandle);
		}
	}

	bRegisterAuthDelegates = false;
}

void FOnlineIdentityPlayFabParty::CleanUpAuthDelegates()
{
	UE_LOG_ONLINE_IDENTITY(Verbose, TEXT("FOnlineIdentityPlayFabParty::CleanUpAuthDelegates"));

	OSS_PFP_GET_NATIVE_IDENTITY_INTERFACE
	{
		for (int32 i = 0; i < LoginStatusChangedDelegateHandles.Num(); ++i)
		{
			NativeIdentityInterface->ClearOnLoginStatusChangedDelegate_Handle(i, LoginStatusChangedDelegateHandles[i]);
		}

		for (int32 i = 0; i < LoginCompleteDelegateHandles.Num(); ++i)
		{
			NativeIdentityInterface->ClearOnLoginCompleteDelegate_Handle(i, LoginCompleteDelegateHandles[i]);
		}

		for (int32 i = 0; i < LogoutCompleteDelegateHandles.Num(); ++i)
		{
			NativeIdentityInterface->ClearOnLogoutCompleteDelegate_Handle(i, LogoutCompleteDelegateHandles[i]);
		}

		LoginStatusChangedDelegateHandles.Empty();
		LoginCompleteDelegateHandles.Empty();
		LogoutCompleteDelegateHandles.Empty();
	}

	bRegisterAuthDelegates = true;
}

void FOnlineIdentityPlayFabParty::OnLoginStatusChanged(int32 LocalUserNum, ELoginStatus::Type OldStatus, ELoginStatus::Type NewStatus, const FUniqueNetId& NewId)
{
	UE_LOG_ONLINE_IDENTITY(Verbose, TEXT("FOnlineIdentityPlayFabParty::OnLoginStatusChanged"));

	OSS_PFP_GET_NATIVE_IDENTITY_INTERFACE
	{
		if (NewId.IsValid())
		{
			if (NewStatus == ELoginStatus::LoggedIn)
			{
				UsersToAuth.Add(NewId.ToString());
			}
			else if (NewStatus == ELoginStatus::NotLoggedIn)
			{
				// Clean up the PlayFab local user
				FString PlatformUserIdStr = NewId.ToString();
				RemoveLocalUser(PlatformUserIdStr);
			}
		}
	}
}

void FOnlineIdentityPlayFabParty::OnLoginComplete(int32 LocalUserNum, bool bWasSuccessful, const FUniqueNetId& UserId, const FString& Error)
{
	UE_LOG_ONLINE_IDENTITY(Verbose, TEXT("FOnlineIdentityPlayFabParty::OnLoginComplete"));

	OSS_PFP_GET_NATIVE_IDENTITY_INTERFACE
	{
		if (bWasSuccessful && UserId.IsValid())
		{
			UsersToAuth.Add(UserId.ToString());
		}
	}
}

void FOnlineIdentityPlayFabParty::OnLogoutComplete(int32 LocalUserNum, bool bWasSuccessful)
{
	UE_LOG_ONLINE_IDENTITY(Verbose, TEXT("FOnlineIdentityPlayFabParty::OnLogoutComplete"));

	OSS_PFP_GET_NATIVE_IDENTITY_INTERFACE
	{
		// Clean up the PlayFab local user
		if (bWasSuccessful)
		{
			TSharedPtr<const FUniqueNetId> UserId = NativeIdentityInterface->GetUniquePlayerId(LocalUserNum);
			if (UserId.IsValid())
			{
				FString PlatformUserIdStr = UserId->ToString();
				RemoveLocalUser(PlatformUserIdStr);
			}
		}
	}
}

void FOnlineIdentityPlayFabParty::TryAuthenticateUsers()
{
	// Update any users that need to update their tokens
	for (FPlayFabPartyUser* LocalUser : LocalPlayFabUsers)
	{
		if (FDateTime::Now() > LocalUser->GetEntityTokenUpdateTime())
		{
			UsersToAuth.Add(LocalUser->GetPlatformUserId());
		}
	}
	
	// Only try to auth if we have waited long enough and have users that need it
	if (TimeSinceLastAuth > AuthCoolDownTime && UsersToAuth.Num() != 0)
	{
		for (const FString& PlatformUserIdStr : UsersToAuth)
		{
			AuthenticateUser(PlatformUserIdStr);
		}
	}
}

void FOnlineIdentityPlayFabParty::CleanUpLocalUsers()
{
	UE_LOG_ONLINE_IDENTITY(Verbose, TEXT("FOnlineIdentityPlayFabParty::CleanUpLocalUsers"));

	for (FPlayFabPartyUser* LocalUser : LocalPlayFabUsers)
	{
		delete LocalUser;
	}
	LocalPlayFabUsers.Empty();

	UsersToAuth.Empty();
	UserAuthRequestsInFlight.Empty();
}

bool FOnlineIdentityPlayFabParty::AuthenticateUser(const FString& PlatformUserIdStr)
{
	// Only if not already in flight for this user
	if (UserAuthRequestsInFlight.Contains(PlatformUserIdStr))
	{
		return false;
	}

	bool bAppliedPlatformData = ApplyPlatformHTTPRequestData(PlatformUserIdStr, L"https://playfabapi.com/", L"POST");
	if (bAppliedPlatformData)
	{
		UserAuthRequestData MetaData;
		UserAuthRequestsInFlight.Add(PlatformUserIdStr, MetaData);
	}

	return bAppliedPlatformData;
}

// Called after platform has appended its headers/body
void FOnlineIdentityPlayFabParty::FinishRequest(bool bPlatformDataSuccess, const FString& PlatformUserIdStr, TMap<FString, FString> PlatformHeaders, TSharedPtr<FJsonObject> RequestBodyJson)
{
	if (bPlatformDataSuccess)
	{
		// PlayFab auth request
		TSharedRef<IHttpRequest> httpRequest = FHttpModule::Get().CreateRequest();

		UserAuthRequestData* RequestInFlight = GetUserAuthRequestData(PlatformUserIdStr);
		if (RequestInFlight != nullptr)
		{
			RequestInFlight->m_HTTPRequest = httpRequest;

			RequestInFlight->m_HTTPRequest->OnProcessRequestComplete().BindRaw(this, &FOnlineIdentityPlayFabParty::Auth_HttpRequestComplete);
			FString TitleIdStr = OSSPlayFabParty->GetAppId();

			// Add all platform headers
			for (const auto& kvPair : PlatformHeaders)
			{
				RequestInFlight->m_HTTPRequest->SetHeader(kvPair.Key, kvPair.Value);
			}

			// Build up the rest of the request body
			RequestBodyJson->SetBoolField(TEXT("CreateAccount"), true);
			RequestBodyJson->SetStringField(TEXT("TitleId"), TitleIdStr);

			// Serialize request body
			FString RequestBodySerialized;
			TSharedRef<TJsonWriter<>> Writer = TJsonWriterFactory<>::Create(&RequestBodySerialized);
			FJsonSerializer::Serialize(RequestBodyJson.ToSharedRef(), Writer);

			const FString URI = FString::Printf(TEXT("https://%s.playfabapi.com/Client/LoginWithXbox"), *TitleIdStr);
			RequestInFlight->m_HTTPRequest->SetHeader(TEXT("Content-Type"), TEXT("application/json"));
			RequestInFlight->m_HTTPRequest->SetURL(URI);
			RequestInFlight->m_HTTPRequest->SetVerb(TEXT("POST"));
			RequestInFlight->m_HTTPRequest->SetContentAsString(RequestBodySerialized); // gets copied internally
			RequestInFlight->m_HTTPRequest->ProcessRequest();
		}
	}
	else
	{
		// Remove the in flight data
		UserAuthRequestsInFlight.Remove(PlatformUserIdStr);
	}
}

void FOnlineIdentityPlayFabParty::Auth_HttpRequestComplete(FHttpRequestPtr HttpRequest, FHttpResponsePtr HttpResponse, bool bSucceeded)
{
	const FString& PlatformUserIdStr = GetUserPlatformIdStrFromRequest(HttpRequest);

	FString ResponseStr;
	FString ErrorStr;

	if (bSucceeded && HttpResponse.IsValid())
	{
		ResponseStr = HttpResponse->GetContentAsString();

		// Deserialize response
		TSharedPtr<FJsonObject> HttpResponseJSON = nullptr;
		TSharedRef<TJsonReader<TCHAR>> JsonReader = TJsonReaderFactory<TCHAR>::Create(ResponseStr);
		if (FJsonSerializer::Deserialize(JsonReader, HttpResponseJSON))
		{
			const TSharedPtr<FJsonObject>* JsonData = nullptr;
			if (HttpResponseJSON->TryGetObjectField(TEXT("data"), JsonData))
			{
				const TSharedPtr<FJsonObject>* JsonEntityTokenData = nullptr;
				if ((*JsonData)->TryGetObjectField(TEXT("EntityToken"), JsonEntityTokenData))
				{
					FString EntityTokenStr;
					FString TokenExpirationStr;

					if ((*JsonEntityTokenData)->TryGetStringField(TEXT("EntityToken"), EntityTokenStr) && (*JsonEntityTokenData)->TryGetStringField(TEXT("TokenExpiration"), TokenExpirationStr))
					{
						const TSharedPtr<FJsonObject>* JsonEntity = nullptr;
						if ((*JsonEntityTokenData)->TryGetObjectField(TEXT("Entity"), JsonEntity))
						{
							FString EntityIdStr;
							if ((*JsonEntity)->TryGetStringField(TEXT("Id"), EntityIdStr))
							{
								UE_LOG_ONLINE(Verbose, TEXT("[FOnlineIdentityPlayFabParty::Auth_HttpRequestComplete] Platform User %s authenticated with entityid %s and token %s and expiration %s"), *PlatformUserIdStr, *EntityIdStr, *EntityTokenStr, *TokenExpirationStr);
								
								FPlayFabPartyUser* PlayFabPartyUser = GetPartyLocalUserFromPlatformIdString(PlatformUserIdStr);
								if (PlayFabPartyUser)
								{
									// Update an existing user if we already have one
									PlayFabPartyUser->UpdateEntityToken(EntityTokenStr);
								}
								else
								{
									// Create a new user if we don't already have one
									CreateLocalUser(PlatformUserIdStr, EntityIdStr, EntityTokenStr, TokenExpirationStr);
								}

								TimeSinceLastAuth = 0.0f;
								UsersToAuth.Remove(PlatformUserIdStr);
							}
							else
							{
								// MS_ATG_PNF: in error cases, the user will re-auth on the next attempt
								UE_LOG_ONLINE(Error, TEXT("[FOnlineIdentityPlayFabParty::Auth_HttpRequestComplete] Failed to parse EntityId data"));
							}
						}
						else
						{
							// MS_ATG_PNF: in error cases, the user will re-auth on the next attempt
							UE_LOG_ONLINE(Error, TEXT("[FOnlineIdentityPlayFabParty::Auth_HttpRequestComplete] Failed to parse Entity data"));
						}
					}
					else
					{
						// MS_ATG_PNF: in error cases, the user will re-auth on the next attempt
						UE_LOG_ONLINE(Error, TEXT("[FOnlineIdentityPlayFabParty::Auth_HttpRequestComplete] Failed to parse EntityToken data"));
					}
				}
				else
				{
					// MS_ATG_PNF: in error cases, the user will re-auth on the next attempt
					UE_LOG_ONLINE(Error, TEXT("[FOnlineIdentityPlayFabParty::Auth_HttpRequestComplete] Failed to parse EntityToken data"));
				}
			}
			else
			{
				// MS_ATG_PNF: in error cases, the user will re-auth on the next attempt
				UE_LOG_ONLINE(Error, TEXT("[FOnlineIdentityPlayFabParty::Auth_HttpRequestComplete] Failed to parse JSON data"));
			}
		}
		else
		{
			// MS_ATG_PNF: in error cases, the user will re-auth on the next attempt
			UE_LOG_ONLINE(Error, TEXT("[FOnlineIdentityPlayFabParty::Auth_HttpRequestComplete] Failed to deserialize response"));
		}
	}

	// Remove the in flight data
	UserAuthRequestsInFlight.Remove(PlatformUserIdStr);
}

void FOnlineIdentityPlayFabParty::CreateLocalUser(const FString& PlatformUserIdStr, const FString& EntityId, const FString& EntityToken, const FString& TokenExpiration)
{
	UE_LOG_ONLINE_IDENTITY(Verbose, TEXT("FOnlineIdentityPlayFabParty::CreateLocalUser"));

	PartyLocalUser* NewPartyLocalUser = nullptr;
	PartyError Err;

	// Create a local user object
	Err = PartyManager::GetSingleton().CreateLocalUser(
		TCHAR_TO_ANSI(*EntityId),		// User id
		TCHAR_TO_ANSI(*EntityToken),	// User entity token
		&NewPartyLocalUser				// OUT local user object
	);

	if (PARTY_FAILED(Err))
	{
		UE_LOG_ONLINE(Warning, TEXT("FOnlineSubsystemPlayFabParty::CreateLocalUser failed: %s"), *GetPartyErrorMessage(Err));
	}

	if (NewPartyLocalUser)
	{
		FPlayFabPartyUser* NewLocalUser = new FPlayFabPartyUser(PlatformUserIdStr, EntityToken, NewPartyLocalUser);
		LocalPlayFabUsers.Add(NewLocalUser);
	}
}

void FOnlineIdentityPlayFabParty::RemoveLocalUser(const FString& PlatformUserIdStr)
{
	UE_LOG_ONLINE_IDENTITY(Verbose, TEXT("FOnlineIdentityPlayFabParty::RemoveLocalUser"));

	if (PlatformUserIdStr.IsEmpty() == false)
	{
		UserAuthRequestsInFlight.Remove(PlatformUserIdStr);
		UsersToAuth.Remove(PlatformUserIdStr);

		for (int32 i = 0; i < LocalPlayFabUsers.Num(); ++i)
		{
			FPlayFabPartyUser* LocalUser = LocalPlayFabUsers[i];
			if (LocalUser->GetPlatformUserId().Compare(PlatformUserIdStr, ESearchCase::IgnoreCase) == 0)
			{
				PartyError Err = PartyManager::GetSingleton().DestroyLocalUser(LocalUser->GetPartyLocalUser(), nullptr);
				if (PARTY_FAILED(Err))
				{
					UE_LOG_ONLINE(Warning, TEXT("FOnlineSubsystemPlayFabParty::DestroyLocalUser failed: %s"), *GetPartyErrorMessage(Err));
				}
				else
				{
					LocalPlayFabUsers.Remove(LocalUser);
					delete LocalUser;
				}

				break;
			}
		}
	}
}

FPlayFabPartyUser* FOnlineIdentityPlayFabParty::GetPartyLocalUserFromPlatformId(const FUniqueNetId& PlatformNetId)
{
	return GetPartyLocalUserFromPlatformIdString(PlatformNetId.ToString());
}

FPlayFabPartyUser* FOnlineIdentityPlayFabParty::GetPartyLocalUserFromPlatformIdString(const FString& PlatformNetIdStr)
{
	if (PlatformNetIdStr.IsEmpty() == false)
	{
		for (FPlayFabPartyUser* LocalUser : LocalPlayFabUsers)
		{
			if (LocalUser->GetPlatformUserId().Compare(PlatformNetIdStr, ESearchCase::IgnoreCase) == 0)
			{
				return LocalUser;
			}
		}
	}

	return nullptr;
}

FDelegateHandle FOnlineIdentityPlayFabParty::AddOnLoginChangedDelegate_Handle(const FOnLoginChangedDelegate& Delegate)
{
	OSS_PFP_GET_NATIVE_IDENTITY_INTERFACE
	{
		return NativeIdentityInterface->AddOnLoginChangedDelegate_Handle(Delegate);
	}

	return FDelegateHandle();
}

void FOnlineIdentityPlayFabParty::ClearOnLoginChangedDelegate_Handle(FDelegateHandle& Handle)
{
	OSS_PFP_GET_NATIVE_IDENTITY_INTERFACE
	{
		return NativeIdentityInterface->ClearOnLoginChangedDelegate_Handle(Handle);
	}
}

void FOnlineIdentityPlayFabParty::TriggerOnLoginChangedDelegates(int32 LocalUserNum)
{
	OSS_PFP_GET_NATIVE_IDENTITY_INTERFACE
	{
		return NativeIdentityInterface->TriggerOnLoginChangedDelegates(LocalUserNum);
	}
}

FDelegateHandle FOnlineIdentityPlayFabParty::AddOnLoginStatusChangedDelegate_Handle(int32 LocalUserNum, const FOnLoginStatusChangedDelegate& Delegate)
{
	OSS_PFP_GET_NATIVE_IDENTITY_INTERFACE
	{
		return NativeIdentityInterface->AddOnLoginStatusChangedDelegate_Handle(LocalUserNum, Delegate);
	}

	return FDelegateHandle();
}

void FOnlineIdentityPlayFabParty::ClearOnLoginStatusChangedDelegate_Handle(int32 LocalUserNum, FDelegateHandle& Handle)
{
	OSS_PFP_GET_NATIVE_IDENTITY_INTERFACE
	{
		return NativeIdentityInterface->ClearOnLoginStatusChangedDelegate_Handle(LocalUserNum, Handle);
	}
}

void FOnlineIdentityPlayFabParty::TriggerOnLoginStatusChangedDelegates(int32 LocalUserNum, ELoginStatus::Type OldStatus, ELoginStatus::Type NewStatus, const FUniqueNetId& NewId)
{
	OSS_PFP_GET_NATIVE_IDENTITY_INTERFACE
	{
		return NativeIdentityInterface->TriggerOnLoginStatusChangedDelegates(LocalUserNum, OldStatus, NewStatus, NewId);
	}
}

FDelegateHandle FOnlineIdentityPlayFabParty::AddOnControllerPairingChangedDelegate_Handle(const FOnControllerPairingChangedDelegate& Delegate)
{
	OSS_PFP_GET_NATIVE_IDENTITY_INTERFACE
	{
		return NativeIdentityInterface->AddOnControllerPairingChangedDelegate_Handle(Delegate);
	}

	return FDelegateHandle();
}

void FOnlineIdentityPlayFabParty::ClearOnControllerPairingChangedDelegate_Handle(FDelegateHandle& Handle)
{
	OSS_PFP_GET_NATIVE_IDENTITY_INTERFACE
	{
		return NativeIdentityInterface->ClearOnControllerPairingChangedDelegate_Handle(Handle);
	}
}

void FOnlineIdentityPlayFabParty::TriggerOnControllerPairingChangedDelegates(int LocalUserNum, FControllerPairingChangedUserInfo PreviousUser, FControllerPairingChangedUserInfo NewUser)
{
	OSS_PFP_GET_NATIVE_IDENTITY_INTERFACE
	{
		return NativeIdentityInterface->TriggerOnControllerPairingChangedDelegates(LocalUserNum, PreviousUser, NewUser);
	}
}

FDelegateHandle FOnlineIdentityPlayFabParty::AddOnLoginCompleteDelegate_Handle(int32 LocalUserNum, const FOnLoginCompleteDelegate& Delegate)
{
	OSS_PFP_GET_NATIVE_IDENTITY_INTERFACE
	{
		return NativeIdentityInterface->AddOnLoginCompleteDelegate_Handle(LocalUserNum, Delegate);
	}

	return FDelegateHandle();
}

void FOnlineIdentityPlayFabParty::ClearOnLoginCompleteDelegate_Handle(int32 LocalUserNum, FDelegateHandle& Handle)
{
	OSS_PFP_GET_NATIVE_IDENTITY_INTERFACE
	{
		return NativeIdentityInterface->ClearOnLoginCompleteDelegate_Handle(LocalUserNum, Handle);
	}
}

void FOnlineIdentityPlayFabParty::TriggerOnLoginCompleteDelegates(int32 LocalUserNum, bool bWasSuccessful, const FUniqueNetId& UserId, const FString& Error)
{
	OSS_PFP_GET_NATIVE_IDENTITY_INTERFACE
	{
		return NativeIdentityInterface->TriggerOnLoginCompleteDelegates(LocalUserNum, bWasSuccessful, UserId, Error);
	}
}

FDelegateHandle FOnlineIdentityPlayFabParty::AddOnLogoutCompleteDelegate_Handle(int32 LocalUserNum, const FOnLogoutCompleteDelegate& Delegate)
{
	OSS_PFP_GET_NATIVE_IDENTITY_INTERFACE
	{
		return NativeIdentityInterface->AddOnLogoutCompleteDelegate_Handle(LocalUserNum, Delegate);
	}

	return FDelegateHandle();
}

void FOnlineIdentityPlayFabParty::ClearOnLogoutCompleteDelegate_Handle(int32 LocalUserNum, FDelegateHandle& Handle)
{
	OSS_PFP_GET_NATIVE_IDENTITY_INTERFACE
	{
		return NativeIdentityInterface->ClearOnLogoutCompleteDelegate_Handle(LocalUserNum, Handle);
	}
}

void FOnlineIdentityPlayFabParty::TriggerOnLogoutCompleteDelegates(int32 LocalUserNum, bool bWasSuccessful)
{
	OSS_PFP_GET_NATIVE_IDENTITY_INTERFACE
	{
		return NativeIdentityInterface->TriggerOnLogoutCompleteDelegates(LocalUserNum, bWasSuccessful);
	}
}

FDelegateHandle FOnlineIdentityPlayFabParty::AddOnLoginFlowLogoutDelegate_Handle(const FOnLoginFlowLogoutDelegate& Delegate)
{
	OSS_PFP_GET_NATIVE_IDENTITY_INTERFACE
	{
		return NativeIdentityInterface->AddOnLoginFlowLogoutDelegate_Handle(Delegate);
	}

	return FDelegateHandle();
}

void FOnlineIdentityPlayFabParty::ClearOnLoginFlowLogoutDelegate_Handle(FDelegateHandle& Handle)
{
	OSS_PFP_GET_NATIVE_IDENTITY_INTERFACE
	{
		return NativeIdentityInterface->ClearOnLoginFlowLogoutDelegate_Handle(Handle);
	}
}

void FOnlineIdentityPlayFabParty::TriggerOnLoginFlowLogoutDelegates(const TArray<FString>& LoginDomains)
{
	OSS_PFP_GET_NATIVE_IDENTITY_INTERFACE
	{
		return NativeIdentityInterface->TriggerOnLoginFlowLogoutDelegates(LoginDomains);
	}
}

PartyLocalUser* FOnlineIdentityPlayFabParty::GetFirstPartyLocalUser()
{
	if (LocalPlayFabUsers.Num() > 0)
	{
		return LocalPlayFabUsers[0]->GetPartyLocalUser();
	}

	return nullptr;
}

void FPlayFabPartyUser::UpdateEntityToken(const FString& NewEntityToken)
{
	UE_LOG_ONLINE_IDENTITY(Verbose, TEXT("FOnlineIdentityPlayFabParty::UpdateEntityToken"));

	if (NewEntityToken.IsEmpty() == false)
	{
		if (LocalUser)
		{
			PartyError Err = LocalUser->UpdateEntityToken(TCHAR_TO_ANSI(*NewEntityToken));
			if (PARTY_FAILED(Err))
			{
				UE_LOG_ONLINE(Warning, TEXT("FPlayFabPartyUser::UpdateEntityToken failed: %s"), *GetPartyErrorMessage(Err));
			}
			else
			{
				EntityToken = NewEntityToken;
				SetNewEntityTokenUpdateTime();
			}
		}
	}
}

void FPlayFabPartyUser::SetNewEntityTokenUpdateTime()
{
	EntityTokenUpdateTime = FDateTime::Now() + FTimespan::FromHours(12.0f);
}