//--------------------------------------------------------------------------------------
// Copyright (C) Microsoft Corporation. All rights reserved.
//--------------------------------------------------------------------------------------

#pragma once

#include "CoreMinimal.h"
#include "UObject/ObjectMacros.h"
#include "IpNetDriver.h"
#include "OnlineSubsystemPlayFabPartyPackage.h"
#include <Party.h>
#include "PlayFabPartyNetDriver.generated.h"

using namespace Party;

class FNetworkNotify;

UCLASS(transient, config=Engine)
class UPlayFabPartyNetDriver : public UIpNetDriver
{
	GENERATED_UCLASS_BODY()

public:
	UPlayFabPartyNetDriver() = default;

	// UIpNetDriver Interface
	virtual class ISocketSubsystem* GetSocketSubsystem() override;
	virtual bool IsAvailable() const override;
	virtual bool InitBase(bool bInitAsClient, FNetworkNotify* InNotify, const FURL& URL, bool bReuseAddressAndPort, FString& Error) override;
	virtual bool InitListen(FNetworkNotify* InNotify, FURL& LocalURL, bool bReuseAddressAndPort, FString& Error) override;
	virtual bool InitConnect(FNetworkNotify* InNotify, const FURL& ConnectURL, FString& Error) override;
	virtual void Shutdown() override;
	virtual bool IsNetResourceValid() override { return true; }
	virtual void TickDispatch(float DeltaTime) override;

	class FOnlineSubsystemPlayFabParty* GetOnlineSubsystemPlayFabParty();
	class FPlayFabPartySocketSubsystem* GetPlayFabPartySocketSubsystem();

protected:

	friend class FPlayFabPartySocketSubsystem;
};