//--------------------------------------------------------------------------------------
// Copyright (C) Microsoft Corporation. All rights reserved.
//--------------------------------------------------------------------------------------

#include "OnlineSubsystemPlayFabParty.h"
#include "OnlineIdentityInterfacePlayFabParty.h"
#include "PlayFabPartySocketSubsystem.h"
#include "Interfaces/IPluginManager.h"
#include "SocketSubsystem.h"
#include "IpConnection.h"
#include "PlayFabPartyNetDriver.h"

#include "EngineLogs.h"
#include "CoreGlobals.h"
#include "OnlineSessionInterfacePlayFabParty.h"
#include "Engine/Engine.h"
#include <PartyImpl.h>
#include <PartyTypes.h>

PFP_OSS_PASSTHROUGH_FUNCTION_DEFINITION(IOnlineFriendsPtr, GetFriendsInterface);
PFP_OSS_PASSTHROUGH_FUNCTION_DEFINITION(IOnlinePartyPtr, GetPartyInterface);
PFP_OSS_PASSTHROUGH_FUNCTION_DEFINITION(IOnlineGroupsPtr, GetGroupsInterface);
PFP_OSS_PASSTHROUGH_FUNCTION_DEFINITION(IOnlineSharedCloudPtr, GetSharedCloudInterface);
PFP_OSS_PASSTHROUGH_FUNCTION_DEFINITION(IOnlineUserCloudPtr, GetUserCloudInterface);
PFP_OSS_PASSTHROUGH_FUNCTION_DEFINITION(IOnlineLeaderboardsPtr, GetLeaderboardsInterface);
PFP_OSS_PASSTHROUGH_FUNCTION_DEFINITION(IOnlineExternalUIPtr, GetExternalUIInterface);
PFP_OSS_PASSTHROUGH_FUNCTION_DEFINITION(IOnlineTimePtr, GetTimeInterface);
PFP_OSS_PASSTHROUGH_FUNCTION_DEFINITION(IOnlineTitleFilePtr, GetTitleFileInterface);
PFP_OSS_PASSTHROUGH_FUNCTION_DEFINITION(IOnlineEntitlementsPtr, GetEntitlementsInterface);
PFP_OSS_PASSTHROUGH_FUNCTION_DEFINITION(IOnlineStorePtr, GetStoreInterface);
PFP_OSS_PASSTHROUGH_FUNCTION_DEFINITION(IOnlineStoreV2Ptr, GetStoreV2Interface);
PFP_OSS_PASSTHROUGH_FUNCTION_DEFINITION(IOnlinePurchasePtr, GetPurchaseInterface);
PFP_OSS_PASSTHROUGH_FUNCTION_DEFINITION(IOnlineEventsPtr, GetEventsInterface);
PFP_OSS_PASSTHROUGH_FUNCTION_DEFINITION(IOnlineAchievementsPtr, GetAchievementsInterface);
PFP_OSS_PASSTHROUGH_FUNCTION_DEFINITION(IOnlineSharingPtr, GetSharingInterface);
PFP_OSS_PASSTHROUGH_FUNCTION_DEFINITION(IOnlineUserPtr, GetUserInterface);
PFP_OSS_PASSTHROUGH_FUNCTION_DEFINITION(IOnlineMessagePtr, GetMessageInterface);
PFP_OSS_PASSTHROUGH_FUNCTION_DEFINITION(IOnlinePresencePtr, GetPresenceInterface);
PFP_OSS_PASSTHROUGH_FUNCTION_DEFINITION(IOnlineChatPtr, GetChatInterface);
PFP_OSS_PASSTHROUGH_FUNCTION_DEFINITION(IOnlineStatsPtr, GetStatsInterface);
PFP_OSS_PASSTHROUGH_FUNCTION_DEFINITION(IOnlineTurnBasedPtr, GetTurnBasedInterface);
PFP_OSS_PASSTHROUGH_FUNCTION_DEFINITION(IOnlineTournamentPtr, GetTournamentInterface);

namespace
{
	void* PlayFabPartyAlloc(size_t Size, uint32_t MemoryTypeId)
	{
		return FMemory::Malloc(Size);
	}

	void PlayFabPartyFree(void* PointerToMemory, uint32_t MemoryTypeId)
	{
		FMemory::Free(PointerToMemory);
	}
}

namespace FNetworkProtocolTypes
{
	const FLazyName PlayFabParty(TEXT("PlayFabParty"));
}

bool FOnlineSubsystemPlayFabParty::Init()
{
	UE_LOG_ONLINE(Verbose, TEXT("FOnlineSubsystemPlayFabParty::Init"));
	
	// Register for suspend/resume callbacks
	FCoreDelegates::ApplicationWillEnterBackgroundDelegate.AddRaw(this, &FOnlineSubsystemPlayFabParty::OnAppSuspend);
	FCoreDelegates::ApplicationHasEnteredForegroundDelegate.AddRaw(this, &FOnlineSubsystemPlayFabParty::OnAppResume);
	
	RegisterNetworkInitCallbacks();

	// Try to initialize PlayFab Party if the platform is ready
	TryInitializePlayFabParty();

	GConfig->GetInt(TEXT("OnlineSubsystemPlayFabParty"), TEXT("MaxDeviceCount"), MaxDeviceCount, GEngineIni);
	GConfig->GetInt(TEXT("OnlineSubsystemPlayFabParty"), TEXT("MaxDevicesPerUserCount"), MaxDevicesPerUserCount, GEngineIni);
	GConfig->GetInt(TEXT("OnlineSubsystemPlayFabParty"), TEXT("MaxEndpointsPerDeviceCount"), MaxEndpointsPerDeviceCount, GEngineIni);
	GConfig->GetInt(TEXT("OnlineSubsystemPlayFabParty"), TEXT("MaxUserCount"), MaxUserCount, GEngineIni);
	GConfig->GetInt(TEXT("OnlineSubsystemPlayFabParty"), TEXT("MaxUsersPerDeviceCount"), MaxUsersPerDeviceCount, GEngineIni);

	TSharedPtr<IPlugin> SocketsPlugin = IPluginManager::Get().FindPlugin(TEXT("PlayFabParty"));
	if (!SocketsPlugin.IsValid() || (SocketsPlugin.IsValid() && !SocketsPlugin->IsEnabled()))
	{
		UE_LOG_ONLINE(Log, TEXT("Initializing PlayFabPartSocketSubsystem"));
		CreatePlayFabPartySocketSubsystem();
	}

	if (FPlayFabPartySocketSubsystem* SocketSubsystem = static_cast<FPlayFabPartySocketSubsystem*>(ISocketSubsystem::Get(PLAYFABPARTY_SOCKET_SUBSYSTEM)))
	{
		SocketSubsystem->RegisterDelegates(this);
	}

	// Construct OSS interfaces
	IdentityInterface = MakeShared<FOnlineIdentityPlayFabParty, ESPMode::ThreadSafe>(this);
	SessionInterface = MakeShared<FOnlineSessionPlayFabParty, ESPMode::ThreadSafe>(this);
	VoiceInterface = MakeShared<FOnlineVoicePlayFabParty, ESPMode::ThreadSafe>(this);
	CognitiveServicesInterface = MakeShared<FOnlineCognitiveServicesPlayFabParty, ESPMode::ThreadSafe>(this);

	return true;
}

void FOnlineSubsystemPlayFabParty::InitializePlayFabParty()
{
	if (bPartyInitialized == false)
	{
		UE_LOG_ONLINE(Verbose, TEXT("FOnlineSubsystemPlayFabParty::InitializePlayFabParty"));

		SetMemoryCallbacks();

		PartyManager& Manager = PartyManager::GetSingleton();

		FString TitleID;
		GConfig->GetString(TEXT("OnlineSubsystemPlayFabParty"), TEXT("PlayFabTitleID"), TitleID, GEngineIni);

		// Initialize PlayFab Party
		PartyError Err = Manager.Initialize(TCHAR_TO_ANSI(*TitleID));
		if (PARTY_FAILED(Err))
		{
			UE_LOG_ONLINE(Error, TEXT("FOnlineSubsystemPlayFabParty::InitializePlayFabParty: Initialize failed: %s"), *GetPartyErrorMessage(Err));
			return;
		}

		UE_LOG_ONLINE(Display, TEXT("FOnlineSubsystemPlayFabParty Initialized with PlayFab TitleID %s"), *TitleID);
		bPartyInitialized = true;
	}
}

void FOnlineSubsystemPlayFabParty::SetMemoryCallbacks()
{
	// Only needs to be called once
	if (bMemoryCallbacksSet == false)
	{
		UE_LOG_ONLINE(Verbose, TEXT("FOnlineSubsystemPlayFabParty::SetMemoryCallbacks"));

		PartyManager& Manager = PartyManager::GetSingleton();

		PartyError Err = Manager.SetMemoryCallbacks(PlayFabPartyAlloc, PlayFabPartyFree);
		if (PARTY_FAILED(Err))
		{
			UE_LOG_ONLINE(Error, TEXT("FOnlineSubsystemPlayFabParty::InitializePlayFabParty: SetMemoryCallbacks failed: %s"), *GetPartyErrorMessage(Err));
		}

		bMemoryCallbacksSet = true;
	}
}

void FOnlineSubsystemPlayFabParty::CleanUpPlayFabParty()
{
	if (bPartyInitialized)
	{
		UE_LOG_ONLINE(Verbose, TEXT("FOnlineSubsystemPlayFabParty::CleanUpPlayFabParty"));

		bPartyInitialized = false;

		NetworkState = EPlayFabPartyNetworkState::NoNetwork;
		Network = nullptr;

		// This cleans up everything allocated in PartyManager.Initialize() and
		// should only be used when done with networking
		PartyManager::GetSingleton().Cleanup();
	}
}

bool FOnlineSubsystemPlayFabParty::Shutdown()
{
	UE_LOG_ONLINE(Display, TEXT("OnlineSubsystemPlayFabParty::Shutdown()"));

	FOnlineSubsystemImpl::Shutdown();

	NetworkState = EPlayFabPartyNetworkState::NoNetwork;

#define DESTRUCT_INTERFACE(Interface) \
	if (Interface.IsValid()) \
	{ \
		ensure(Interface.IsUnique()); \
		Interface = nullptr; \
	}

	// Destruct the interfaces (in opposite order they were created)
	DESTRUCT_INTERFACE(IdentityInterface);
	DESTRUCT_INTERFACE(SessionInterface);
	DESTRUCT_INTERFACE(VoiceInterface);
	DESTRUCT_INTERFACE(CognitiveServicesInterface);

#undef DESTRUCT_INTERFACE

	DestroyPlayFabPartySocketSubsystem();

	CleanUpPlayFabParty();

	UnregisterNetworkInitCallbacks();

	// Unregister for suspend/resume callbacks
	FCoreDelegates::ApplicationWillEnterBackgroundDelegate.RemoveAll(this);
	FCoreDelegates::ApplicationHasEnteredForegroundDelegate.RemoveAll(this);

	return true;
}

bool FOnlineSubsystemPlayFabParty::Exec(class UWorld* InWorld, const TCHAR* Cmd, FOutputDevice& Ar)
{
	if (FOnlineSubsystemImpl::Exec(InWorld, Cmd, Ar))
	{
		return true;
	}

	bool bWasHandled = false;

	return bWasHandled;
}

bool FOnlineSubsystemPlayFabParty::IsEnabled() const
{
	// Check the ini for disabling PFP
	bool bEnablePlayFabParty = FOnlineSubsystemImpl::IsEnabled();
	if (bEnablePlayFabParty)
	{
#if UE_EDITOR
		if (bEnablePlayFabParty)
		{
			bEnablePlayFabParty = IsRunningDedicatedServer() || IsRunningGame();
		}
#endif
	}

	return bEnablePlayFabParty;
}

FString FOnlineSubsystemPlayFabParty::GetAppId() const
{
	FString TitleID;
	GConfig->GetString(TEXT("OnlineSubsystemPlayFabParty"), TEXT("PlayFabTitleID"), TitleID, GEngineIni);
	return TitleID;
}

FText FOnlineSubsystemPlayFabParty::GetOnlineServiceName() const
{
	return NSLOCTEXT("OnlineSubsystemPlayFabParty", "OnlineServiceName", "PlayFabParty");
}

void FOnlineSubsystemPlayFabParty::OnAppSuspend()
{
	UE_LOG_ONLINE(Verbose, TEXT("FOnlineSubsystemPlayFabParty::OnAppSuspend"));

	if (IdentityInterface.IsValid())
	{
		IdentityInterface->OnAppSuspend();
	}

	if (VoiceInterface.IsValid())
	{
		VoiceInterface->OnAppSuspend();
	}
	
	CleanUpPlayFabParty();
}

void FOnlineSubsystemPlayFabParty::OnAppResume()
{
	UE_LOG_ONLINE(Verbose, TEXT("FOnlineSubsystemPlayFabParty::OnAppResume"));

	TryInitializePlayFabParty();

	if (IdentityInterface.IsValid())
	{
		IdentityInterface->OnAppResume();
	}

	if (VoiceInterface.IsValid())
	{
		VoiceInterface->OnAppResume();
	}
}

bool FOnlineSubsystemPlayFabParty::Tick(float DeltaTime)
{
	if (!FOnlineSubsystemImpl::Tick(DeltaTime))
	{
		return false;
	}

	if (IdentityInterface.IsValid())
	{
		IdentityInterface->Tick(DeltaTime);
	}

	DoWork();

	if (VoiceInterface.IsValid())
	{
		VoiceInterface->Tick(DeltaTime);
	}

	return true;
}

IOnlineIdentityPtr FOnlineSubsystemPlayFabParty::GetIdentityInterface() const
{
	return IdentityInterface;
}

IOnlineSessionPtr FOnlineSubsystemPlayFabParty::GetSessionInterface() const
{
	return SessionInterface;
}

IOnlineVoicePtr FOnlineSubsystemPlayFabParty::GetVoiceInterface() const
{
	return VoiceInterface;
}

FOnlineCognitiveServicesPlayFabPartyPtr FOnlineSubsystemPlayFabParty::GetCognitiveServicesInterface() const
{
	return CognitiveServicesInterface;
}

bool FOnlineSubsystemPlayFabParty::IsLocalPlayer(const FUniqueNetId& UniqueId) const
{
	if (!IsDedicated())
	{
		IOnlineIdentityPtr IdentityInt = GetIdentityInterface();
		if (IdentityInt.IsValid())
		{
			for (int32 LocalUserNum = 0; LocalUserNum < MAX_LOCAL_PLAYERS; LocalUserNum++)
			{
				TSharedPtr<const FUniqueNetId> LocalUniqueId = IdentityInt->GetUniquePlayerId(LocalUserNum);
				if (LocalUniqueId.IsValid() && UniqueId == *LocalUniqueId)
				{
					return true;
				}
			}
		}
	}

	return false;
}

void FOnlineSubsystemPlayFabParty::DoWork()
{
	if (bPartyInitialized == false)
	{
		return;
	}
	
	uint32_t Count;
	PartyStateChangeArray Changes;
	PartyManager& Manager = PartyManager::GetSingleton();

	// Start processing messages from PlayFab Party
	PartyError Err = Manager.StartProcessingStateChanges(&Count, &Changes);
	if (PARTY_FAILED(Err))
	{
		UE_LOG_ONLINE(Warning, TEXT("FOnlineSubsystemPlayFabParty::DoWork: StartProcessingStateChanges failed: %s"), *GetPartyErrorMessage(Err));
		return;
	}

	for (uint32_t i = 0; i < Count; i++)
	{
		const PartyStateChange* Change = Changes[i];

		if (Change)
		{
			switch (Change->stateChangeType)
			{
			case PartyStateChangeType::RegionsChanged:									 OnRegionsChanged(Change); break;
			case PartyStateChangeType::DestroyLocalUserCompleted:						 OnDestroyLocalUserCompleted(Change); break;
			case PartyStateChangeType::CreateNewNetworkCompleted:						 OnCreateNewNetworkCompleted(Change); break;
			case PartyStateChangeType::ConnectToNetworkCompleted:						 OnConnectToNetworkCompleted(Change); break;
			case PartyStateChangeType::AuthenticateLocalUserCompleted:					 OnAuthenticateLocalUserCompleted(Change); break;
			case PartyStateChangeType::NetworkConfigurationMadeAvailable:				 OnNetworkConfigurationMadeAvailable(Change); break;
			case PartyStateChangeType::NetworkDescriptorChanged:						 OnNetworkDescriptorChanged(Change); break;
			case PartyStateChangeType::LocalUserRemoved:								 OnLocalUserRemoved(Change); break;
			case PartyStateChangeType::RemoveLocalUserCompleted:						 OnRemoveLocalUserCompleted(Change); break;
			case PartyStateChangeType::LocalUserKicked:									 OnLocalUserKicked(Change); break;
			case PartyStateChangeType::CreateEndpointCompleted:							 OnCreateEndpointCompleted(Change); break;
			case PartyStateChangeType::DestroyEndpointCompleted:						 OnDestroyEndpointCompleted(Change); break;
			case PartyStateChangeType::EndpointCreated:									 OnEndpointCreated(Change); break;
			case PartyStateChangeType::EndpointDestroyed:								 OnEndpointDestroyed(Change); break;
			case PartyStateChangeType::RemoteDeviceCreated:								 OnRemoteDeviceCreated(Change); break;
			case PartyStateChangeType::RemoteDeviceDestroyed:							 OnRemoteDeviceDestroyed(Change); break;
			case PartyStateChangeType::RemoteDeviceJoinedNetwork:						 OnRemoteDeviceJoinedNetwork(Change); break;
			case PartyStateChangeType::RemoteDeviceLeftNetwork:							 OnRemoteDeviceLeftNetwork(Change); break;
			case PartyStateChangeType::DevicePropertiesChanged:							 OnDevicePropertiesChanged(Change); break;
			case PartyStateChangeType::LeaveNetworkCompleted:							 OnLeaveNetworkCompleted(Change); break;
			case PartyStateChangeType::NetworkDestroyed:								 OnNetworkDestroyed(Change); break;
			case PartyStateChangeType::EndpointMessageReceived:							 OnEndpointMessageReceived(Change); break;
			case PartyStateChangeType::DataBuffersReturned:								 OnDataBuffersReturned(Change); break;
			case PartyStateChangeType::EndpointPropertiesChanged:						 OnEndpointPropertiesChanged(Change); break;
			case PartyStateChangeType::SynchronizeMessagesBetweenEndpointsCompleted:	 OnSynchronizeMessagesBetweenEndpointsCompleted(Change); break;
			case PartyStateChangeType::CreateInvitationCompleted:						 OnCreateInvitationCompleted(Change); break;
			case PartyStateChangeType::RevokeInvitationCompleted:						 OnRevokeInvitationCompleted(Change); break;
			case PartyStateChangeType::InvitationCreated:								 OnInvitationCreated(Change); break;
			case PartyStateChangeType::InvitationDestroyed:								 OnInvitationDestroyed(Change); break;
			case PartyStateChangeType::NetworkPropertiesChanged:						 OnNetworkPropertiesChanged(Change); break;
			case PartyStateChangeType::KickDeviceCompleted:								 OnKickDeviceCompleted(Change); break;
			case PartyStateChangeType::KickUserCompleted:								 OnKickUserCompleted(Change); break;
			case PartyStateChangeType::ChatControlJoinedNetwork:						 VoiceInterface->OnChatControlJoinedNetwork(Change); break;
			case PartyStateChangeType::ChatControlLeftNetwork:							 VoiceInterface->OnChatControlLeftNetwork(Change); break;
			case PartyStateChangeType::ChatControlDestroyed:							 VoiceInterface->OnChatControlDestroyed(Change); break;
			case PartyStateChangeType::ChatControlCreated:								 VoiceInterface->OnChatControlCreated(Change); break;
			case PartyStateChangeType::ConnectChatControlCompleted:						 VoiceInterface->OnConnectChatControlCompleted(Change); break;
			case PartyStateChangeType::CreateChatControlCompleted:						 VoiceInterface->OnCreateChatControlCompleted(Change); break;
			case PartyStateChangeType::DestroyChatControlCompleted:						 VoiceInterface->OnDestroyChatControlCompleted(Change); break;
			case PartyStateChangeType::LocalChatAudioInputChanged:						 VoiceInterface->OnLocalChatAudioInputChanged(Change); break;
			case PartyStateChangeType::SetChatAudioInputCompleted:						 VoiceInterface->OnSetChatAudioInputCompleted(Change); break;
			case PartyStateChangeType::SetChatAudioOutputCompleted:						 VoiceInterface->OnSetChatAudioOutputCompleted(Change); break;
			case PartyStateChangeType::SetChatAudioEncoderBitrateCompleted:				 OnSetChatAudioEncoderBitrateCompleted(Change); break;
			case PartyStateChangeType::LocalChatAudioOutputChanged:						 OnLocalChatAudioOutputChanged(Change); break;
			case PartyStateChangeType::SetLanguageCompleted:							 OnSetLanguageCompleted(Change); break;
			case PartyStateChangeType::ChatControlPropertiesChanged:					 OnChatControlPropertiesChanged(Change); break;
			case PartyStateChangeType::DisconnectChatControlCompleted:					 OnDisconnectChatControlCompleted(Change); break;
			case PartyStateChangeType::ConfigureAudioManipulationVoiceStreamCompleted:	 OnConfigureAudioManipulationVoiceStreamCompleted(Change); break;
			case PartyStateChangeType::ConfigureAudioManipulationCaptureStreamCompleted: OnConfigureAudioManipulationCaptureStreamCompleted(Change); break;
			case PartyStateChangeType::ConfigureAudioManipulationRenderStreamCompleted:	 OnConfigureAudioManipulationRenderStreamCompleted(Change); break;
			case PartyStateChangeType::ChatTextReceived:								 CognitiveServicesInterface->OnChatTextReceived(Change); break;
			case PartyStateChangeType::VoiceChatTranscriptionReceived:					 CognitiveServicesInterface->OnVoiceChatTranscriptionReceived(Change); break;
			case PartyStateChangeType::SetTextToSpeechProfileCompleted:					 CognitiveServicesInterface->OnSetTextToSpeechProfileCompleted(Change); break;
			case PartyStateChangeType::SynthesizeTextToSpeechCompleted:					 CognitiveServicesInterface->OnSynthesizeTextToSpeechCompleted(Change); break;
			case PartyStateChangeType::SetTranscriptionOptionsCompleted:				 CognitiveServicesInterface->OnSetTranscriptionOptionsCompleted(Change); break;
			case PartyStateChangeType::SetTextChatOptionsCompleted:						 CognitiveServicesInterface->OnSetTextChatOptionsCompleted(Change); break;
			case PartyStateChangeType::PopulateAvailableTextToSpeechProfilesCompleted:	 CognitiveServicesInterface->OnPopulateAvailableTextToSpeechProfilesCompleted(Change); break;
			}
		}
	}
	
	// Return the processed changes back to the PartyManager
	Err = Manager.FinishProcessingStateChanges(Count, Changes);
	if (PARTY_FAILED(Err))
	{
		UE_LOG_ONLINE(Warning, TEXT("FOnlineSubsystemPlayFabParty::DoWork: FinishProcessingStateChanges failed: %s"), *GetPartyErrorMessage(Err));
	}
}

bool FOnlineSubsystemPlayFabParty::CreateAndConnectToPlayFabPartyNetwork()
{
	UE_LOG_ONLINE(Log, TEXT("FOnlineSubsystemPlayFabParty::CreateAndConnectToPlayFabPartyNetwork()"));

	if (bPartyInitialized == false)
	{
		UE_LOG_ONLINE(Warning, TEXT("FOnlineSubsystemPlayFabParty::CreateAndConnectToPlayFabPartyNetwork: Cannot create to playfab network, PartyManager is not initialized."));
		return false;
	}

	if (NetworkState != EPlayFabPartyNetworkState::NoNetwork || Network != nullptr)
	{
		UE_LOG_ONLINE(Warning, TEXT("FOnlineSubsystemPlayFabParty::CreateAndConnectToPlayFabPartyNetwork: Cannot create to playfab network while already connected to a network."));
		return false;
	}

	PartyLocalUser* PlayFabPartyLocalUser = IdentityInterface ? IdentityInterface->GetFirstPartyLocalUser() : nullptr;
	if (PlayFabPartyLocalUser == nullptr)
	{
		UE_LOG_ONLINE(Warning, TEXT("FOnlineSubsystemPlayFabParty::CreateAndConnectToPlayFabPartyNetwork: Could not create new network PlayFabPartyLocalUser was null"));
		return false;
	}

	FString NewNetworkId = FGuid::NewGuid().ToString();

	PartyNetworkConfiguration PlayFabPartyNetworkConfig = {};

	// Setup the network using values from config
	PlayFabPartyNetworkConfig.maxDeviceCount = MaxDeviceCount;				
	PlayFabPartyNetworkConfig.maxDevicesPerUserCount = MaxDevicesPerUserCount;		
	PlayFabPartyNetworkConfig.maxEndpointsPerDeviceCount = MaxEndpointsPerDeviceCount;	
	PlayFabPartyNetworkConfig.maxUserCount = MaxUserCount;					
	PlayFabPartyNetworkConfig.maxUsersPerDeviceCount = MaxUsersPerDeviceCount;		

	// Setup the network invitation configuration to use the network id as an invitation id and allow anyone to join.
	PartyInvitationConfiguration PartyInviteConfig{
		TCHAR_TO_ANSI(*NewNetworkId),			// Invitation identifier
		PartyInvitationRevocability::Anyone,	// Revocability
		0,										// Authorized user count
		nullptr									// Authorized user list
	};

	PartyNetworkDescriptor NewNetworkDescriptor = {};

	// Create a new network descriptor
	PartyError Err = PartyManager::GetSingleton().CreateNewNetwork(
		PlayFabPartyLocalUser,		// Local User
		&PlayFabPartyNetworkConfig,	// Network Config
		0,							// Region List Count
		nullptr,					// Region List
		&PartyInviteConfig,			// Invitation configuration
		nullptr,					// Async Identifier
		&NewNetworkDescriptor,		// OUT network descriptor
		nullptr						// Applied initial invitation identifier
	);

	if (PARTY_FAILED(Err))
	{
		UE_LOG_ONLINE(Warning, TEXT("FOnlineSubsystemPlayFabParty::CreateAndConnectToPlayFabPartyNetwork: CreateNewNetwork failed: %s"), *GetPartyErrorMessage(Err));
		return false;
	}

	// Connect to the new network
	if (InternalConnectToNetwork(PlayFabPartyLocalUser, NewNetworkId, NewNetworkDescriptor))
	{
		NetworkState = EPlayFabPartyNetworkState::JoiningNetwork_Host;
		NetworkId = NewNetworkId;

		return true;
	}

	return false;
}

bool FOnlineSubsystemPlayFabParty::ConnectToPlayFabPartyNetwork(const FString& NewNetworkId, const FString& NewNetworkDescriptorStr)
{
	UE_LOG_ONLINE(Log, TEXT("FOnlineSubsystemPlayFabParty::ConnectToPlayFabPartyNetwork()"));

	if (bPartyInitialized == false)
	{
		UE_LOG_ONLINE(Warning, TEXT("FOnlineSubsystemPlayFabParty::ConnectToPlayFabPartyNetwork: Cannot connect to playfab network, PartyManager is not initialized."));
		return false;
	}

	if (NetworkState != EPlayFabPartyNetworkState::NoNetwork || Network != nullptr)
	{
		UE_LOG_ONLINE(Warning, TEXT("FOnlineSubsystemPlayFabParty::ConnectToPlayFabPartyNetwork: Cannot connect to playfab network while already connected to a network."));
		return false;
	}

	PartyLocalUser* PlayFabPartyLocalUser = IdentityInterface ? IdentityInterface->GetFirstPartyLocalUser() : nullptr;
	if (PlayFabPartyLocalUser == nullptr)
	{
		UE_LOG_ONLINE(Warning, TEXT("FOnlineSubsystemPlayFabParty::ConnectToPlayFabPartyNetwork: Could not create new network PlayFabPartyLocalUser was null"));
		return false;
	}

	PartyNetworkDescriptor NewNetworkDescriptor = {};

	// Deserialize the remote network's descriptor
	PartyError Err = PartyManager::DeserializeNetworkDescriptor(TCHAR_TO_ANSI(*NewNetworkDescriptorStr), &NewNetworkDescriptor);

	if (PARTY_FAILED(Err))
	{
		UE_LOG_ONLINE(Warning, TEXT("FOnlineSubsystemPlayFabParty::ConnectToPlayFabPartyNetwork: failed to deserialize descriptor: %s"), *GetPartyErrorMessage(Err));
		return false;
	}

	// Connect to the remote network
	if (InternalConnectToNetwork(PlayFabPartyLocalUser, NewNetworkId, NewNetworkDescriptor))
	{
		NetworkState = EPlayFabPartyNetworkState::JoiningNetwork_Client;
		NetworkId = NewNetworkId;

		return true;
	}

	return false;
}

bool FOnlineSubsystemPlayFabParty::AddChatControlToNetwork(PartyLocalChatControl* LocalChatControl)
{
	if (Network && NetworkState == EPlayFabPartyNetworkState::NetworkReady)
	{
		PartyError Err = Network->ConnectChatControl(LocalChatControl, nullptr);

		if (PARTY_FAILED(Err))
		{
			UE_LOG_ONLINE(Warning, TEXT("FOnlineSubsystemPlayFabParty::AddChatControlToNetwork failed: %s\n"), *GetPartyErrorMessage(Err));
			return false;
		}

		return true;
	}
	else
	{
		UE_LOG_ONLINE(Warning, TEXT("FOnlineSubsystemPlayFabParty::AddChatControlToNetwork failed: Network is null or state is invalid!\n"))
	}

	return false;
}

bool FOnlineSubsystemPlayFabParty::InternalConnectToNetwork(PartyLocalUser* PlayFabPartyLocalUser, const FString& InNetworkId, Party::PartyNetworkDescriptor& InNetworkDescriptor)
{
	// This portion of connecting to the network is the same for
	// both creating a new and joining an existing network.

	if (PlayFabPartyLocalUser == nullptr)
	{
		UE_LOG_ONLINE(Warning, TEXT("FOnlineSubsystemPlayFabParty::InternalConnectToNetwork: Could not create new network PlayFabPartyLocalUser was null"));
		return false;
	}

	PartyError Err = PartyManager::GetSingleton().ConnectToNetwork(
		&InNetworkDescriptor,	// Network descriptor
		nullptr,				// Async identifier
		&Network				// OUT network
	);

	if (PARTY_FAILED(Err))
	{
		UE_LOG_ONLINE(Warning, TEXT("FOnlineSubsystemPlayFabParty::InternalConnectToNetwork: ConnectToNetwork failed: %s"), *GetPartyErrorMessage(Err));
		return false;
	}

	// Authenticate the local user on the network so we can participate in it
	Err = Network->AuthenticateLocalUser(
		PlayFabPartyLocalUser,			// Local user
		TCHAR_TO_ANSI(*InNetworkId),	// Invite value
		nullptr							// Async identifier
	);

	if (PARTY_FAILED(Err))
	{
		UE_LOG_ONLINE(Warning, TEXT("FOnlineSubsystemPlayFabParty::InternalConnectToNetwork: AuthenticateLocalUser failed: %s"), *GetPartyErrorMessage(Err));
		return false;
	}

	// Establish a network endpoint for game message traffic
	Err = Network->CreateEndpoint(
		PlayFabPartyLocalUser,	// Local user
		0,						// Property Count
		nullptr,				// Property name keys
		nullptr,				// Property Values
		nullptr,				// Async identifier
		&LocalEndpoint			// OUT local endpoint
	);

	if (PARTY_FAILED(Err))
	{
		UE_LOG_ONLINE(Warning, TEXT("FOnlineSubsystemPlayFabParty::InternalConnectToNetwork: CreateEndpoint failed: %s"), *GetPartyErrorMessage(Err));
		return false;
	}

	return true;
}

void FOnlineSubsystemPlayFabParty::LeavePlayFabPartyNetwork()
{
	UE_LOG_ONLINE(Log, TEXT("FOnlineSubsystemPlayFabParty::LeaveNetwork()"));

	if (NetworkState != EPlayFabPartyNetworkState::LeavingNetwork && Network)
	{
		NetworkState = EPlayFabPartyNetworkState::LeavingNetwork;
		Network->LeaveNetwork(nullptr);

		if (VoiceInterface)
		{
			VoiceInterface->OnLeavePFPNetwork();
		}
	}
}

FString FOnlineSubsystemPlayFabParty::SerializeNetworkDescriptor(const PartyNetworkDescriptor& InNetworkDescriptor)
{
	FString NetworkDescriptorStr;
	
	char Descriptor[c_maxSerializedNetworkDescriptorStringLength + 1] = {};

	PartyError Err = PartyManager::SerializeNetworkDescriptor(
		&InNetworkDescriptor,
		Descriptor
	);

	if (PARTY_FAILED(Err))
	{
		UE_LOG_ONLINE(Warning, TEXT("Failed to serialize network descriptor: %s\n"), *GetPartyErrorMessage(Err));
	}
	else
	{
		NetworkDescriptorStr = ANSI_TO_TCHAR(Descriptor);
	}

	UE_LOG_ONLINE(Verbose, TEXT("FOnlineSubsystemPlayFabParty::SerializeNetworkDescriptor: NetworkDescriptor: %s"), *NetworkDescriptorStr);

	return NetworkDescriptorStr;
}

FString GetPartyErrorMessage(PartyError InError)
{
	PartyString ErrorString = nullptr;

	PartyError Err = PartyManager::GetErrorMessage(InError, &ErrorString);
	if (PARTY_FAILED(Err))
	{
		return FString::Printf(TEXT("[ERROR] Failed to get error message %d.\n"), InError);
	}

	return ANSI_TO_TCHAR(ErrorString);
}

FString PartyStateChangeResultToReasonString(PartyStateChangeResult result)
{
	switch (result)
	{
	case PartyStateChangeResult::Succeeded:					 return TEXT("Succeeded");
	case PartyStateChangeResult::UnknownError:				 return TEXT("An unknown error occurred");
	case PartyStateChangeResult::InternetConnectivityError:  return TEXT("The local device has internet connectivity issues which caused the operation to fail");
	case PartyStateChangeResult::PartyServiceError:			 return TEXT("The CommunicationFabric service is unable to create a new network at this time");
	case PartyStateChangeResult::NoServersAvailable:		 return TEXT("There are no available servers in the regions specified by the call to PartyManager::CreateNewNetwork()");
	case PartyStateChangeResult::CanceledByTitle:			 return TEXT("Operation canceled by title.");
	case PartyStateChangeResult::UserCreateNetworkThrottled: return TEXT("The PartyLocalUser specified in the call to PartyManager::CreateNewNetwork() has created too many networks and cannot create new networks at this time");
	case PartyStateChangeResult::TitleNotEnabledForParty:	 return TEXT("The title has not been configured properly in the Party portal");
	case PartyStateChangeResult::NetworkLimitReached:		 return TEXT("The network is full and is not allowing new devices or users to join");
	case PartyStateChangeResult::NetworkNoLongerExists:		 return TEXT("The network no longer exists");
	case PartyStateChangeResult::NetworkNotJoinable:		 return TEXT("The network is not currently allowing new devices or users to join");
	case PartyStateChangeResult::VersionMismatch:			 return TEXT("The network uses a version of the CommunicationFabric library that is incompatible with this library");
	case PartyStateChangeResult::UserNotAuthorized:			 return TEXT("The specified user was not authorized");
	case PartyStateChangeResult::LeaveNetworkCalled:		 return TEXT("The network was gracefully exited by the local device");
	}
	return TEXT("Unknown enumeration value");
}

FString GetPartyStateChangeTypeString(PartyStateChangeType Type)
{
	switch (Type)
	{
	case PartyStateChangeType::RegionsChanged:									 return TEXT("RegionsChanged");
	case PartyStateChangeType::DestroyLocalUserCompleted:						 return TEXT("DestroyLocalUserCompleted");
	case PartyStateChangeType::CreateNewNetworkCompleted:						 return TEXT("CreateNewNetworkCompleted");
	case PartyStateChangeType::ConnectToNetworkCompleted:						 return TEXT("ConnectToNetworkCompleted");
	case PartyStateChangeType::AuthenticateLocalUserCompleted:					 return TEXT("AuthenticateLocalUserCompleted");
	case PartyStateChangeType::NetworkConfigurationMadeAvailable:				 return TEXT("NetworkConfigurationMadeAvailable");
	case PartyStateChangeType::NetworkDescriptorChanged:						 return TEXT("NetworkDescriptorChanged");
	case PartyStateChangeType::LocalUserRemoved:								 return TEXT("LocalUserRemoved");
	case PartyStateChangeType::RemoveLocalUserCompleted:						 return TEXT("RemoveLocalUserCompleted");
	case PartyStateChangeType::LocalUserKicked:									 return TEXT("LocalUserKicked");
	case PartyStateChangeType::CreateEndpointCompleted:							 return TEXT("CreateEndpointCompleted");
	case PartyStateChangeType::DestroyEndpointCompleted:						 return TEXT("DestroyEndpointCompleted");
	case PartyStateChangeType::EndpointCreated:									 return TEXT("EndpointCreated");
	case PartyStateChangeType::EndpointDestroyed:								 return TEXT("EndpointDestroyed");
	case PartyStateChangeType::RemoteDeviceCreated:								 return TEXT("RemoteDeviceCreated");
	case PartyStateChangeType::RemoteDeviceDestroyed:							 return TEXT("RemoteDeviceDestroyed");
	case PartyStateChangeType::RemoteDeviceJoinedNetwork:						 return TEXT("RemoteDeviceJoinedNetwork");
	case PartyStateChangeType::RemoteDeviceLeftNetwork:							 return TEXT("RemoteDeviceLeftNetwork");
	case PartyStateChangeType::DevicePropertiesChanged:							 return TEXT("DevicePropertiesChanged");
	case PartyStateChangeType::LeaveNetworkCompleted:							 return TEXT("LeaveNetworkCompleted");
	case PartyStateChangeType::NetworkDestroyed:								 return TEXT("NetworkDestroyed");
	case PartyStateChangeType::EndpointMessageReceived:							 return TEXT("EndpointMessageReceived");
	case PartyStateChangeType::DataBuffersReturned:								 return TEXT("DataBuffersReturned");
	case PartyStateChangeType::EndpointPropertiesChanged:						 return TEXT("EndpointPropertiesChanged");
	case PartyStateChangeType::SynchronizeMessagesBetweenEndpointsCompleted:	 return TEXT("SynchronizeMessagesBetweenEndpointsCompleted");
	case PartyStateChangeType::CreateInvitationCompleted:						 return TEXT("CreateInvitationCompleted");
	case PartyStateChangeType::RevokeInvitationCompleted:						 return TEXT("RevokeInvitationCompleted");
	case PartyStateChangeType::InvitationCreated:								 return TEXT("InvitationCreated");
	case PartyStateChangeType::InvitationDestroyed:								 return TEXT("InvitationDestroyed");
	case PartyStateChangeType::NetworkPropertiesChanged:						 return TEXT("NetworkPropertiesChanged");
	case PartyStateChangeType::KickDeviceCompleted:								 return TEXT("KickDeviceCompleted");
	case PartyStateChangeType::KickUserCompleted:								 return TEXT("KickUserCompleted");
	case PartyStateChangeType::SetChatAudioEncoderBitrateCompleted:				 return TEXT("SetChatAudioEncoderBitrateCompleted");
	case PartyStateChangeType::LocalChatAudioOutputChanged:						 return TEXT("LocalChatAudioOutputChanged");
	case PartyStateChangeType::SetLanguageCompleted:							 return TEXT("SetLanguageCompleted");
	case PartyStateChangeType::ChatControlPropertiesChanged:					 return TEXT("ChatControlPropertiesChanged");
	case PartyStateChangeType::DisconnectChatControlCompleted:					 return TEXT("DisconnectChatControlCompleted");
	case PartyStateChangeType::PopulateAvailableTextToSpeechProfilesCompleted:	 return TEXT("PopulateAvailableTextToSpeechProfilesCompleted");
	case PartyStateChangeType::ConfigureAudioManipulationVoiceStreamCompleted:	 return TEXT("ConfigureAudioManipulationVoiceStreamCompleted");
	case PartyStateChangeType::ConfigureAudioManipulationCaptureStreamCompleted: return TEXT("ConfigureAudioManipulationCaptureStreamCompleted");
	case PartyStateChangeType::ConfigureAudioManipulationRenderStreamCompleted:	 return TEXT("ConfigureAudioManipulationRenderStreamCompleted");
	case PartyStateChangeType::ChatTextReceived:								 return TEXT("ChatTextReceived");
	case PartyStateChangeType::VoiceChatTranscriptionReceived:					 return TEXT("VoiceChatTranscriptionReceived");
	case PartyStateChangeType::SetTextToSpeechProfileCompleted:					 return TEXT("SetTextToSpeechProfileCompleted");
	case PartyStateChangeType::SynthesizeTextToSpeechCompleted:					 return TEXT("SynthesizeTextToSpeechCompleted");
	case PartyStateChangeType::SetTranscriptionOptionsCompleted:				 return TEXT("SetTranscriptionOptionsCompleted");
	case PartyStateChangeType::SetTextChatOptionsCompleted:						 return TEXT("SetTextChatOptionsCompleted");
	}

	return TEXT("Unknown PartyStateChangeType");
}

FString GetNetworkStateStateString(EPlayFabPartyNetworkState State)
{
	switch (State)
	{
	case EPlayFabPartyNetworkState::NoNetwork: return TEXT("NoNetwork");
	case EPlayFabPartyNetworkState::JoiningNetwork_Host: return TEXT("JoiningNetwork_Host");
	case EPlayFabPartyNetworkState::JoiningNetwork_Host_PendingEndpointCreation: return TEXT("JoiningNetwork_Host_PendingEndpointCreation");
	case EPlayFabPartyNetworkState::JoiningNetwork_Client: return TEXT("JoiningNetwork_Client");
	case EPlayFabPartyNetworkState::NetworkReady: return TEXT("NetworkReady");
	case EPlayFabPartyNetworkState::LeavingNetwork: return TEXT("LeavingNetwork");
	}
	return TEXT("Unknown");
}

void FOnlineSubsystemPlayFabParty::OnCreateNewNetworkCompleted(const PartyStateChange* Change)
{
	UE_LOG_ONLINE(Verbose, TEXT("FOnlineSubsystemPlayFabParty::OnCreateNewNetworkCompleted"));

	const PartyCreateNewNetworkCompletedStateChange* Result = static_cast<const PartyCreateNewNetworkCompletedStateChange*>(Change);
	if (Result)
	{
		if (Result->result == PartyStateChangeResult::Succeeded)
		{
			UE_LOG_ONLINE(Verbose, TEXT("CreateNewNetworkCompleted: SUCCESS"));
			if (Result->localUser)
			{
				PartyString EntityId;
				Result->localUser->GetEntityId(&EntityId);

				UE_LOG_ONLINE(Verbose, TEXT("CreateNewNetworkCompleted: EntityId: %s"), ANSI_TO_TCHAR(EntityId));
			}
		}
		else
		{
			UE_LOG_ONLINE(Warning, TEXT("CreateNewNetworkCompleted: FAIL: %s"), *PartyStateChangeResultToReasonString(Result->result));
			UE_LOG_ONLINE(Warning, TEXT("ErrorDetail: %s"), *GetPartyErrorMessage(Result->errorDetail));
		}
	}
}

void FOnlineSubsystemPlayFabParty::OnConnectToNetworkCompleted(const PartyStateChange* Change)
{
	UE_LOG_ONLINE(Verbose, TEXT("FOnlineSubsystemPlayFabParty::OnConnectToNetworkCompleted"));

	const PartyConnectToNetworkCompletedStateChange* Result = static_cast<const PartyConnectToNetworkCompletedStateChange*>(Change);
	if (Result)
	{
		if (Result->result == PartyStateChangeResult::Succeeded)
		{
			UE_LOG_ONLINE(Verbose, TEXT("ConnectToNetworkCompleted: SUCCESS"));

			// We branch here if we are the host, since we need to wait for the local endpoint to be created to store the info in the session / have a valid 'PlayFab IP addr' class instance
			if (NetworkState == EPlayFabPartyNetworkState::JoiningNetwork_Host)
			{
				NetworkState = EPlayFabPartyNetworkState::JoiningNetwork_Host_PendingEndpointCreation;
			}
			else
			{
				NetworkState = EPlayFabPartyNetworkState::NetworkReady;
			}
			NetworkDescriptor = Result->networkDescriptor;

			TriggerOnConnectToPlayFabPartyNetworkCompletedDelegates(true);
		}
		else
		{
			UE_LOG_ONLINE(Warning, TEXT("ConnectToNetworkCompleted: FAIL:  %s"), *PartyStateChangeResultToReasonString(Result->result));
			UE_LOG_ONLINE(Warning, TEXT("ErrorDetail: %s"), *GetPartyErrorMessage(Result->errorDetail));

			TriggerOnConnectToPlayFabPartyNetworkCompletedDelegates(false);
		}
	}
}

void FOnlineSubsystemPlayFabParty::OnLeaveNetworkCompleted(const PartyStateChange* Change)
{
	UE_LOG_ONLINE(Verbose, TEXT("FOnlineSubsystemPlayFabParty::OnLeaveNetworkCompleted"));

	const PartyLeaveNetworkCompletedStateChange* Result = static_cast<const PartyLeaveNetworkCompletedStateChange*>(Change);
	if (Result)
	{
		NetworkState = EPlayFabPartyNetworkState::NoNetwork;
		Network = nullptr;
	}
}

void FOnlineSubsystemPlayFabParty::OnNetworkDestroyed(const PartyStateChange* Change)
{
	UE_LOG_ONLINE(Verbose, TEXT("FOnlineSubsystemPlayFabParty::OnNetworkDestroyed"));

	const PartyNetworkDestroyedStateChange* Result = static_cast<const PartyNetworkDestroyedStateChange*>(Change);
	if (Result)
	{
		UE_LOG_ONLINE(Warning, TEXT("FOnlineSubsystemPlayFabParty::OnNetworkDestroyed: PlayFab Party network was destroyed with reason code %d"), Result->reason);

		FPlayFabPartySocketSubsystem* SocketSubsystem = static_cast<FPlayFabPartySocketSubsystem*>(ISocketSubsystem::Get(PLAYFABPARTY_SOCKET_SUBSYSTEM));
		if (SocketSubsystem == nullptr)
		{
			return;
		}

		UPlayFabPartyNetDriver* PlayFabNetDriver = SocketSubsystem->GetLinkedNetDriver();
		if (PlayFabNetDriver == nullptr)
		{
			return;
		}

		UIpConnection* const ServerConnection = PlayFabNetDriver->GetServerConnection();

		if (ServerConnection != nullptr)
		{
			ServerConnection->Close();
		}
		else // We are the host and must handle this, UE won't handle it like a client because the host connection wont get closed
		{
			// was it an error? If so what kind
			FString ErrorString;
			if (Result->reason == PartyDestroyedReason::Requested)
			{
				// not an error
			}
			else if (Result->reason == PartyDestroyedReason::Disconnected)
			{
				ErrorString = FString::Printf(TEXT("You have lost connection to the multiplayer service."));
			}
			else if (Result->reason == PartyDestroyedReason::Kicked)
			{
				ErrorString = FString::Printf(TEXT("You were kicked from the match."));
			}
			else if (Result->reason == PartyDestroyedReason::DeviceLostAuthentication)
			{
				ErrorString = FString::Printf(TEXT("You have lost connection to the authentication service."));
			}
			else if (Result->reason == PartyDestroyedReason::CreationFailed)
			{
				ErrorString = FString::Printf(TEXT("Failed to create a match."));
			}

			if (!ErrorString.IsEmpty())
			{
				GEngine->BroadcastNetworkFailure(PlayFabNetDriver->GetWorld(), PlayFabNetDriver, ENetworkFailure::PendingConnectionFailure, ErrorString);
			}
		}
	
	}
}

void FOnlineSubsystemPlayFabParty::OnEndpointMessageReceived(const PartyStateChange* Change)
{
	const PartyEndpointMessageReceivedStateChange* Result = static_cast<const PartyEndpointMessageReceivedStateChange*>(Change);
	if (Result)
	{
		TriggerOnEndpointMessageReceivedDelegates(Result);
	}
}

void FOnlineSubsystemPlayFabParty::OnNetworkConfigurationMadeAvailable(const PartyStateChange* Change)
{
	UE_LOG_ONLINE(Verbose, TEXT("FOnlineSubsystemPlayFabParty::OnNetworkConfigurationMadeAvailable"));

	const PartyNetworkConfigurationMadeAvailableStateChange* Result = static_cast<const PartyNetworkConfigurationMadeAvailableStateChange*>(Change);
	if (Result)
	{
		if (Result->networkConfiguration)
		{
			MaxDeviceCount = Result->networkConfiguration->maxDeviceCount;
			MaxDevicesPerUserCount = Result->networkConfiguration->maxDevicesPerUserCount;
			MaxEndpointsPerDeviceCount = Result->networkConfiguration->maxEndpointsPerDeviceCount;
			MaxUserCount = Result->networkConfiguration->maxUserCount;
			MaxUsersPerDeviceCount = Result->networkConfiguration->maxUsersPerDeviceCount;
		}
		else
		{
			UE_LOG_ONLINE(Warning, TEXT("FOnlineSubsystemPlayFabParty::OnNetworkConfigurationMadeAvailable: The NetworkConfiguration returned was null"));
		}
	}
}

void FOnlineSubsystemPlayFabParty::OnNetworkDescriptorChanged(const PartyStateChange* Change)
{
	UE_LOG_ONLINE(Verbose, TEXT("FOnlineSubsystemPlayFabParty::OnNetworkDescriptorChanged"));

	const PartyNetworkDescriptorChangedStateChange* Result = static_cast<const PartyNetworkDescriptorChangedStateChange*>(Change);
	if (Result)
	{
		if (Result->network)
		{
			PartyNetworkDescriptor* NewNetorkDescriptor = nullptr;

			PartyError Err = Result->network->GetNetworkDescriptor(NewNetorkDescriptor);

			if (PARTY_FAILED(Err))
			{
				UE_LOG_ONLINE(Warning, TEXT("FOnlineSubsystemPlayFabParty::OnNetworkDescriptorChanged: Failed to get network descriptor from network: %s"), *GetPartyErrorMessage(Err));
				return;
			}
		}
		else
		{
			UE_LOG_ONLINE(Warning, TEXT("FOnlineSubsystemPlayFabParty::OnNetworkDescriptorChanged: The PartyNetwork returned was null"));
		}
	}
}

void FOnlineSubsystemPlayFabParty::OnNetworkPropertiesChanged(const PartyStateChange* Change)
{
	UE_LOG_ONLINE(Verbose, TEXT("FOnlineSubsystemPlayFabParty::OnNetworkPropertiesChanged"));
}

void FOnlineSubsystemPlayFabParty::OnCreateEndpointCompleted(const PartyStateChange* Change)
{
	UE_LOG_ONLINE(Verbose, TEXT("FOnlineSubsystemPlayFabParty::OnCreateEndpointCompleted"));
}

void FOnlineSubsystemPlayFabParty::OnDestroyEndpointCompleted(const PartyStateChange* Change)
{
	UE_LOG_ONLINE(Verbose, TEXT("FOnlineSubsystemPlayFabParty::OnDestroyEndpointCompleted"));
}

void FOnlineSubsystemPlayFabParty::OnEndpointCreated(const PartyStateChange* Change)
{
	UE_LOG_ONLINE(Verbose, TEXT("FOnlineSubsystemPlayFabParty::OnEndpointCreated"));

	const PartyEndpointCreatedStateChange* Result = static_cast<const PartyEndpointCreatedStateChange*>(Change);
	if (Result)
	{
		bool bIsHosting = NetworkState == EPlayFabPartyNetworkState::JoiningNetwork_Host_PendingEndpointCreation;

		PartyEndpoint* NewEndpoint = Result->endpoint;
		if (NewEndpoint)
		{
			uint16 EndpointId = 0;
			PartyError Err = NewEndpoint->GetUniqueIdentifier(&EndpointId);
			if (PARTY_FAILED(Err) || EndpointId == 0)
			{
				UE_LOG_ONLINE(Warning, TEXT("FOnlineSubsystemPlayFabParty::OnEndpointCreated: Unable to retrieve UniqueIdentifier from endpoint: %s"), *GetPartyErrorMessage(Err));

				

				TriggerOnPartyEndpointCreatedDelegates(false, 0, bIsHosting);
			}
			else
			{
				Endpoints.Add(EndpointId, NewEndpoint);
				NetworkState = EPlayFabPartyNetworkState::NetworkReady;
				TriggerOnPartyEndpointCreatedDelegates(true, EndpointId, bIsHosting);

				UE_LOG(LogNet, Warning, TEXT("FOnlineSubsystemPlayFabParty::OnEndpointCreate: Created Party Endpoint: %d"), EndpointId);
			}
		}
		else
		{
			UE_LOG_ONLINE(Warning, TEXT("FOnlineSubsystemPlayFabParty::OnEndpointCreated: returned enpoint was invalid"));
			TriggerOnPartyEndpointCreatedDelegates(false, 0, bIsHosting);
		}
	}
}

void FOnlineSubsystemPlayFabParty::OnEndpointDestroyed(const PartyStateChange* Change)
{
	UE_LOG_ONLINE(Verbose, TEXT("FOnlineSubsystemPlayFabParty::OnEndpointDestroyed"));

	const PartyEndpointDestroyedStateChange* Result = static_cast<const PartyEndpointDestroyedStateChange*>(Change);
	if (Result)
	{
		PartyEndpoint* NewEndpoint = Result->endpoint;
		if (NewEndpoint)
		{
			uint16 EndpointId = 0;
			PartyError Err = NewEndpoint->GetUniqueIdentifier(&EndpointId);
			if (PARTY_FAILED(Err) || EndpointId == 0)
			{
				UE_LOG_ONLINE(Warning, TEXT("FOnlineSubsystemPlayFabParty::OnEndpointDestroyed: Unable to retrieve UniqueIdentifier from endpoint: %s"), *GetPartyErrorMessage(Err));
			}
			else
			{
				Endpoints.Remove(EndpointId);
			}

			UE_LOG_ONLINE(Verbose, TEXT("FOnlineSubsystemPlayFabParty::OnEndpointDestroyed: Destroying endpoint %d with reason code %d"), EndpointId, Result->reason);

			// Also close the net connection for instantaneous disconnection rather than a timeout
			FPlayFabPartySocketSubsystem* SocketSubsystem = static_cast<FPlayFabPartySocketSubsystem*>(ISocketSubsystem::Get(PLAYFABPARTY_SOCKET_SUBSYSTEM));
			if (SocketSubsystem == nullptr)
			{
				return;
			}

			UPlayFabPartyNetDriver* PlayFabNetDriver = SocketSubsystem->GetLinkedNetDriver();
			if (PlayFabNetDriver == nullptr)
			{
				return;
			}

			// Was it the server connection? Also handled in network destroy but lets close for sanity
			UIpConnection* const ServerConnection = PlayFabNetDriver->GetServerConnection();
			UNetConnection* ConnectionToClose = nullptr;
			if (ServerConnection != nullptr && ServerConnection->GetAddrPort() == EndpointId)
			{
				ConnectionToClose = ServerConnection;
			}
			else
			{
				TSharedRef<FInternetAddr> CompareAddr = SocketSubsystem->CreateInternetAddr();
				CompareAddr->SetIp(EndpointId);
				CompareAddr->SetPort(EndpointId);
				UNetConnection** ConnectionFound = PlayFabNetDriver->MappedClientConnections.Find(CompareAddr);
				if (ConnectionFound != nullptr)
				{
					ConnectionToClose = *ConnectionFound;
				}
			}

			if (ConnectionToClose != nullptr)
			{
				ConnectionToClose->Close();
			}
		}
		else
		{
			UE_LOG_ONLINE(Warning, TEXT("FOnlineSubsystemPlayFabParty::OnEndpointDestroyed: returned enpoint was invalid"));
		}
	}
}

void FOnlineSubsystemPlayFabParty::OnEndpointPropertiesChanged(const PartyStateChange* Change)
{
	UE_LOG_ONLINE(Verbose, TEXT("FOnlineSubsystemPlayFabParty::OnEndpointPropertiesChanged"));
}

void FOnlineSubsystemPlayFabParty::OnRegionsChanged(const PartyStateChange* Change)
{
	UE_LOG_ONLINE(Verbose, TEXT("FOnlineSubsystemPlayFabParty::OnRegionsChanged"));
}

void FOnlineSubsystemPlayFabParty::OnDestroyLocalUserCompleted(const PartyStateChange* Change)
{
	UE_LOG_ONLINE(Verbose, TEXT("FOnlineSubsystemPlayFabParty::OnDestroyLocalUserCompleted"));
}

void FOnlineSubsystemPlayFabParty::OnAuthenticateLocalUserCompleted(const PartyStateChange* Change)
{
	UE_LOG_ONLINE(Verbose, TEXT("FOnlineSubsystemPlayFabParty::OnAuthenticateLocalUserCompleted"));
}

void FOnlineSubsystemPlayFabParty::OnRemoteDeviceDestroyed(const PartyStateChange* Change)
{
	UE_LOG_ONLINE(Verbose, TEXT("FOnlineSubsystemPlayFabParty::OnRemoteDeviceDestroyed"));
}

void FOnlineSubsystemPlayFabParty::OnRemoteDeviceJoinedNetwork(const PartyStateChange* Change)
{
	UE_LOG_ONLINE(Verbose, TEXT("FOnlineSubsystemPlayFabParty::OnRemoteDeviceJoinedNetwork"));
}

void FOnlineSubsystemPlayFabParty::OnRemoteDeviceLeftNetwork(const PartyStateChange* Change)
{
	UE_LOG_ONLINE(Verbose, TEXT("FOnlineSubsystemPlayFabParty::OnRemoteDeviceLeftNetwork"));
}

void FOnlineSubsystemPlayFabParty::OnDevicePropertiesChanged(const PartyStateChange* Change)
{
	UE_LOG_ONLINE(Verbose, TEXT("FOnlineSubsystemPlayFabParty::OnDevicePropertiesChanged"));
}

void FOnlineSubsystemPlayFabParty::OnDataBuffersReturned(const PartyStateChange* Change)
{
	UE_LOG_ONLINE(Verbose, TEXT("FOnlineSubsystemPlayFabParty::OnDataBuffersReturned"));
}

void FOnlineSubsystemPlayFabParty::OnLocalUserRemoved(const PartyStateChange* Change)
{
	UE_LOG_ONLINE(Verbose, TEXT("FOnlineSubsystemPlayFabParty::OnLocalUserRemoved"));
}

void FOnlineSubsystemPlayFabParty::OnRemoveLocalUserCompleted(const PartyStateChange* Change)
{
	UE_LOG_ONLINE(Verbose, TEXT("FOnlineSubsystemPlayFabParty::OnRemoveLocalUserCompleted"));
}

void FOnlineSubsystemPlayFabParty::OnLocalUserKicked(const PartyStateChange* Change)
{
	UE_LOG_ONLINE(Verbose, TEXT("FOnlineSubsystemPlayFabParty::OnLocalUserKicked"));
}

void FOnlineSubsystemPlayFabParty::OnCreateInvitationCompleted(const PartyStateChange* Change)
{
	UE_LOG_ONLINE(Verbose, TEXT("FOnlineSubsystemPlayFabParty::OnCreateInvitationCompleted"));
}

void FOnlineSubsystemPlayFabParty::OnRevokeInvitationCompleted(const PartyStateChange* Change)
{
	UE_LOG_ONLINE(Verbose, TEXT("FOnlineSubsystemPlayFabParty::OnRevokeInvitationCompleted"));
}

void FOnlineSubsystemPlayFabParty::OnInvitationCreated(const PartyStateChange* Change)
{
	UE_LOG_ONLINE(Verbose, TEXT("FOnlineSubsystemPlayFabParty::OnInvitationCreated"));
}

void FOnlineSubsystemPlayFabParty::OnInvitationDestroyed(const PartyStateChange* Change)
{
	UE_LOG_ONLINE(Verbose, TEXT("FOnlineSubsystemPlayFabParty::OnInvitationDestroyed"));
}

void FOnlineSubsystemPlayFabParty::OnKickDeviceCompleted(const PartyStateChange* Change)
{
	UE_LOG_ONLINE(Verbose, TEXT("FOnlineSubsystemPlayFabParty::OnKickDeviceCompleted"));
}

void FOnlineSubsystemPlayFabParty::OnKickUserCompleted(const PartyStateChange* Change)
{
	UE_LOG_ONLINE(Verbose, TEXT("FOnlineSubsystemPlayFabParty::OnKickUserCompleted"));
}

void FOnlineSubsystemPlayFabParty::OnRemoteDeviceCreated(const PartyStateChange* Change)
{
	UE_LOG_ONLINE(Verbose, TEXT("FOnlineSubsystemPlayFabParty::OnRemoteDeviceCreated"));
}

void FOnlineSubsystemPlayFabParty::OnSynchronizeMessagesBetweenEndpointsCompleted(const PartyStateChange* Change)
{
	UE_LOG_ONLINE(Verbose, TEXT("FOnlineSubsystemPlayFabParty::OnSynchronizeMessagesBetweenEndpointsCompleted"));
}

void FOnlineSubsystemPlayFabParty::OnSetChatAudioEncoderBitrateCompleted(const PartyStateChange* Change)
{
	UE_LOG_ONLINE(Verbose, TEXT("FOnlineSubsystemPlayFabParty::OnSetChatAudioEncoderBitrateCompleted"));
}

void FOnlineSubsystemPlayFabParty::OnLocalChatAudioOutputChanged(const PartyStateChange* Change)
{
	UE_LOG_ONLINE(Verbose, TEXT("FOnlineSubsystemPlayFabParty::OnLocalChatAudioOutputChanged"));
}

void FOnlineSubsystemPlayFabParty::OnSetLanguageCompleted(const PartyStateChange* Change)
{
	UE_LOG_ONLINE(Verbose, TEXT("FOnlineSubsystemPlayFabParty::OnSetLanguageCompleted"));
}

void FOnlineSubsystemPlayFabParty::OnChatControlPropertiesChanged(const PartyStateChange* Change)
{
	UE_LOG_ONLINE(Verbose, TEXT("FOnlineSubsystemPlayFabParty::OnChatControlPropertiesChanged"));
}

void FOnlineSubsystemPlayFabParty::OnDisconnectChatControlCompleted(const PartyStateChange* Change)
{
	UE_LOG_ONLINE(Verbose, TEXT("FOnlineSubsystemPlayFabParty::OnDisconnectChatControlCompleted"));
}

void FOnlineSubsystemPlayFabParty::OnConfigureAudioManipulationVoiceStreamCompleted(const PartyStateChange* Change)
{
	UE_LOG_ONLINE(Verbose, TEXT("FOnlineSubsystemPlayFabParty::OnConfigureAudioManipulationVoiceStreamCompleted"));
}

void FOnlineSubsystemPlayFabParty::OnConfigureAudioManipulationCaptureStreamCompleted(const PartyStateChange* Change)
{
	UE_LOG_ONLINE(Verbose, TEXT("FOnlineSubsystemPlayFabParty::OnConfigureAudioManipulationCaptureStreamCompleted"));
}

void FOnlineSubsystemPlayFabParty::OnConfigureAudioManipulationRenderStreamCompleted(const PartyStateChange* Change)
{
	UE_LOG_ONLINE(Verbose, TEXT("FOnlineSubsystemPlayFabParty::OnConfigureAudioManipulationRenderStreamCompleted"));
}

PartyEndpoint* FOnlineSubsystemPlayFabParty::GetPartyEndpoint(uint32 EndpointId)
{
	if (EndpointId != 0)
	{
		PartyEndpoint** PlayFabPartyEndpoint = Endpoints.Find(EndpointId);

		if (PlayFabPartyEndpoint == nullptr || *PlayFabPartyEndpoint == nullptr)
		{
			UE_LOG(LogSockets, Warning, TEXT("FOnlineSubsystemPlayFabParty::GetPartyEndpoint: Could not find Enpoint for UniqueId %d"), EndpointId);
		}
		else
		{
			return *PlayFabPartyEndpoint;
		}
	}
	else
	{
		UE_LOG(LogSockets, Warning, TEXT("FOnlineSubsystemPlayFabParty::GetPartyEndpoint: UniqueId was invalid"));
	}

	return nullptr;
}