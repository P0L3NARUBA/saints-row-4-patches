//--------------------------------------------------------------------------------------
// Copyright (C) Microsoft Corporation. All rights reserved.
//--------------------------------------------------------------------------------------

#pragma once

#include "CoreTypes.h"

#define INVALID_INDEX -1

// URL Prefix when using PlayFab Party connection
#define PLAYFABPARTY_URL_PREFIX TEXT("PlayFabParty.")

// Pre-pended to all PlayFab Party logging
#undef ONLINE_LOG_PREFIX
#define ONLINE_LOG_PREFIX TEXT("PLAYFABPARTY: ")

#define SETTING_NETWORK_ID FName(TEXT("NETWORKID"))
#define SETTING_NETWORK_DESCRIPTOR FName(TEXT("NETWORKDESCRIPTOR"))
#define SETTING_HOST_CONNECT_INFO FName(TEXT("HOSTCONNECTINFO"))