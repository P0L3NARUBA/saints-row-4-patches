//--------------------------------------------------------------------------------------
// Copyright (C) Microsoft Corporation. All rights reserved.
//--------------------------------------------------------------------------------------

#pragma once

#include "Interfaces/OnlineIdentityInterface.h"
#include "OnlineSubsystemPlayFabPartyPackage.h"
#include "OnlineSubsystemPlayFabPartyDefines.h"
#include "Interfaces/IHttpRequest.h"
#include "Interfaces/IHttpResponse.h"
#include "Misc/DateTime.h"
#include "Dom/JsonObject.h"

#include <vector>

THIRD_PARTY_INCLUDES_START
#include <Party.h>
using namespace Party;
THIRD_PARTY_INCLUDES_END

struct UserAuthRequestData
{
	TSharedPtr<class IHttpRequest> m_HTTPRequest;
};

class FPlayFabPartyUser
{
public:
	FPlayFabPartyUser(const FString& PlatformUserIdStrIn, const FString& EntityTokenIn, PartyLocalUser* LocalUserIn)
		: PlatformUserIdStr(PlatformUserIdStrIn)
		, EntityToken(EntityTokenIn)
		, LocalUser(LocalUserIn)
	{
		SetNewEntityTokenUpdateTime();
	}

	const FString& GetPlatformUserId() const { return PlatformUserIdStr; }
	const FString& GetEntityToken() const { return EntityToken; }
	const FDateTime& GetEntityTokenUpdateTime() const { return EntityTokenUpdateTime; }
	PartyLocalUser* GetPartyLocalUser() const { return LocalUser; }

	void UpdateEntityToken(const FString& NewEntityToken);

	void SetNewEntityTokenUpdateTime();

private:
	FString PlatformUserIdStr;
	FString EntityToken;
	PartyLocalUser* LocalUser = nullptr;
	FDateTime EntityTokenUpdateTime;
};

class FOnlineIdentityPlayFabParty
	: public IOnlineIdentity
	, public TSharedFromThis<FOnlineIdentityPlayFabParty, ESPMode::ThreadSafe>
{
PACKAGE_SCOPE:

	/** Constructor
	 *
	 * @param InSubsystem The owner of this identity interface.
	 */
	explicit FOnlineIdentityPlayFabParty(class FOnlineSubsystemPlayFabParty* InSubsystem);

	/** Reference to the owning subsystem */
	class FOnlineSubsystemPlayFabParty* OSSPlayFabParty = nullptr;

public:

	virtual ~FOnlineIdentityPlayFabParty();

	// IOnlineIdentity

	virtual bool Login(int32 LocalUserNum, const FOnlineAccountCredentials& AccountCredentials) override;
	virtual bool Logout(int32 LocalUserNum) override;
	virtual bool AutoLogin(int32 LocalUserNum) override;
	virtual TSharedPtr<FUserOnlineAccount> GetUserAccount(const FUniqueNetId& UserId) const override;
	virtual TArray<TSharedPtr<FUserOnlineAccount> > GetAllUserAccounts() const override;
	virtual TSharedPtr<const FUniqueNetId> GetUniquePlayerId(int32 LocalUserNum) const override;
	virtual TSharedPtr<const FUniqueNetId> GetSponsorUniquePlayerId(int32 LocalUserNum) const override;
	virtual TSharedPtr<const FUniqueNetId> CreateUniquePlayerId(uint8* Bytes, int32 Size) override;
	virtual TSharedPtr<const FUniqueNetId> CreateUniquePlayerId(const FString& Str) override;
	virtual ELoginStatus::Type GetLoginStatus(int32 LocalUserNum) const override;
	virtual ELoginStatus::Type GetLoginStatus(const FUniqueNetId& UserId) const override;
	virtual FString GetPlayerNickname(int32 LocalUserNum) const override;
	virtual FString GetPlayerNickname(const FUniqueNetId& UserId) const override;
	virtual FString GetAuthToken(int32 LocalUserNum) const override;
	virtual void RevokeAuthToken(const FUniqueNetId& UserId, const FOnRevokeAuthTokenCompleteDelegate& Delegate) override;
	virtual void GetUserPrivilege(const FUniqueNetId& UserId, EUserPrivileges::Type Privilege, const FOnGetUserPrivilegeCompleteDelegate& Delegate) override;
	virtual FPlatformUserId GetPlatformUserIdFromUniqueNetId(const FUniqueNetId& UniqueNetId) const override;
	virtual FString GetAuthType() const override;

	UserAuthRequestData* GetUserAuthRequestData(const FString& PlatformUserIdStr)
	{
		if (UserAuthRequestsInFlight.Contains(PlatformUserIdStr))
		{
			return &UserAuthRequestsInFlight[PlatformUserIdStr];
		}

		return nullptr;
	}

	const FString GetUserPlatformIdStrFromRequest(FHttpRequestPtr HttpRequest)
	{
		for (auto& Elem : UserAuthRequestsInFlight)
		{
			const UserAuthRequestData& ReqData = Elem.Value;
			if (ReqData.m_HTTPRequest.Get() == HttpRequest.Get())
			{
				return Elem.Key;
			}
		}

		return FString();
	}

	UserAuthRequestData* GetUserAuthRequestDataFromRequest(FHttpRequestPtr HttpRequest)
	{
		for (auto& Elem : UserAuthRequestsInFlight)
		{
			const UserAuthRequestData& ReqData = Elem.Value;
			if (ReqData.m_HTTPRequest.Get() == HttpRequest.Get())
			{
				return &Elem.Value;
			}
		}

		return nullptr;
	}

	void Tick(float DeltaTime);
	void OnAppSuspend();
	void OnAppResume();
	void TryAuthenticateUsers();
	void CleanUpLocalUsers();

	PartyLocalUser* GetFirstPartyLocalUser();

	FPlayFabPartyUser* GetPartyLocalUserFromPlatformId(const FUniqueNetId& PlatformNetId);
	FPlayFabPartyUser* GetPartyLocalUserFromPlatformIdString(const FString& PlatformNetIdStr);

	const TArray<FPlayFabPartyUser*>& GetAllPartyLocalUsers() const
	{
		return LocalPlayFabUsers;
	}

protected:
	bool AuthenticateUser(const FString& UserPlatformIdStr);
	void Auth_HttpRequestComplete(FHttpRequestPtr HttpRequest, FHttpResponsePtr HttpResponse, bool bSucceeded);

	void CreateLocalUser(const FString& UserPlatformIdStr, const FString& EntityId, const FString& EntityToken, const FString& TokenExpiration);
	void RemoveLocalUser(const FString& PlatformUserIdStr);
	
private:
	TArray<FPlayFabPartyUser*> LocalPlayFabUsers;
	TArray<FString> UsersToAuth;
	TMap<FString, UserAuthRequestData> UserAuthRequestsInFlight;
	bool bRegisterAuthDelegates = true;
	bool bAuthAllUsers = true;
	float AuthCoolDownTime = 3.0f;
	float TimeSinceLastAuth = 0.0f;

	TArray<FDelegateHandle> LoginStatusChangedDelegateHandles;
	TArray<FDelegateHandle> LoginCompleteDelegateHandles;
	TArray<FDelegateHandle> LogoutCompleteDelegateHandles;

	void RegisterAuthDelegates();
	void CleanUpAuthDelegates();

	void OnLoginStatusChanged(int32 LocalUserNum, ELoginStatus::Type OldStatus, ELoginStatus::Type NewStatus, const FUniqueNetId& NewId);
	void OnLoginComplete(int32 LocalUserNum, bool bWasSuccessful, const FUniqueNetId& UserId, const FString& Error);
	void OnLogoutComplete(int32 LocalUserNum, bool bWasSuccessful);

public:
	// Platform specific, must implement for your platform!
	bool ApplyPlatformHTTPRequestData(const FString& PlatformUserIdStr, const FString& URL, const FString& RequestVerb);
	static void OnPopulatePlatformRequestDataCompleted(bool bWasSuccessful, const FString& PlatformUserIdStr, TMap<FString, FString> PlatformHeaders = TMap<FString, FString>(), TSharedPtr<FJsonObject> RequestBodyJson = TSharedPtr<FJsonObject>(nullptr));

	void FinishRequest(bool bPlatformDataSuccess, const FString& UserPlatformId, TMap<FString, FString> PlatformHeaders, TSharedPtr<FJsonObject> RequestBodyJson);

	//OnLoginChanged
	virtual FDelegateHandle AddOnLoginChangedDelegate_Handle(const FOnLoginChangedDelegate& Delegate) override;
	virtual void ClearOnLoginChangedDelegate_Handle(FDelegateHandle& Handle) override;
	virtual void TriggerOnLoginChangedDelegates(int32 LocalUserNum) override;

	//OnLoginStatusChanged
	virtual FDelegateHandle AddOnLoginStatusChangedDelegate_Handle(int32 LocalUserNum, const FOnLoginStatusChangedDelegate& Delegate) override;
	virtual void ClearOnLoginStatusChangedDelegate_Handle(int32 LocalUserNum, FDelegateHandle& Handle) override;
	virtual void TriggerOnLoginStatusChangedDelegates(int32 LocalUserNum, ELoginStatus::Type OldStatus, ELoginStatus::Type NewStatus, const FUniqueNetId& NewId) override;

	//OnControllerPairingChanged
	virtual FDelegateHandle AddOnControllerPairingChangedDelegate_Handle(const FOnControllerPairingChangedDelegate& Delegate) override;
	virtual void ClearOnControllerPairingChangedDelegate_Handle(FDelegateHandle& Handle) override;
	virtual void TriggerOnControllerPairingChangedDelegates(int LocalUserNum, FControllerPairingChangedUserInfo PreviousUser, FControllerPairingChangedUserInfo NewUser) override;

	//OnLoginComplete
	virtual FDelegateHandle AddOnLoginCompleteDelegate_Handle(int32 LocalUserNum, const FOnLoginCompleteDelegate& Delegate) override;
	virtual void ClearOnLoginCompleteDelegate_Handle(int32 LocalUserNum, FDelegateHandle& Handle) override;
	virtual void TriggerOnLoginCompleteDelegates(int32 LocalUserNum, bool bWasSuccessful, const FUniqueNetId& UserId, const FString& Error) override;

	//OnLogoutComplete
	virtual FDelegateHandle AddOnLogoutCompleteDelegate_Handle(int32 LocalUserNum, const FOnLogoutCompleteDelegate& Delegate) override;
	virtual void ClearOnLogoutCompleteDelegate_Handle(int32 LocalUserNum, FDelegateHandle& Handle) override;
	virtual void TriggerOnLogoutCompleteDelegates(int32 LocalUserNum, bool bWasSuccessful) override;

	//OnLoginFlowLogout
	virtual FDelegateHandle AddOnLoginFlowLogoutDelegate_Handle(const FOnLoginFlowLogoutDelegate& Delegate) override;
	virtual void ClearOnLoginFlowLogoutDelegate_Handle(FDelegateHandle& Handle) override;
	virtual void TriggerOnLoginFlowLogoutDelegates(const TArray<FString>& LoginDomains) override;
};

typedef TSharedPtr<class FOnlineIdentityPlayFabParty, ESPMode::ThreadSafe> FOnlineIdentityPlayFabPartyPtr;